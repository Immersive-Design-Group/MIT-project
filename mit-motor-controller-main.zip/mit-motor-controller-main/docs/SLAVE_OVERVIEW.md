# Slave Implementation Overview

This document provides a comprehensive overview of the CAN slave implementation in the 250729IDG_Slave codebase. This serves as a reference for implementing the same functionality in the mit-motor-controller.

## System Architecture

The slave implementation is designed to work with a master controller in a CAN-based motor control system. Each slave controls up to 20 stepper motors with limit switches for homing.

### Key Components

1. **CAN Communication Layer**:
   - Dual CAN interface (CAN1 and CAN2) for redundancy
   - Message filtering based on slave ID
   - Standard 11-bit CAN identifiers

2. **Motor Control Layer**:
   - Control of up to 20 stepper motors
   - Homing procedure using limit switches
   - Speed control with acceleration/deceleration

3. **Peripheral Management**:
   - GPIO for motor control and limit switches
   - ADC for temperature monitoring
   - DAC for motor driver reference voltage
   - Timers for precise motor stepping

## CAN Implementation Details

### CAN Initialization

The CAN interfaces are initialized in `Core/Src/can.c` with the following configuration:
- **Bit Timing**: 
  - Prescaler: 12
  - TimeSeg1: 7
  - TimeSeg2: 6
  - SJW: 1
  - Resulting bitrate: ~1Mbps (assuming 42MHz CAN clock)
- **Mode**: Normal operation
- **Features**: 
  - Automatic bus-off recovery disabled
  - Automatic wake-up disabled
  - Automatic retransmission disabled
  - Receive FIFO locked disabled
  - Transmit FIFO priority disabled

### Message Filtering

Each CAN interface uses identifier list filtering to receive only messages intended for this slave:
- Filters are configured based on the slave's `machine_id`
- CAN1 receives messages with IDs: `machine_id * 6 + 1`, `machine_id * 6 + 2`, `machine_id * 6 + 3`, `machine_id * 6 + 6`
- CAN2 receives messages with IDs: `machine_id * 6 + 4`, `machine_id * 6 + 5`, `machine_id * 6 + 6`, `NUM_SLAVES * 6 + 7`

### Message Format

#### Incoming Messages

1. **Position Commands** (ID = machine_id * 6 + [1-5]):
   - Data: 8 bytes containing 4 position values
   - Each position value is represented as two decimal digits (tens in even bytes, units in odd bytes)
   - Example: To send position 123, data would be [12, 3, ...]
   - Stored in `data_CAN` buffer at indices [0-7], [8-15], [16-23], [24-31], [32-39] for message IDs 1-5 respectively

2. **Status Commands** (ID = machine_id * 6 + 6):
   - Contains state information and command codes
   - Special handling for initialization (data[0] == 3)
   - Stored in `data_CAN` buffer at indices [40-47]

3. **Control Commands** (ID = NUM_SLAVES * 6 + 7):
   - Global commands affecting all slaves
   - Command code in data[0]:
     - 4: Get side ID
     - 5: Set motor speed (data[1-2] = init_speed high/low, data[3-4] = high_speed high/low)
     - 7: Set fan temperature (data[1] = start temp, data[2] = stop temp)

#### Outgoing Messages

1. **Initialization Status**:
   - Sent in response to initialization command
   - ID: NUM_SLAVES * 6 + 1
   - Data format: [machine_id, 3, 0, 0, 0, 0, 0, 1]
   - Byte 7 value of 1 indicates initialization status message

2. **Temperature Data**:
   - Sent periodically when temperature changes
   - ID: NUM_SLAVES * 6 + 1
   - Data format: [machine_id, temp0, temp1, temp2, 0, 0, 0, 3]
   - Byte 7 value of 3 indicates temperature data message

3. **Retransmission Requests**:
   - Sent when data is missing or corrupted
   - ID: NUM_SLAVES * 6 + 1
   - Data format: [machine_id, flag1, flag2, ..., flag6, 0]
   - Flags indicate which messages need retransmission
   - Byte 7 value of 0 indicates retransmission request

## Slave Identification

Each slave is uniquely identified by a 5-bit hardware address:
- **Hardware Pins**: ADD0-ADD4 pins are read at startup
- **Address Calculation**: machine_id = Σ(ADDi == LOW ? 1<<i : 0) - 1
- **Valid Range**: 0-30 (5-bit value minus 1)
- **Implementation**: In `GetMachineID()` function in `Drivers/Users/Src/global.c`

## Data Processing Flow

1. **Message Reception**:
   - Messages are received in interrupt context via `HAL_CAN_RxFifo0MsgPendingCallback` or `HAL_CAN_RxFifo1MsgPendingCallback`
   - Data is stored in the `data_CAN` buffer with indexing based on message ID
   - Receive flags are set in `receiveFlag` array (index 0-4 for position messages, index 5 for status message)
   - `countCANTime` is updated to track reception time for timeout handling

2. **Command Assembly**:
   - When all 6 messages are received, `commandFlag` is set to 2
   - Checked in `ProcessCANMessage` function by verifying all `receiveFlag` entries are set
   - `receiveFlag` array is cleared after setting `commandFlag` to 2

3. **Data Conversion**:
   - In the main loop, when `commandFlag == 2`, `regenerateData` function is called
   - Converts two-digit position values to actual motor steps
   - Formula: `Step[i] = (datas[2*i] * 10 + datas[2*i+1]) * ratio`
   - State is extracted from `datas[40]`

4. **Motor Control Execution**:
   - Based on the command type (move, home, etc.), appropriate motor control functions are called
   - Motor movements are executed in the timer interrupt handler (TIM4)

## Motor Control Implementation

### Motor Initialization

- 20 motors are initialized with their respective GPIO pins
- Motor parameters (speed, steps) are read from flash memory using `readParameter()` function
- Homing procedure is executed if calibration is enabled (`isCalibrate` = 1)
- Motor VREF is set using DAC to 1.5V

### Position Control

- Position values are received as two-digit decimal numbers
- Converted to actual motor steps using the `ratio` parameter
- `ratio` = (360 * reductionRatio) / (pitch * stepAngle) = (360 * 30) / (12 * 9.3) ≈ 96.77
- In the slave code, this evaluates to approximately 97 steps per unit
- In `regenerateData`, positions are multiplied by `ratio` to get final step count

### Speed Control

Two speed parameters control motor movement:
- **InitMotorSpeed**: Starting speed for movements (default: 2999)
- **HighestSpeed**: Maximum speed during movement (default: 1499)
- Speed is gradually adjusted during movement using timer auto-reload value
- Higher numeric values represent slower speeds (TIM4 auto-reload value)
- Speed adjustment happens in `HAL_TIM_PeriodElapsedCallback` when `htim->Instance == TIM4`

### Homing Procedure

- Triggered when State = 2
- Motors move continuously toward limit switches
- When limit switch is hit, motor steps are reset to 0
- All motors must complete homing before State returns to 0
- Implemented in `StepperMotor_MoveHome` function
- Motor direction is set to move toward limit switch
- When limit switch is detected (GPIO_PIN_RESET), motor is disabled and steps reset to 0

## Temperature Monitoring

- Three NTC temperature sensors are monitored via ADC (channels 0, 1, 5)
- Temperature data is sent to master when changes exceed 1°C for any sensor
- Fan control based on temperature thresholds:
  - FanStartTemperature: Fan turns on (default: 30°C)
  - FanStopTemperature: Motor shuts down to prevent overheating (default: 50°C)
- Temperature checking happens in TIM3 interrupt every period
- Implemented in `HAL_TIM_PeriodElapsedCallback` when `htim->Instance == TIM3`

## Error Handling

- Retransmission requests are sent when data is missing
  - Detected when not all messages received within 10ms
  - Request message contains flags indicating which messages need retransmission
- Error codes are sent for communication failures
  - Sent when no messages received within 20ms
  - Error code 1 indicates CAN error
- Watchdog timer ensures system recovery from lockups
  - Refreshed in TIM5 interrupt every period
  - IWDG timeout value set during initialization

## Integration with Main Application

### Initialization Sequence

1. HAL initialization
2. System clock configuration
3. Peripheral initialization (GPIO, CAN, ADC, DAC, Timers)
4. Slave ID determination from hardware pins
5. CAN interface startup
6. Motor initialization and homing (if enabled)
7. Wait for side ID assignment from master

### Main Loop Operation

1. Process UART commands (if enabled with `isUart` = 1)
2. Handle retransmission requests:
   - When `commandFlag == 1` and timeout (10ms) has elapsed
   - Send retransmission request with missing message flags
3. Process received CAN commands:
   - When `commandFlag == 2`
   - Convert data to motor steps using `regenerateData`
   - Enable motors and set initial speed
4. Execute motor movements based on commands in TIM4 interrupt

### Interrupt Handlers

- **CAN RX Interrupts**: Process incoming messages
  - `HAL_CAN_RxFifo0MsgPendingCallback` (CAN1)
  - `HAL_CAN_RxFifo1MsgPendingCallback` (CAN2)
  - Call `ProcessCANMessage` to handle received data
- **Timer Interrupts**: Execute motor stepping and temperature monitoring
  - TIM2: Microsecond delay generation (not used in main flow)
  - TIM3: Temperature monitoring and fan control
  - TIM4: Motor stepping control
  - TIM5: Watchdog refresh
- **Watchdog Refresh**: Periodic system health check

## Key Data Structures

### Global Variables

- `machine_id`: Slave identifier (0-30), determined by ADD0-ADD4 pins
- `side_id`: CAN interface assignment (0=CAN1, 1=CAN2, 3=unassigned)
- `State`: Operation state (0=idle, 1=moving, 2=homing)
- `data_CAN[48]`: Buffer for received CAN data (8 bytes × 6 messages)
- `receiveFlag[6]`: Flags indicating received message types (0-4 for position, 5 for status)
- `commandFlag`: Status of command assembly (0=none, 1=in progress, 2=complete)
- `Steps[NUM_MOTORS]`: Target positions for each motor (0-19)
- `countCANTime`: Timestamp of last CAN message reception for timeout handling

### Motor Control Structures

- `StepperMotor`: Contains motor state and GPIO pin information
  - `pins`: Structure containing all GPIO pins for the motor
  - `speed`: Current motor speed (timer auto-reload value)
  - `steps`: Current step count
- `StepperMotorPins`: Defines GPIO pins for each motor
  - `dirPort/dirPin`: Direction control
  - `stepPort/stepPin`: Step pulse
  - `sleepPort/sleepPin`: Enable/disable motor
  - `switchPort/switchPin`: Limit switch input
- `MotorSpeed`: Current motor speed during movement
- `InitMotorSpeed`: Starting speed for movements
- `HighestSpeed`: Maximum speed during movements

## Configuration Parameters

### System Constants

- `NUM_SLAVES`: 50 (maximum number of slaves in system)
- `NUM_MOTORS`: 20 (number of motors per slave)
- `pitch`: 12 (leadscrew pitch in mm)
- `reductionRatio`: 30 (gear reduction ratio)
- `stepAngle`: 9.3 (stepper motor step angle in degrees)
- `ratio`: Calculated steps per position unit ≈ 97

### Compile-time Options

- `isTest`: Enable test mode (default: 0)
- `isUart`: Enable UART command interface (default: 0)
- `isCalibrate`: Enable automatic homing at startup (default: 1)
- `TestHeight`: Test movement height (default: 305)
- `TestNumber`: Number of motors to test (default: 20)

## Hardware Dependencies

### GPIO Pins

- ADD0-ADD4: Slave address inputs (active low)
- Motor control pins for direction, step, sleep, and limit switch for each motor
- Fan control pins (FAN1, FAN2)
- Enable pin for motor drivers (EN)
- DAC output for VREF adjustment (DAC1 channel 1)

### Peripherals

- **CAN1/CAN2**: Dual CAN interfaces for communication
  - CAN1: PD0 (RX), PD1 (TX)
  - CAN2: PB12 (RX), PB13 (TX)
- **ADC1**: Temperature sensor inputs (channels 0, 1, 5)
- **DAC1**: Motor driver reference voltage (channel 1)
- **TIM2**: Microsecond delay generation (not actively used)
- **TIM3**: Temperature monitoring (period: configured in initialization)
- **TIM4**: Motor stepping control (period: dynamically adjusted for speed)
- **TIM5**: Watchdog refresh (period: configured in initialization)
- **IWDG**: Independent watchdog timer (timeout: configured in initialization)
- **I2C1**: (Not actively used in current implementation)
- **USART1**: (Optional UART interface for diagnostics)

## Implementation Functions

### CAN Functions (`Core/Src/can.c`)

- `CAN_Start()`: Initialize and start CAN interfaces
- `CANx_SendStdData()`: Send standard CAN message
- `ProcessCANMessage()`: Process received CAN message
- `HAL_CAN_RxFifo0MsgPendingCallback()`: CAN1 message reception handler
- `HAL_CAN_RxFifo1MsgPendingCallback()`: CAN2 message reception handler
- `MX_CAN1_Init()`: Initialize CAN1 with filters
- `MX_CAN2_Init()`: Initialize CAN2 with filters

### Motor Control Functions (`Drivers/Users/Src/motor.c`)

- `StepperMotor_Init()`: Initialize a single motor
- `StepperMotors_Init()`: Initialize all motors
- `StepperMotor_SetDirection()`: Set motor direction
- `StepperMotor_MoveOneStep()`: Execute one step
- `StepperMotor_MoveSteps()`: Move motor to target position
- `StepperMotor_MoveHome()`: Execute homing procedure
- `DAC_OutputValue()`: Set motor driver reference voltage

### Data Processing Functions (`Drivers/Users/Src/data.c`)

- `parseJson()`: Parse JSON commands from UART
- `regenerateData()`: Convert CAN data to motor steps

### Global Functions (`Drivers/Users/Src/global.c`)

- `GetMachineID()`: Determine slave ID from hardware pins

This comprehensive overview documents all aspects of the slave implementation that need to be replicated in the mit-motor-controller codebase.