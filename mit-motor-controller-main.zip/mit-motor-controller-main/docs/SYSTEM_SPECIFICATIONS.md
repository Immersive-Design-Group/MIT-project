# System Specifications

## Overview

This document describes the CAN communication protocol used in the art installation system. The system consists of a master controller and multiple slave motor controller boards. Each slave board controls 8 motors for a total of 64 motors across 8 boards.

## CAN Protocol

### Physical Layer

The CAN bus operates at approximately 1 Mbps using the JSM65HV230 transceiver. The master controller uses dual CAN interfaces (CAN1 and CAN2) for redundancy and load balancing.

### Message Structure

All CAN messages use 8-byte data payloads with the following structure variations:

#### Slave Data Messages
- **Message ID**: `slave_id * 6 + [1-6]` (where slave_id is 0-49)
- **Data**: 4 motor positions (2 bytes each)
  - Bytes 0-1: Motor 1 position (high byte, low byte)
  - Bytes 2-3: Motor 2 position
  - Bytes 4-5: Motor 3 position
  - Bytes 6-7: Motor 4 position

#### Slave Status Messages
- **Message ID**: `slave_id * 6 + 6`
- **Data**: Status information
  - Byte 0: Status/Command Code
  - Bytes 1-6: Reserved
  - Byte 7: Message Type Identifier

#### Control Messages
- **Message ID**: `NUM_SLAVES * 6 + [1-7]` (typically 301-307)
- **Data**: Command data
  - Bytes 0-6: Command data
  - Byte 7: Message Type Identifier

### Message Types (Byte 7 Identifier)

1. `0` - Retransmission request
2. `1` - Initialization status
3. `3` - Temperature data
4. `4` - Homing command
5. `5` - Speed control command
6. `7` - LED Color Control Command (replaces Temperature Threshold Settings)

### Command Codes (Byte 0 in Status Messages)

1. `3` - Initialization complete
2. `4` - Homing command
3. `5` - Speed control
4. `6` - Test command
5. `7` - LED Color Control Command (replaces Temperature Threshold Settings)

### Position Data Format

Position values are sent as two-digit numbers where:
- The first digit is the tens place
- The second digit is the units place
- For example, a value of 123 would be split into 12 and 3

The position values represent 1/10 mm units, so a value of 100 represents 10.0 mm.

### Speed Command Format

Speed commands (code 5) contain:
- Byte 0: Command code (5)
- Byte 1: High byte of initial speed
- Byte 2: Low byte of initial speed
- Byte 3: High byte of high speed
- Byte 4: Low byte of high speed

### LED Color Control Command Format

LED Color Control commands (code 7) contain:
- Byte 0: Command code (7)
- Byte 1: Must be 0 (to distinguish from temperature command)
- Byte 2: Motor index (1-8)
- Byte 3: Red value (0-255)
- Byte 4: Green value (0-255)
- Byte 5: Blue value (0-255)
- Bytes 6-7: Reserved (should be 0)

This command replaces the original Temperature Threshold Settings command to provide artistic LED control.

## System Behavior

### Initialization Sequence

1. Master sends initialization command
2. Slave responds with status code 3
3. Master acknowledges initialization

### Retransmission Mechanism

When a slave receives a retransmission request (identifier 0):
1. It checks which data packets are missing
2. Resends only the missing packets
3. Updates its transmission status

### Homing Procedure

The master can send a homing command (code 4) to initiate homing on a slave:
1. Slave performs CCW movement at 2 mm/s until limit switch is hit
2. Backs off from limit switch
3. Approaches limit switch at 0.5 mm/s for accurate positioning
4. Resets position counter when homing is complete

### Temperature Monitoring

Slaves can send temperature data to the master:
- Motor temperature
- Hot air temperature
- PCB temperature

### LED Color Control

Slaves can receive LED color control commands from the master:
1. Each motor has an individually controllable WS2812B LED
2. LED colors can be set using RGB values (0-255 for each component)
3. Predefined color codes are also supported for convenience
4. This feature replaces the original temperature threshold settings command

## Timing Requirements

- CAN bus operates at 1 Mbps
- Slaves should respond to commands within a few milliseconds
- Position updates should be sent periodically based on system requirements

## Error Handling

The system uses several error handling mechanisms:
1. CRC checking on CAN messages
2. Retransmission requests for missing data
3. Status reporting for error conditions
4. Watchdog timers to detect system lockups

## Network Communication

The master controller also provides TCP/IP connectivity on port 5000:
- JSON-based command protocol
- Real-time status reporting
- Remote control capabilities

### JSON Command Format

```json
{
  "i": 0,           // Slave ID (0-49)
  "s": 1,           // State/command (0-9)
  "h": [100, 200]   // Array of motor heights/positions
}
```

Commands can be concatenated with semicolons for batch operations.