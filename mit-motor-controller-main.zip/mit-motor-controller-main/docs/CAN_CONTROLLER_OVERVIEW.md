# CAN Controller Implementation Overview

This document provides a comprehensive overview of the CAN master controller implementation in the can_stm32 codebase. This serves as a reference for understanding how the master communicates with slave modules in the CAN-based motor control system.

## System Architecture

The CAN master controller is implemented on an STM32F407 microcontroller and serves as the central coordinator for up to 50 slave modules. Each slave can control up to 20 motors, allowing for large-scale distributed motor control.

### Hardware Components

1. **STM32F407 Microcontroller** - Main processing unit
2. **Dual CAN Bus Controllers (CAN1 and CAN2)** - For communication with slave modules
3. **Ethernet Interface (W5500)** - For TCP/IP communication
4. **SPI Interface** - For communication with the W5500 Ethernet controller
5. **UART Interface** - For serial communication/debugging
6. **GPIOs** - For control signals and status indicators

### Key Features

- CAN bus communication with up to 50 slave modules
- TCP/IP interface for remote control on port 5000
- JSON-based command parsing
- Real-time motor control and monitoring
- Temperature monitoring of slave modules
- Retransmission mechanism for reliable communication

## CAN Communication Protocol

### CAN Bus Configuration

Both CAN controllers are configured identically:
- **Prescaler**: 12
- **Time Segment 1**: 7 time quanta
- **Time Segment 2**: 6 time quanta
- **Synchronization Jump Width**: 1 time quantum
- **Mode**: Normal operation
- **Baud Rate**: Approximately 1 Mbps (168MHz / 12 / (1+7+6) = 1MHz)

### Message Structure

All CAN messages use 8-byte data payloads with structured formats:

#### Slave Data Messages (ID = slave_id * 6 + [1-5])
```
Byte 0-7: 4 motor positions (2 bytes each)
  - Bytes 0-1: Motor 1 position (tens digit, units digit)
  - Bytes 2-3: Motor 2 position (tens digit, units digit)
  - Bytes 4-5: Motor 3 position (tens digit, units digit)
  - Bytes 6-7: Motor 4 position (tens digit, units digit)
```
Example: To send position 123 to motor 1, bytes would be [12, 3, ...]

#### Slave Status Messages (ID = slave_id * 6 + 6)
```
Byte 0: Status/Command Code
Bytes 1-6: Reserved or command-specific data
Byte 7: Message Type Identifier
```

#### Control Messages (ID = NUM_SLAVES * 6 + [1-7])
```
Bytes 0-6: Command data
Byte 7: Message Type Identifier
```

### Message Types (Byte 7 Identifier)

1. `0` - Retransmission request
2. `1` - Initialization status
3. `3` - Temperature data
4. `4` - Homing command
5. `5` - Speed control command
6. `7` - Temperature threshold settings

### Status/Command Codes (Byte 0 in Status Messages)

1. `3` - Initialization complete
2. `4` - Homing command
3. `5` - Speed control
4. `6` - Test command
5. `7` - Temperature threshold settings

### Command Codes (Byte 0 in Control Messages)

1. `4` - Homing command
2. `5` - Speed control command
   - Bytes 1-2: Initial speed (high byte, low byte)
   - Bytes 3-4: High speed (high byte, low byte)
3. `7` - Temperature threshold settings
   - Byte 1: Start fan temperature
   - Byte 2: Close motor temperature

## Network Interface

The system provides TCP/IP connectivity through a W5500 Ethernet controller on port 5000.

### JSON Command Format
```json
{
  "i": 0,           // Slave ID (0-49)
  "s": 1,           // State/command (0-9)
  "h": [100, 200]   // Array of motor heights/positions
}
```

Commands can be concatenated with semicolons for batch operations.

### Supported Commands (State/Command values)

- `s: 1` - Move motors to specified positions
- `s: 2` - Move motors to home position (not working in current implementation)
- `s: 3` - Check initialization state
- `s: 4` - Set side (auto) - removed from current implementation
- `s: 5` - Set motor speed
- `s: 6` - Test mode
- `s: 7` - Set fan operating temperature

## Software Architecture

### Main Components

1. **main.c** - Application entry point and main loop
2. **can.c** - CAN bus initialization and message handling
3. **data.c** - Data processing and JSON parsing
4. **MYw5500.c** - Ethernet/W5500 interface
5. **global.h** - Global definitions and constants

### Key Functions

#### CAN Functions (in `Core/Src/can.c`)

- `CAN_Start()` - Initialize and start both CAN buses
  - Activates notification for RX FIFO 0 and 1
  - Starts both CAN1 and CAN2 interfaces
  
- `CANx_SendStdData(CAN_HandleTypeDef* hcan, uint16_t ID, uint8_t* pData, uint8_t Len)` - Send standard CAN messages
  - Configures CAN header with standard ID, data length, and data
  - Waits for available transmit mailbox
  - Sends message using HAL CAN API

- `HAL_CAN_RxFifo0/1MsgPendingCallback(CAN_HandleTypeDef* hcan)` - Handle incoming CAN messages
  - Retrieves message from appropriate FIFO
  - Processes message based on ID and data content
  - Handles different message types:
    - Identifier 0: Retransmission requests
    - Identifier 1: Initialization status
    - Identifier 3: Temperature data
    - Identifier 4: Homing commands
    
- `MX_CAN1/2_Init()` - Initialize CAN controllers with appropriate filters
  - Configures CAN timing parameters
  - Sets up filter banks for message filtering
  - Uses ID list mode for exact message ID matching
  - Assigns filters to appropriate FIFOs

#### Data Processing (in `Drivers/Users/Src/data.c`)

- `parseJson(const char* const jsonString, uint16_t (*Step)[NUM_MOTORS + 1], uint8_t* const flag)` - Parse incoming JSON commands
  - Uses cJSON library for JSON parsing
  - Validates machine ID and state values
  - Extracts height/position data for specified slave
  - Handles different command types (position, speed settings)

- `parseData(char* const dataString)` - Process command strings
  - Tokenizes semicolon-separated commands
  - Calls parseJson for each command
  - Triggers appropriate slave communication based on command type

- `sendSlaveHeight(const uint16_t slave_id, const uint16_t* const Step)` - Send motor position data to slaves
  - Converts 16-bit position values to two-digit format
  - Sends 5 data messages (ID = slave_id * 6 + [1-5])
  - Sends status message (ID = slave_id * 6 + 6)

- `sendSlaveSpeed(uint16_t init_speed_h, uint16_t init_speed_l, uint16_t high_speed_h, uint16_t high_speed_l)` - Send speed control commands
  - Sends control message with command code 5
  - ID = NUM_SLAVES * 6 + 7
  - Data format: [5, init_speed_h, init_speed_l, high_speed_h, high_speed_l, 0, 0, 5]

- `sendSlaveTemperature(uint16_t start_fan_temperature, uint16_t close_motor_temperature)` - Send temperature threshold settings
  - Sends control message with command code 7
  - ID = NUM_SLAVES * 6 + 7
  - Data format: [7, start_fan_temperature, close_motor_temperature, 0, 0, 0, 0, 7]

- `sendSlaveCheck(CAN_HandleTypeDef* hcan, uint8_t slave_id)` - Send homing command to slave
  - Sends control message with command code 4
  - ID = NUM_SLAVES * 6 + 7
  - Data format: [4, 0, 0, 0, 0, 0, 0, 4]

- `sendSlaveEachHeight()` - Handle retransmission requests
  - Sends only requested data packets based on flags
  - Used when slave requests specific messages to be resent

#### Network Functions (in various network-related files)

- `W5500_ChipInit()` - Initialize Ethernet controller
- TCP server implementation using socket state machine
- Message handling for different socket states (INIT, LISTEN, ESTABLISHED, etc.)

### Global Variables and Constants (in `Drivers/Users/Inc/global.h`)

- `NUM_SLAVES`: 50 (Maximum number of slave modules)
- `NUM_MOTORS`: 20 (Motors per slave module)
- `FanStopTemperature`: 55°C (Temperature threshold for fan operation)
- `dataArray[NUM_SLAVES][NUM_MOTORS + 1]`: Storage for motor position data
- `StateArray[NUM_SLAVES]`: Slave state tracking
- `TemperatureArray[NUM_SLAVES][4]`: Temperature data from slaves
- `TestArray[NUM_SLAVES]`: Test mode status for slaves

### Timers

1. **TIM2** - Used for state management
2. **TIM3** - Periodic test operations
3. **TIM4** - Watchdog refresh

## Operation Flow

### System Initialization

1. MCU and peripheral initialization through HAL
2. CAN bus startup with `CAN_Start()`
3. Ethernet controller initialization with `W5500_ChipInit()`
4. Timer initialization for periodic operations
5. GPIO configuration for control signals

### Main Loop Operation

1. Monitor TCP/IP connection for commands
   - Handle socket state transitions
   - Process incoming JSON commands
   - Send responses and status updates to TCP client

2. Parse and process JSON commands
   - Validate command syntax and parameters
   - Extract slave ID, command type, and data
   - Store data in appropriate arrays

3. Send appropriate CAN messages to slave modules
   - Based on command type, call appropriate send functions
   - Distribute messages between CAN1 and CAN2 for load balancing

4. Handle incoming CAN messages from slaves
   - Process initialization status messages
   - Handle temperature data reports
   - Respond to retransmission requests

### CAN Message Processing

When receiving messages from slaves:
- **Identifier 0**: Retransmission requests
  - Parse slave ID and missing packet flags
  - Resend requested data packets with `sendSlaveEachHeight()`
  
- **Identifier 1**: Initialization status
  - Update `StateArray` for the slave
  - Set `StateFlag[0]` to trigger status reporting
  
- **Identifier 3**: Temperature data
  - Update `TemperatureArray` with received values
  - Set `StateFlag[1]` to trigger temperature reporting
  
- **Identifier 4**: Homing commands
  - Call `sendSlaveCheck()` to send homing command back to slave

### Network Communication

1. Server listens for incoming TCP connections on port 5000
2. Parses JSON commands from client
3. Validates command format and parameters
4. Stores command data in global arrays
5. Triggers appropriate CAN communication to slave modules
6. Sends responses and status updates to connected client

## Error Handling

### CAN Bus Error Handling

- Through HAL error callbacks and return value checking
- Retransmission mechanism for handling message loss
- Timeout handling for missing messages
- Error reporting to TCP client

### Network Error Handling

- Connection state management
- Socket error detection and recovery
- Data validation in JSON parsing
- Graceful handling of network disconnections

### System-Level Error Handling

- Watchdog timer refresh to prevent system lockup
- Data validation at multiple levels
- Error state reporting to connected clients

## Configuration Constants

- `NUM_SLAVES`: 50 (Maximum number of slave modules)
- `NUM_MOTORS`: 20 (Motors per slave module)
- `FanStopTemperature`: 55°C (Temperature threshold for fan operation)

## Development Environment

- STM32CubeIDE for development
- HAL (Hardware Abstraction Layer) library
- C programming language
- W5500 Ethernet controller driver
- cJSON library for JSON parsing

This comprehensive overview documents all aspects of the CAN master controller implementation, providing sufficient detail to understand the system without needing to refer to the source code.