# MIT Motor Controller Implementation Checklist

This document provides a detailed checklist for implementing CAN slave functionality in the mit-motor-controller. It tracks progress through all phases of the implementation.

## Phase 1: CAN Communication Layer Implementation

### CAN Handle Declarations
- [ ] Add `CAN_HandleTypeDef hcan1` to main.c (only one CAN interface)
- [ ] Include necessary headers in main.c

### CAN Header File
- [ ] Create `Core/Inc/can_slave.h`
- [ ] Define function prototypes for CAN initialization and message handling
- [ ] Declare external variables (hcan1)

### CAN Initialization Functions
- [ ] Create `Core/Src/can_slave.c`
- [ ] Implement `MX_CAN1_Init()` with proper configuration:
  - [ ] Prescaler: 12
  - [ ] TimeSeg1: 7
  - [ ] TimeSeg2: 6
  - [ ] SJW: 1
  - [ ] Mode: Normal
  - [ ] All advanced features disabled (matching slave implementation)
- [ ] Add proper GPIO initialization for CAN pins (PD0/PD1 for CAN1 RX/TX)

### CAN Start Function
- [ ] Implement `CAN_Slave_Start()` function
- [ ] Initialize and start CAN interface
- [ ] Activate notification for RX FIFO 0

### Message Transmission
- [ ] Implement `CAN_Slave_SendMessage()` function
- [ ] Handle mailbox management and error checking
- [ ] Match the implementation in the slave project

### CAN Filter Configuration
- [ ] Configure filters based on machine_id
- [ ] Use ID list mode for exact message ID matching
- [ ] Assign appropriate IDs to FIFO0

### CAN Interrupt Handlers
- [ ] Add `HAL_CAN_RxFifo0MsgPendingCallback()` 
- [ ] Create common message processing function

### Integration in Main
- [ ] Add CAN initialization to startup sequence in main()
- [ ] Enable CAN interrupts
- [ ] Call `CAN_Slave_Start()` after peripheral initialization

### Testing
- [ ] Verify CAN initialization without errors
- [ ] Test basic message transmission
- [ ] Verify proper message filtering

## Phase 2: Slave Identification System

### Global Variables
- [ ] Create `Core/Inc/global.h`
- [ ] Add declarations for `machine_id`, `NUM_SLAVES` (50), `NUM_MOTORS` (8 for our setup)
- [ ] Add `side_id` and `State` variables

### Global Implementation
- [ ] Create `Core/Src/global.c`
- [ ] Implement `GetMachineID()` function
- [ ] Hardcode machine_id (0-7) for our setup

### Integration with CAN Configuration
- [ ] Modify CAN filter configuration to use machine_id
- [ ] Ensure proper message filtering based on slave ID

### Testing
- [ ] Verify machine_id is properly set
- [ ] Confirm CAN filters work correctly with slave ID

## Phase 3: Data Processing and Command Handling

### Data Structures
- [ ] Add `data_CAN[48]` buffer to store received messages
- [ ] Add `receiveFlag[6]` array to track received message types
- [ ] Add `commandFlag` variable to track command assembly status

### Message Processing
- [ ] Implement `ProcessCANMessage()` function
- [ ] Handle position commands (ID = machine_id * 6 + [1-5])
- [ ] Handle status messages (ID = machine_id * 6 + 6)
- [ ] Handle LED color control commands (ID = machine_id * 6 + 7) - REPLACES TEMPERATURE COMMAND
- [ ] Handle control messages (ID = NUM_SLAVES * 6 + 7)
- [ ] Implement proper data storage in `data_CAN` buffer

### Data Processing Functions
- [ ] Create `Core/Inc/data.h`
- [ ] Create `Core/Src/data.c`
- [ ] Implement `regenerateData()` function to convert CAN data to motor steps
- [ ] Add position tracking variables

### Integration with Main Loop
- [ ] Modify main loop to check `commandFlag`
- [ ] Process completed commands when `commandFlag == 2`
- [ ] Call `regenerateData()` to convert received data to motor positions

### Testing
- [ ] Verify message processing works correctly
- [ ] Test data conversion from CAN format to motor steps
- [ ] Confirm integration with main application loop

## Phase 4: Motor Control Integration

### Integration with Motion Control
- [ ] Modify main loop to execute movements when position commands are received
- [ ] Connect motor position targets to `Motion_move()` functions
- [ ] Ensure proper conversion from 1/10mm units to motor steps (80 steps per 1/10mm)

### Homing Command Handling
- [ ] Add State variable handling (0=idle, 1=moving, 2=homing)
- [ ] Implement homing command processing in message handler
- [ ] Connect to existing homing procedures in motion control

### Speed Parameter Handling
- [ ] Add `InitMotorSpeed` and `HighestSpeed` variables
- [ ] Implement speed command handling
- [ ] Connect speed parameters to motion control system

### Position Tracking
- [ ] Add position tracking to motion control system
- [ ] Ensure positions are properly updated during movement
- [ ] Reset positions during homing

### Testing
- [ ] Test position command execution
- [ ] Verify homing procedure activation
- [ ] Test speed parameter control
- [ ] Confirm position tracking works correctly

## Phase 5: Status Reporting System

### Status Reporting Functions
- [ ] Implement initialization status reporting
- [ ] Add functions to send status messages to master
- [ ] Match message formats from the slave implementation

### Periodic Status Updates
- [ ] Add periodic status reporting in main loop or timer interrupt
- [ ] Implement state reporting based on operation mode

### Retransmission Response Handling
- [ ] Implement retransmission request processing
- [ ] Add functions to resend requested data packets
- [ ] Track transmission status for each packet

### Testing
- [ ] Verify initialization status reporting
- [ ] Test periodic status updates
- [ ] Confirm retransmission handling works correctly

## Phase 6: LED Color Control Implementation

### LED Color Control Functions
- [ ] Create `setMotorLEDColor()` function to set individual motor LED colors
- [ ] Add predefined color palette (red, green, blue, white, yellow, etc.)
- [ ] Add support for direct RGB values (0-255)

### Update Message Processing for LED Commands
- [ ] Modify `ProcessCANMessage()` to handle LED color commands (s=7)
- [ ] Implement special format detection (bytes 0-1 = 0) to distinguish from temperature commands
- [ ] Validate motor index (1-8) and color values

### Integrate with WS2812B Driver
- [ ] Connect LED color setting to existing WS2812B driver
- [ ] Map motor indices to specific LED channels
- [ ] Implement color setting for each motor's LED

### Add LED Color Command Handling
- [ ] Update `regenerateData()` function to handle LED color commands
- [ ] Add LED color tracking variables

### Testing
- [ ] Verify LED color control via CAN commands
- [ ] Test palette and direct RGB color values
- [ ] Confirm motor index mapping is correct
- [ ] Test special format detection

## Phase 7: Physical Switch Integration

### Switch Monitoring
- [ ] Add periodic switch state checking in main loop
- [ ] Use existing `IO_DigitalRead()` functions to read switch states

### Motor Override
- [ ] Override CAN commands when physical switches are pressed
- [ ] Implement motor control for UP/DOWN switches
- [ ] Use pre-defined speed for switch operations

### Position Limits
- [ ] Ensure motors stop at 0mm and 200mm positions
- [ ] Even when physical switches are still pressed

### Testing
- [ ] Verify switch state detection
- [ ] Test motor override functionality
- [ ] Confirm position limit enforcement

## Phase 8: Speed Calibration

### Safe Starting Speeds
- [ ] Implement conservative starting speed values
- [ ] Default: InitMotorSpeed=3000, HighestSpeed=1500

### Testing and Optimization
- [ ] Test movement accuracy and smoothness
- [ ] Gradually adjust speeds while monitoring performance
- [ ] Determine optimal values for the specific hardware

### Validation
- [ ] Verify calibrated speed parameters
- [ ] Confirm movement performance

## Phase 9: System Integration and Testing

### System Integration
- [ ] Ensure all components work together seamlessly
- [ ] Verify proper initialization sequence
- [ ] Check timing and performance

### Functional Testing
- [ ] Test position commands from master
- [ ] Verify homing procedure activation
- [ ] Test speed parameter control
- [ ] Validate status reporting
- [ ] Test physical switch override functionality
- [ ] Test LED color control via CAN commands

### Error Handling Testing
- [ ] Test retransmission mechanism
- [ ] Verify error reporting
- [ ] Check system recovery from error conditions

### Performance Optimization
- [ ] Optimize timing and responsiveness
- [ ] Reduce latency in command execution
- [ ] Ensure reliable communication

## Phase 10: Documentation and Finalization

### Documentation Updates
- [ ] Update MIT_MOTOR_CONTROLLER_OVERVIEW.md with implementation details
- [ ] Add usage instructions
- [ ] Document any deviations from the plan

### Code Cleanup
- [ ] Remove unused/commented code
- [ ] Ensure consistent code style
- [ ] Add necessary comments

### Final Testing
- [ ] Perform complete system test
- [ ] Verify all features work as expected
- [ ] Document any remaining issues

## Overall Progress Tracking

### Phase Completion
- [ ] Phase 1: CAN Communication Layer Implementation
- [ ] Phase 2: Slave Identification System
- [ ] Phase 3: Data Processing and Command Handling
- [ ] Phase 4: Motor Control Integration
- [ ] Phase 5: Status Reporting System
- [ ] Phase 6: LED Color Control Implementation
- [ ] Phase 7: Physical Switch Integration
- [ ] Phase 8: Speed Calibration
- [ ] Phase 9: System Integration and Testing
- [ ] Phase 10: Documentation and Finalization

### Feature Completion
- [ ] CAN message transmission
- [ ] CAN message reception
- [ ] Message filtering
- [ ] Slave identification
- [ ] Position command handling
- [ ] Homing command handling
- [ ] Speed control
- [ ] Status reporting
- [ ] Retransmission handling
- [ ] LED color control (replaces temperature command)
- [ ] Physical switch integration
- [ ] Speed calibration

This checklist provides a comprehensive tracking system for the MIT Motor Controller implementation, ensuring all tasks are completed and verified.