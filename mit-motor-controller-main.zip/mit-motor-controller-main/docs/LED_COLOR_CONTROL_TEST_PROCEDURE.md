# LED Color Control Test Procedure

This document provides a comprehensive test procedure for the LED color control feature that replaces the temperature command in the CAN motor control system.

## Overview

The LED color control feature allows individual motor LEDs to be controlled via CAN commands, replacing the original temperature command (s=7). This provides an artistic element while maintaining system functionality.

## Test Environment Setup

### Required Hardware
1. MIT Motor Controller board with WS2812B LEDs installed
2. CAN interface connected to the controller (PD0/PD1 for CAN1 RX/TX)
3. Network connection to the master controller
4. PC with network access to send test commands
5. Oscilloscope or logic analyzer (optional, for CAN bus verification)

### Required Software
1. Terminal application (PuTTY, Tera Term, etc.) for serial communication
2. Network utility (telnet, netcat, or custom script) for sending commands
3. CAN bus analyzer software (if available)

## Test Cases

### 1. Basic LED Color Control

#### Test Objective
Verify that basic LED color control commands work correctly.

#### Test Procedure
1. Power on the MIT Motor Controller
2. Establish network connection to the master controller
3. Send single LED color command for each predefined color:
   ```json
   // Off
   {"i":0,"s":7,"h":[0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
   
   // Red
   {"i":0,"s":7,"h":[0,0,1,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
   
   // Green
   {"i":0,"s":7,"h":[0,0,1,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
   
   // Blue
   {"i":0,"s":7,"h":[0,0,1,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
   
   // White
   {"i":0,"s":7,"h":[0,0,1,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
   
   // Yellow
   {"i":0,"s":7,"h":[0,0,1,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
   
   // Cyan
   {"i":0,"s":7,"h":[0,0,1,0,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
   
   // Magenta
   {"i":0,"s":7,"h":[0,0,1,255,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
   
   // Orange
   {"i":0,"s":7,"h":[0,0,1,255,165,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
   
   // Purple
   {"i":0,"s":7,"h":[0,0,1,128,0,128,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
   
   // Pink
   {"i":0,"s":7,"h":[0,0,1,255,192,203,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
   ```

#### Expected Results
1. LED for motor 1 changes to specified color after each command
2. LED turns off when "Off" command is sent
3. LED displays correct RGB values for each color
4. No errors or unexpected behavior

#### Pass Criteria
- Each LED color change occurs within 100ms of command receipt
- LED brightness is consistent across all colors
- No flickering or instability in LED output
- No interference with motor control functions

### 2. All Motor LEDs Control

#### Test Objective
Verify that LED color commands work for all 8 motors on a slave.

#### Test Procedure
1. Send LED color commands for motors 1-8:
   ```json
   // Set different colors for all 8 motors
   {"i":0,"s":7,"h":[0,0,1,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};  // Motor 1 - Red
   {"i":0,"s":7,"h":[0,0,2,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};  // Motor 2 - Green
   {"i":0,"s":7,"h":[0,0,3,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};  // Motor 3 - Blue
   {"i":0,"s":7,"h":[0,0,4,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};  // Motor 4 - White
   {"i":0,"s":7,"h":[0,0,5,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};  // Motor 5 - Yellow
   {"i":0,"s":7,"h":[0,0,6,0,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};  // Motor 6 - Cyan
   {"i":0,"s":7,"h":[0,0,7,255,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};  // Motor 7 - Magenta
   {"i":0,"s":7,"h":[0,0,8,255,165,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};  // Motor 8 - Orange
   ```

#### Expected Results
1. Each motor's LED displays the correct color
2. All 8 LEDs are lit with their respective colors
3. No cross-talk between motor LEDs
4. No interference with motor control functions

#### Pass Criteria
- All 8 motor LEDs display their assigned colors correctly
- No delay greater than 100ms between command receipt and LED change
- No flickering or instability in LED output
- No impact on motor control performance

### 3. Multiple Slave LED Control

#### Test Objective
Verify that LED color commands work correctly across multiple slaves.

#### Test Procedure
1. If multiple slaves are available, send LED color commands to each:
   ```json
   // Set LED color on slave 0, motor 1
   {"i":0,"s":7,"h":[0,0,1,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   
   // Set LED color on slave 1, motor 1
   {"i":1,"s":7,"h":[0,0,1,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   
   // Set LED color on slave 2, motor 1
   {"i":2,"s":7,"h":[0,0,1,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   ```

#### Expected Results
1. Each slave's motor 1 LED displays the correct color
2. No cross-talk between slaves
3. Commands are properly filtered by slave ID
4. No interference with motor control functions

#### Pass Criteria
- Each slave correctly responds only to commands addressed to its ID
- LED colors are displayed correctly on each slave
- No delay greater than 100ms between command receipt and LED change
- No impact on motor control performance

### 4. Edge Cases and Error Handling

#### Test Objective
Verify proper handling of edge cases and invalid commands.

#### Test Procedure
1. Send invalid motor index:
   ```json
   // Invalid motor index (0)
   {"i":0,"s":7,"h":[0,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   
   // Invalid motor index (9)
   {"i":0,"s":7,"h":[0,0,9,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   ```

2. Send invalid RGB values:
   ```json
   // RGB values exceeding 255
   {"i":0,"s":7,"h":[0,0,1,300,300,300,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   ```

3. Send command with incorrect format (not distinguishing from temperature command):
   ```json
   // Non-zero bytes 0-1 (temperature command format)
   {"i":0,"s":7,"h":[1,0,1,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   ```

#### Expected Results
1. Invalid motor indices are rejected
2. Invalid RGB values are clamped or rejected
3. Temperature command format is properly distinguished from LED command format
4. No adverse effects on system operation

#### Pass Criteria
- Invalid commands are properly rejected or handled gracefully
- System continues normal operation after invalid commands
- No crashes or unexpected behavior
- Appropriate error handling or ignoring of invalid commands

### 5. Integration with Motor Control

#### Test Objective
Verify that LED color control does not interfere with motor control operations.

#### Test Procedure
1. Send LED color commands while motors are moving:
   ```json
   // Send position command
   {"i":0,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]};
   
   // During motor movement, send LED color command
   {"i":0,"s":7,"h":[0,0,1,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   ```

2. Send LED color commands while homing:
   ```json
   // Send homing command
   {"i":0,"s":1,"h":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   
   // During homing, send LED color command
   {"i":0,"s":7,"h":[0,0,1,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   ```

#### Expected Results
1. LED color changes occur without affecting motor movement
2. Motor control operations continue normally
3. No timing conflicts between LED control and motor control
4. No degradation in motor control performance

#### Pass Criteria
- LED color changes occur without impacting motor control
- Motor movements execute correctly regardless of LED commands
- No noticeable delay in motor control operations
- System maintains stable operation during concurrent LED and motor control

### 6. Performance Testing

#### Test Objective
Verify LED color control performance meets system requirements.

#### Test Procedure
1. Send rapid sequence of LED color commands:
   ```json
   // Rapid color changes
   {"i":0,"s":7,"h":[0,0,1,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   {"i":0,"s":7,"h":[0,0,1,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   {"i":0,"s":7,"h":[0,0,1,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   {"i":0,"s":7,"h":[0,0,1,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   ```

2. Send simultaneous LED color commands to multiple motors:
   ```json
   // Set all motor LEDs rapidly
   {"i":0,"s":7,"h":[0,0,1,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   {"i":0,"s":7,"h":[0,0,2,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   {"i":0,"s":7,"h":[0,0,3,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   {"i":0,"s":7,"h":[0,0,4,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   {"i":0,"s":7,"h":[0,0,5,255,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   {"i":0,"s":7,"h":[0,0,6,0,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   {"i":0,"s":7,"h":[0,0,7,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   {"i":0,"s":7,"h":[0,0,8,255,165,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};
   ```

#### Expected Results
1. LED color changes occur rapidly without delays
2. All LED commands are processed in sequence
3. No missed or dropped LED commands
4. Consistent timing between commands

#### Pass Criteria
- LED color changes occur within 100ms of command receipt
- No dropped or missed commands
- Consistent timing between consecutive commands
- No buffer overflow or memory issues with rapid commands

## Test Execution

### Test Sequence
1. Execute Basic LED Color Control test
2. Execute All Motor LEDs Control test
3. Execute Multiple Slave LED Control test (if multiple slaves available)
4. Execute Edge Cases and Error Handling test
5. Execute Integration with Motor Control test
6. Execute Performance Testing

### Test Data Collection
1. Record timestamp of each command sent
2. Record timestamp of each LED color change
3. Note any errors or unexpected behavior
4. Document any deviations from expected results

### Test Metrics
1. Command-to-response time (should be <100ms)
2. Success rate of LED color changes (should be 100%)
3. Impact on motor control performance (should be negligible)
4. Error handling effectiveness (should properly reject invalid commands)

## Troubleshooting

### Common Issues
1. **LED Not Changing Color**
   - Verify WS2812B LED connections
   - Check power supply to LEDs
   - Verify LED command format
   - Check for software errors in LED control implementation

2. **Incorrect Colors Displayed**
   - Verify RGB value ordering in command
   - Check LED driver implementation
   - Verify LED color mapping

3. **Delayed LED Response**
   - Check for processing delays in main loop
   - Verify CAN message processing priority
   - Check for buffer overflows

4. **LED Interference with Motor Control**
   - Verify LED control doesn't block motor control execution
   - Check timing of LED updates
   - Ensure LED updates occur in background or during idle periods

### Debugging Tips
1. Use serial output to trace command processing
2. Add LED status indicators to show command receipt
3. Monitor CAN bus traffic to verify command transmission
4. Use oscilloscope to verify LED signal timing

This test procedure provides a comprehensive framework for validating the LED color control feature in the CAN motor control system.