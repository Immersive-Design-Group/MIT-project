# JSON Command Format for CAN Motor Control System

This document details the JSON command format used in the CAN-based motor control system and provides specific instructions for creating and sending test data for a setup with 8 motors per slave and 8 slaves.

## JSON Command Structure

All commands use the following JSON format:

```json
{
  "i": 0,           // Slave ID (0-49 for standard system, 0-7 for our setup)
  "s": 1,           // State/command (0-9)
  "h": [100, 200]   // Array of motor positions/parameters
}
```

Multiple commands can be concatenated with semicolons for batch operations.

## Command Types

### Position Commands (s: 1)

Moves motors to specified positions in 1/10 mm units.

Format:
```json
{"i": slave_id, "s": 1, "h": [pos1, pos2, ..., pos8, 0, 0, ..., 0]}
```

Details:
- `slave_id`: ID of the target slave (0-7 for our setup)
- `pos1` through `pos8`: Target positions for motors 1-8 (0-2000 representing 0.0-200.0mm)
- Remaining positions (9-20) must be 0

Example for slave 0:
```json
{"i":0,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]}
```

### Initialization Check (s: 3)

Requests initialization status from a slave.

Format:
```json
{"i": slave_id, "s": 3, "h": [0, 0, ..., 0]}
```

Example:
```json
{"i":0,"s":3,"h":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
```

### Speed Control (s: 5)

Sets motor speeds for all slaves.

Format:
```json
{"i": slave_id, "s": 5, "h": [init_speed_h, init_speed_l, high_speed_h, high_speed_l, 0, 0, ..., 0]}
```

Details:
- `init_speed_h`: High byte of initial speed (e.g., 29 for 2999)
- `init_speed_l`: Low byte of initial speed (e.g., 99 for 2999)
- `high_speed_h`: High byte of high speed (e.g., 14 for 1499)
- `high_speed_l`: Low byte of high speed (e.g., 99 for 1499)
- Speed values: 4-digit numbers where first two digits are high byte, last two are low byte
- Typically sent once to slave 0 to set system-wide speeds

Example:
```json
{"i":0,"s":5,"h":[29,99,14,99,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
```

### Test Mode (s: 6)

Activates test mode for a slave.

Format:
```json
{"i": slave_id, "s": 6, "h": [0, 0, ..., 0]}
```

Example:
```json
{"i":0,"s":6,"h":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
```

### LED Color Control (s: 7) - REPLACES TEMPERATURE COMMAND

Sets LED colors for motors on a slave. This command replaces the original temperature control command.

Format:
```json
{"i": slave_id, "s": 7, "h": [0, 0, motor_index, r, g, b, 0, 0, ..., 0]}
```

Details:
- `motor_index`: Index of the motor (1-8) to set LED color for
- `r`: Red component (0-255)
- `g`: Green component (0-255)
- `b`: Blue component (0-255)
- Bytes 0-1 must be 0 to distinguish from original temperature command
- Remaining bytes (6-19) are reserved for future use

Examples:
```json
// Set motor 1 LED to red on slave 0
{"i":0,"s":7,"h":[0,0,1,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}

// Set motor 2 LED to green on slave 0
{"i":0,"s":7,"h":[0,0,2,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}

// Set motor 3 LED to blue on slave 0
{"i":0,"s":7,"h":[0,0,3,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}

// Set motor 4 LED to white on slave 0
{"i":0,"s":7,"h":[0,0,4,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
```

### Predefined Color Codes (for reference)
- Off: [0, 0, 0]
- Red: [255, 0, 0]
- Green: [0, 255, 0]
- Blue: [0, 0, 255]
- White: [255, 255, 255]
- Yellow: [255, 255, 0]
- Cyan: [0, 255, 255]
- Magenta: [255, 0, 255]
- Orange: [255, 165, 0]
- Purple: [128, 0, 128]
- Pink: [255, 192, 203]

## System Configuration for Our Setup

### Slave and Motor Mapping

Our setup consists of:
- 8 slave modules with IDs 0-7
- 8 motors per slave (motors 1-8)
- Total of 64 motors

Slave ID mapping:
- Slave 0: Motors 1-8
- Slave 1: Motors 9-16
- Slave 2: Motors 17-24
- Slave 3: Motors 25-32
- Slave 4: Motors 33-40
- Slave 5: Motors 41-48
- Slave 6: Motors 49-56
- Slave 7: Motors 57-64

### Position Units

All positions are specified in 1/10 mm units:
- Value of 100 = 10.0 mm
- Value of 2000 = 200.0 mm (maximum travel)
- Value of 0 = 0.0 mm (home position at limit switch, lowest point)

### Motor Direction

- **CCW rotation**: Moves motor down (toward limit switch/position 0)
- **CW rotation**: Moves motor up (away from limit switch)
- **Travel range**: 0-200mm
- **Limit switch**: Located at 0mm position

### Physical Switches

Each motor has two physical switches connected via GPIO expanders:
- **UP switch**: Causes motor to move up until released (at pre-defined speed)
- **DOWN switch**: Causes motor to move down until released (at pre-defined speed)
- Motors automatically stop at position 0mm or 200mm even if buttons are still pressed
- Physical switches override CAN commands in progress

## Position Calculation

Based on hardware specifications:
- 4mm pitch leadscrew
- 200mm travel range
- Steps per 1/10mm: 80 steps
- Steps per mm: 800 steps
- Total steps for full travel: 160,000 steps

## Sample Test Data

### Single Slave Commands

Move all motors of slave 0 to mid-position (100.0mm):
```json
{"i":0,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]}
```

Move all motors of slave 1 to different positions:
```json
{"i":1,"s":1,"h":[500,750,1250,1500,1750,2000,250,100,0,0,0,0,0,0,0,0,0,0,0,0]}
```

### LED Color Commands

Set different colors for motors on slave 0:
```json
// Set motor 1 to red
{"i":0,"s":7,"h":[0,0,1,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
// Set motor 2 to green
{"i":0,"s":7,"h":[0,0,2,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
// Set motor 3 to blue
{"i":0,"s":7,"h":[0,0,3,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
// Set motor 4 to white
{"i":0,"s":7,"h":[0,0,4,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
// Set motor 5 to yellow
{"i":0,"s":7,"h":[0,0,5,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
// Set motor 6 to cyan
{"i":0,"s":7,"h":[0,0,6,0,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
// Set motor 7 to magenta
{"i":0,"s":7,"h":[0,0,7,255,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
// Set motor 8 to orange
{"i":0,"s":7,"h":[0,0,8,255,165,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
```

### Multiple Slave Commands

Send position commands to all 8 slaves:
```json
{"i":0,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":1,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":2,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":3,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":4,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":5,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":6,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":7,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]}
```

Set system speed parameters:
```json
{"i":0,"s":5,"h":[29,99,14,99,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
```

Set LED colors for all motors on all slaves:
```json
{"i":0,"s":7,"h":[0,0,1,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":0,"s":7,"h":[0,0,2,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":0,"s":7,"h":[0,0,3,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":0,"s":7,"h":[0,0,4,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":0,"s":7,"h":[0,0,5,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":0,"s":7,"h":[0,0,6,0,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":0,"s":7,"h":[0,0,7,255,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":0,"s":7,"h":[0,0,8,255,165,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
```

### Complex Test Sequence

1. Set speeds:
```json
{"i":0,"s":5,"h":[29,99,14,99,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
```

2. Move all motors to home position:
```json
{"i":0,"s":1,"h":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":1,"s":1,"h":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":2,"s":1,"h":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":3,"s":1,"h":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":4,"s":1,"h":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":5,"s":1,"h":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":6,"s":1,"h":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":7,"s":1,"h":[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
```

3. Set LED colors for all motors:
```json
{"i":0,"s":7,"h":[0,0,1,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":0,"s":7,"h":[0,0,2,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":0,"s":7,"h":[0,0,3,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":0,"s":7,"h":[0,0,4,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":0,"s":7,"h":[0,0,5,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":0,"s":7,"h":[0,0,6,0,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":0,"s":7,"h":[0,0,7,255,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":0,"s":7,"h":[0,0,8,255,165,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
```

4. Move all motors to mid-position:
```json
{"i":0,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":1,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":2,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":3,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":4,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":5,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":6,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":7,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]}
```

## Sending Data from a PC

### Network Connection

1. Connect the PC to the same network as the CAN controller
2. The controller listens on TCP port 5000
3. Use a TCP client to connect to the controller

### Example Python Script

```python
import socket
import json

# Controller IP and port
CONTROLLER_IP = "192.168.1.100"  # Replace with actual IP
CONTROLLER_PORT = 5000

# Create socket connection
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.connect((CONTROLLER_IP, CONTROLLER_PORT))

# Create command
command = {"i": 0, "s": 1, "h": [1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000] + [0]*12}

# Convert to JSON and send
json_string = json.dumps(command)
sock.send(json_string.encode() + b'\n')

# Close connection
sock.close()
```

### Example with Multiple Commands

```python
import socket
import json

# Controller IP and port
CONTROLLER_IP = "192.168.1.100"  # Replace with actual IP
CONTROLLER_PORT = 5000

# Create socket connection
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.connect((CONTROLLER_IP, CONTROLLER_PORT))

# Create multiple commands
commands = [
    {"i": 0, "s": 1, "h": [1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000] + [0]*12},
    {"i": 1, "s": 1, "h": [500, 750, 1250, 1500, 1750, 2000, 250, 100] + [0]*12},
    {"i": 0, "s": 7, "h": [0, 0, 1, 255, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]}  # Set motor 1 LED to red
]

# Concatenate commands with semicolons
command_string = ";".join(json.dumps(cmd) for cmd in commands)

# Send commands
sock.send(command_string.encode() + b'\n')

# Close connection
sock.close()
```

### Using Telnet

You can also use telnet to send commands:

```bash
telnet 192.168.1.100 5000
```

Then type commands like:
```
{"i":0,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]}
```

Press Enter to send each command.

### Using netcat (Linux/Mac)

```bash
echo '{"i":0,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]}' | nc 192.168.1.100 5000
```

For multiple commands:
```bash
echo '{"i":0,"s":1,"h":[1000,1000,1000,1000,1000,1000,1000,1000,0,0,0,0,0,0,0,0,0,0,0,0]};{"i":1,"s":1,"h":[500,750,1250,1500,1750,2000,250,100,0,0,0,0,0,0,0,0,0,0,0,0]}' | nc 192.168.1.100 5000
```

## Validation Rules

When creating JSON commands, ensure:

1. Slave ID (`i`) is between 0-7 for our setup
2. Command type (`s`) is a valid value (1, 3, 5, 6, or 7)
3. Height array (`h`) always contains exactly 20 values
4. For position commands, only the first 8 values should be non-zero (representing motor positions)
5. For LED color commands (s: 7):
   - Bytes 0-1 must be 0 to distinguish from temperature command
   - Byte 2 is motor index (1-8)
   - Bytes 3-5 are R, G, B values (0-255)
   - Bytes 6-19 are reserved (should be 0)
6. Speed values use the 4-digit encoding (high byte, low byte)
7. All commands end with a newline character when sent over network

