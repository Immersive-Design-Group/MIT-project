# Startup Prompt

## Project Overview

This is a CAN-based motor control system for an art installation. The system consists of:

1. A master controller (can_stm32) that communicates with up to 50 slave modules via CAN bus
2. Multiple slave motor controller boards (mit-motor-controller) that each control 8 stepper motors

## System Documentation

All system functionality is documented in the following files:

1. **SLAVE_OVERVIEW.md** - Complete documentation of the old slave implementation
2. **CAN_CONTROLLER_OVERVIEW.md** - Complete documentation of the master controller
3. **MIT_MOTOR_CONTROLLER_OVERVIEW.md** - Documentation of the new controller implementation
4. **JSON_COMMAND_FORMAT.md** - Documentation of JSON command format for PC communication
5. **SYSTEM_SPECIFICATIONS.md** - CAN protocol specifications
6. **IMPLEMENTATION_PLAN.md** - Detailed implementation plan for the new controller
7. **IMPLEMENTATION_CHECKLIST.md** - Checklist for tracking implementation progress

## File Locations

### Master Controller (CAN interface)
- Directory: `/home/bairui/stm32/can_stm32/`

### Slave Motor Controller (New Implementation)
- Directory: `/home/bairui/stm32/mit-motor-controller/`
- Key files:
  - `Core/Src/main.c` - Main application
  - `Core/tmc2209/tmc2209.c` - TMC2209 stepper driver
  - `Core/tmc2209/motion_control.c` - Motion control system
  - `Core/pca9555/pca9555.c` - PCA9555 I/O expander driver
  - `Core/pca9555/io_expander.c` - I/O expander interface
  - `Core/pca9555/io_mapping.h` - Pin mapping for I/O expanders
  - `Core/ws2812b/ws2812_driver.c` - LED driver (optional)

## Your Role

You are assisting in adapting the motor controller firmware to work as a CAN slave with the existing master controller. Your tasks include:

1. Understanding the CAN protocol used by the master (refer to CAN_CONTROLLER_OVERVIEW.md)
2. Implementing CAN communication in the slave firmware (refer to SLAVE_OVERVIEW.md and MIT_MOTOR_CONTROLLER_OVERVIEW.md)
3. Adapting motor control to respond to CAN commands
4. Implementing the homing procedure
5. Adding status reporting to the master

## Goals

1. Make the motor controller respond to position commands from the master
2. Implement speed control commands
3. Execute homing procedures when requested
4. Send status updates to the master
5. Handle retransmission requests
6. Integrate with the existing master-slave communication system

## Next Steps

Review the documentation files to prepare for implementation work. Focus on:
1. Understanding the CAN message formats and IDs (refer to SYSTEM_SPECIFICATIONS.md)
2. Learning how position values are encoded and decoded (refer to JSON_COMMAND_FORMAT.md)
3. Understanding the homing procedure requirements (refer to SLAVE_OVERVIEW.md)
4. Identifying where to add CAN initialization and message handling code (refer to MIT_MOTOR_CONTROLLER_OVERVIEW.md and IMPLEMENTATION_PLAN.md)