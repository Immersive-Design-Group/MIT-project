
# STM32F407ZGT6 Motor Controller Overview

## MCU & Programming

- **Microcontroller**: STM32F407ZGT6  
- **Programmer/Debugger**: ST-LINK V2  
- **Firmware Environment**: STM32CubeIDE (TMC2209 library must be ported from Arduino)

---

## Stepper Motor Control: TMC2209

- **Driver IC**: TMC2209  
- **Number of Drivers**: 8  
- **Control Interface**: STEP and DIR signals  
- **Configuration Interface**: UART (single-wire)  
- **Electrical Notes**:  
  - Each UART controls two TMC2209 drivers in parallel  
  - UART TX goes through 1kΩ resistor  
  - MS1 determines driver address: `MS1=0 → Addr 0`, `MS1=1 → Addr 1`

### TMC2209 Pin Assignments

| Motor | MS1 | UART | MCU RX | MCU TX | STEP | DIR  | EN   |
| ----- | --- | ---- | ------ | ------ | ---- | ---- | ---- |
| 0     | 0   | 1    | PA10   | PA9    | PC7  | PC6  | PA11 |
| 1     | 1   | 1    | PA10   | PA9    | PG4  | PG3  | PG6  |
| 2     | 0   | 3    | PD9    | PD8    | PB15 | PB14 | PD13 |
| 3     | 1   | 3    | PD9    | PD8    | PE13 | PE12 | PE15 |
| 4     | 0   | 2    | PD6    | PD5    | PA15 | PC10 | PC12 |
| 5     | 1   | 2    | PD6    | PD5    | PE3  | PE2  | PE5  |
| 7     | 1   | 4    | PA1    | PA0    | PB1  | PB0  | PF13 |
| 6     | 0   | 4    | PA1    | PA0    | PF14(PF4) | PF15 | PG1  |

**Note**: For UART4, ensure `PA6` is in Hi-Z or INPUT mode.

---

## Debugging Interfaces

### Diagnostic LEDs

| LED | Pin |
|-----|-----|
| LED1 | PF3 |
| LED2 | PF2 |

### UART6 (Debug UART)

| Function | Pin |
|----------|-----|
| TX       | PG14 |
| RX       | PG9  |

### User Button

- **Pin**: PF4  
- **Type**: Active low with external pull-up  

---

## Peripheral Subsystems

### Fans (Active High via NPN controlling P-Channel MOSFET)

| Fan | Pin |
|-----|-----|
| Fan1 | PF1 |
| Fan2 | PF0 |

### NTC Temperature Sensors

| Sensor         | Pin |
|----------------|-----|
| Onboard        | PA4 |
| External 1     | PA3 |
| External 2     | PA2 |
| Sensor Type    | 10k NTC |

---

### CAN Bus

- **Transceiver**: SN65HVD230DR  
- **Pins**:
  - `CAN_RX`: PD0  
  - `CAN_TX`: PD1

---

### Smart LEDs (WS2812B)

- **Data Pin**: PB5  
- **Function**: Drives 8 parallel LED strips  
- **Enable Control**: Via GPIO Extenders  
- **Testing**: Can bypass extenders and directly drive `PB5`

---

## GPIO Extenders

- **IC**: TCA9555 x2  
- **Protocol**: I²C  
- **Interrupts**: Not used; polling required  
- **Bus Pins**:
  - `SCL`: PB6  
  - `SDA`: PB7  
- **I²C Addresses**:
  - `0x20` → Address 000  
  - `0x21` → Address 001  

### Switch Definitions

Each motor has 3 associated switches (active LOW with external pull-up):

- `LIMIT_SW`: Homing switch  
- `UP_SW`: Clockwise motion  
- `DOWN_SW`: Counter-clockwise motion  

### GPIO Extender 1 – Address 000 (0x20)

| Pin  | Function         |
|------|------------------|
| P00  | LED_DATA2_OE     |
| P01  | LED_DATA1_OE     |
| P02  | LIMIT_SW1        |
| P03  | UP_SW1           |
| P04  | DOWN_SW1         |
| P05  | LIMIT_SW2        |
| P06  | UP_SW2           |
| P07  | DOWN_SW2         |
| P10  | DOWN_SW4         |
| P11  | UP_SW4           |
| P12  | LIMIT_SW4        |
| P13  | LED_DATA4_OE     |
| P14  | LED_DATA3_OE     |
| P15  | DOWN_SW3         |
| P16  | UP_SW3           |
| P17  | LIMIT_SW3        |

### GPIO Extender 2 – Address 001 (0x21)

| Pin  | Function         |
|------|------------------|
| P00  | LIMIT_SW5        |
| P01  | UP_SW5           |
| P02  | DOWN_SW5         |
| P03  | LED_DATA5_OE     |
| P04  | LED_DATA6_OE     |
| P05  | LIMIT_SW6        |
| P06  | UP_SW6           |
| P07  | DOWN_SW6         |
| P10  | LIMIT_SW8        |
| P11  | UP_SW8           |
| P12  | DOWN_SW8         |
| P13  | LED_DATA8_OE     |
| P14  | LED_DATA7_OE     |
| P15  | DOWN_SW7         |
| P16  | UP_SW7           |
| P17  | LIMIT_SW7        |

---

## Development Strategy

- Each hardware module (UART, stepper, CAN, GPIO, LEDs, sensors) will be developed and tested **independently**.
- Integration will occur **only after** individual validation.
- GPIO expanders must be **polled continuously**, especially during homing, where `LIMIT_SWx` inputs must be checked at high frequency.
- TMC2209 library (currently Arduino-based) is to be **ported to STM32Cube/CMSIS** for compatibility.

Development Prompt