# CAN Motor Control System Documentation

This repository contains comprehensive documentation for a CAN-based motor control system used in an art installation. The system consists of a master controller and multiple slave motor controllers that work together to precisely control stepper motors via CAN bus communication.

## Project Overview

The system coordinates up to 8 slave modules, each controlling 8 stepper motors, for a total of 64 motors. Communication between the master and slaves is handled via CAN bus, while the master also provides a TCP/IP interface for remote control from a PC.

## Documentation Structure

This documentation is organized into several key files, each focusing on a specific aspect of the system:

### System Architecture and Communication

1. **[SYSTEM_SPECIFICATIONS.md](SYSTEM_SPECIFICATIONS.md)**
   - Detailed CAN protocol specifications
   - Message formats and ID assignments
   - Command types and data representations
   - Essential reference for understanding system communication

2. **[CAN_CONTROLLER_OVERVIEW.md](CAN_CONTROLLER_OVERVIEW.md)**
   - Complete documentation of the master controller implementation
   - Network interface details (TCP/IP on port 5000)
   - JSON command parsing and processing
   - Hardware components and software architecture

3. **[SLAVE_OVERVIEW.md](SLAVE_OVERVIEW.md)**
   - Comprehensive documentation of the original slave implementation
   - CAN message handling and filtering
   - Motor control and homing procedures
   - Reference implementation for the new controller

### Implementation and Development

4. **[MIT_MOTOR_CONTROLLER_OVERVIEW.md](MIT_MOTOR_CONTROLLER_OVERVIEW.md)**
   - Current state of the new motor controller codebase
   - Hardware components and code structure
   - Issues and missing functionality
   - Implementation requirements for CAN slave operation
   - Details about physical switches and motor direction
   - Information about LED color control implementation

5. **[IMPLEMENTATION_PLAN.md](IMPLEMENTATION_PLAN.md)**
   - Detailed roadmap for implementing CAN slave functionality
   - Phased approach with specific tasks and time estimates
   - Risk mitigation strategies
   - Complete guide for development process
   - Detailed information about LED color control implementation

6. **[IMPLEMENTATION_CHECKLIST.md](IMPLEMENTATION_CHECKLIST.md)**
   - Comprehensive checklist for tracking implementation progress
   - Detailed tasks organized by implementation phase
   - Feature completion tracking
   - Progress monitoring tool
   - LED color control implementation checklist

### Command and Control

7. **[JSON_COMMAND_FORMAT.md](JSON_COMMAND_FORMAT.md)**
   - Complete reference for JSON command format
   - Command types and parameters
   - Sample test data for all system configurations
   - Instructions for sending commands from a PC
   - Details about motor direction and physical switches
   - Complete documentation of LED color control commands (replaces temperature command)

### Project Context

8. **[STARTUP_PROMPT.md](STARTUP_PROMPT.md)**
   - Quick start guide for understanding the project
   - Overview of system components
   - Links to key documentation files
   - Next steps for implementation work

## Getting Started

To understand and work with this system, we recommend reviewing the documentation in the following order:

1. Start with [STARTUP_PROMPT.md](STARTUP_PROMPT.md) for a quick overview
2. Review [SYSTEM_SPECIFICATIONS.md](SYSTEM_SPECIFICATIONS.md) to understand the CAN protocol
3. Examine [CAN_CONTROLLER_OVERVIEW.md](CAN_CONTROLLER_OVERVIEW.md) and [SLAVE_OVERVIEW.md](SLAVE_OVERVIEW.md) to understand both sides of the communication
4. Study [MIT_MOTOR_CONTROLLER_OVERVIEW.md](MIT_MOTOR_CONTROLLER_OVERVIEW.md) to understand the current implementation status
5. Use [IMPLEMENTATION_PLAN.md](IMPLEMENTATION_PLAN.md) and [IMPLEMENTATION_CHECKLIST.md](IMPLEMENTATION_CHECKLIST.md) for development guidance
6. Refer to [JSON_COMMAND_FORMAT.md](JSON_COMMAND_FORMAT.md) for command structure and testing

## System Components

### Master Controller (can_stm32)
- STM32F407 microcontroller
- Dual CAN interfaces (CAN1/CAN2)
- Ethernet interface (W5500) for TCP/IP communication
- Processes commands from PC and coordinates slave modules

### Slave Controllers (mit-motor-controller)
- STM32F407ZGT6 microcontroller
- Controls 8 stepper motors via TMC2209 drivers
- Uses PCA9555 I/O expanders for limit switch inputs
- Communicates with master via CAN bus (single CAN interface on PD0/PD1)
- Implements homing procedures using limit switches
- Includes physical UP/DOWN switches for direct motor control
- Temperature sensors on PA2/PA3/PA4 with 10k pullup resistors
- WS2812B LED strips for status indication and artistic effect
- LED color control via CAN commands (replaces temperature command)

## Development Environment

- STM32CubeIDE for firmware development
- HAL (Hardware Abstraction Layer) library
- C programming language
- Python or other languages for PC-side command sending

## Key Features

- Precise stepper motor control (0.05mm accuracy with 80 steps per 1/10mm)
- CAN bus communication at ~1Mbps
- TCP/IP interface for remote control
- Homing procedures using limit switches
- Physical switch override for direct motor control
- Retransmission mechanism for reliable communication
- JSON-based command protocol
- Temperature monitoring capabilities (NTC sensors)
- LED color control via CAN commands (replaces temperature command)
- Predefined color palette and direct RGB value support

## Physical Operation

- **Motor Direction**: CCW rotation moves motor down (toward limit switch/position 0), CW rotation moves motor up
- **Travel Range**: 0-200mm (limit switch at 0mm position)
- **Lead Screw Pitch**: 4mm
- **Physical Switches**: Each motor has UP and DOWN switches connected via GPIO expanders that override CAN commands
  - UP switch causes motor to move up until released (pre-defined speed)
  - DOWN switch causes motor to move down until released (pre-defined speed)
  - Motors automatically stop at position 0mm or 200mm even if buttons are still pressed

## LED Color Control

### Overview
Each motor is equipped with a WS2812B LED that can be controlled individually via CAN commands. This feature replaces the original temperature control command, providing an artistic element while maintaining system functionality.

### Command Format
```json
{"i": slave_id, "s": 7, "h": [0, 0, motor_index, r, g, b, 0, 0, ..., 0]}
```

Details:
- `slave_id`: ID of the target slave (0-7 for our setup)
- `s`: 7 (LED color control command)
- `h[0-1]`: Must be 0 to distinguish from temperature command
- `h[2]`: Motor index (1-8)
- `h[3]`: Red value (0-255)
- `h[4]`: Green value (0-255)
- `h[5]`: Blue value (0-255)
- `h[6-19]`: Reserved (should be 0)

### Predefined Colors
- 0: Off [0, 0, 0]
- 1: Red [255, 0, 0]
- 2: Green [0, 255, 0]
- 3: Blue [0, 0, 255]
- 4: White [255, 255, 255]
- 5: Yellow [255, 255, 0]
- 6: Cyan [0, 255, 255]
- 7: Magenta [255, 0, 255]
- 8: Orange [255, 165, 0]
- 9: Purple [128, 0, 128]
- 10: Pink [255, 192, 203]

### Example Commands
```json
// Set motor 1 LED to red on slave 0
{"i":0,"s":7,"h":[0,0,1,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}

// Set motor 2 LED to green on slave 0
{"i":0,"s":7,"h":[0,0,2,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}

// Set motor 3 LED to blue on slave 0
{"i":0,"s":7,"h":[0,0,3,0,0,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0]}
```

## System Timing

This is an art installation with no strict timing requirements:
- Command response times in milliseconds or tens of milliseconds are acceptable
- Motor movements will begin as soon as commands are processed
- No hard real-time constraints

This documentation provides all necessary information to understand, implement, and work with the CAN motor control system without needing to refer to the original source code repositories.