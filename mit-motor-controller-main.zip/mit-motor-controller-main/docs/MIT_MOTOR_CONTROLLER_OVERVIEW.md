# MIT Motor Controller Overview

This document provides a comprehensive overview of the mit-motor-controller codebase, detailing its current functionality, issues that need to be resolved, and what needs to be added to duplicate the functionality of the old slave project.

## System Architecture

The mit-motor-controller is designed to control 8 stepper motors using TMC2209 drivers with limit switches for homing. It uses PCA9555 I/O expanders for GPIO management and includes WS2812B LED support.

### Hardware Components

1. **STM32F407ZGT6 Microcontroller** - Main processing unit
2. **TMC2209 Stepper Motor Drivers** - Control for 8 motors (UART interface)
3. **PCA9555 I/O Expanders** - GPIO management for limit switches and LED control
4. **WS2812B LEDs** - Status indication
5. **I2C Interface** - Communication with PCA9555 expanders
6. **UART Interfaces** - Communication with TMC2209 drivers
7. **GPIOs** - Control signals for motor drivers
8. **Single CAN Interface** - Communication with master controller (PD0/PD1 for CAN1 RX/TX)
9. **Temperature Sensors** - NTC sensors on PA2/PA3/PA4 with 10k pullup resistors forming voltage dividers

### Key Features (Current Implementation)

- Control of 8 stepper motors via TMC2209 drivers
- Homing procedure using limit switches
- LED status indication via WS2812B
- I/O management through PCA9555 expanders
- Motion control with acceleration/deceleration
- Physical switch inputs for direct motor control

### Physical Operation

- **Motor Direction**: CCW rotation moves motor down (toward limit switch/position 0), CW rotation moves motor up
- **Travel Range**: 0-200mm (limit switch at 0mm position)
- **Lead Screw Pitch**: 4mm
- **Physical Switches**: Each motor has UP and DOWN switches connected via GPIO expanders that override CAN commands
  - UP switch causes motor to move up until released (pre-defined speed)
  - DOWN switch causes motor to move down until released (pre-defined speed)
  - Motors automatically stop at position 0mm or 200mm even if buttons are still pressed

## Current Codebase Structure

### Core Components

1. **main.c** - Application entry point and main loop
2. **tmc2209/** - TMC2209 stepper driver implementation
3. **pca9555/** - PCA9555 I/O expander implementation
4. **ws2812b/** - WS2812B LED driver
5. **motion_control.c/h** - Motion control system

### Key Functions

#### Main Application (Core/Src/main.c)

- MCU and peripheral initialization
- I/O expander initialization
- TMC2209 driver initialization
- Motion control initialization
- LED initialization and control
- Main loop with LED color cycling

#### TMC2209 Driver (Core/tmc2209/)

- `TMC2209_init()` - Initialize TMC2209 driver
- `TMC2209_setControlPins()` - Configure GPIO pins for motor control
- `TMC2209_enable()/disable()` - Enable/disable motor driver
- `TMC2209_setMicrostepsPerStep()` - Configure microstepping
- `TMC2209_setRunCurrent()/setHoldCurrent()` - Configure motor current
- `TMC2209_moveAtVelocity()` - Velocity control
- `TMC2209_setDirection()` - Set motor direction
- `TMC2209_step()` - Generate step pulse
- `TMC2209_isCommunicating()` - Verify communication with driver

#### Motion Control (Core/tmc2209/motion_control.c)

- `Motion_init()` - Initialize motion control system
- `Motion_move()` - Command motor movement
- `Motion_stop()` - Stop motor movement
- `Motion_isBusy()` - Check if motor is moving
- `Motion_timerCallback()` - Timer-based step generation

#### I/O Management (Core/pca9555/)

- `IO_Init()` - Initialize I/O expanders
- `IO_DigitalRead()/IO_DigitalWrite()` - Read/write I/O pins
- `IO_Expander_EnableLedChannel()` - Control LED channels

#### LED Control (Core/ws2812b/)

- `ws2812b_init()` - Initialize WS2812B LED driver
- `ws2812b_set_strip_color()` - Set LED strip color
- `ws2812b_set_led_color()` - Set individual LED color
- `ws2812b_update()` - Update LED strip with new colors

## Issues and Missing Functionality

### Critical Missing Components

1. **CAN Communication Layer**
   - **Issue**: No CAN initialization or message handling
   - **Impact**: Cannot communicate with master controller
   - **Solution**: Implement CAN1 initialization, message filtering, and handlers
   - **Implementation**:
     - Add CAN handle (hcan1) to main.c
     - Implement MX_CAN1_Init() function
     - Add CAN_Start() function to initialize and start CAN interface
     - Implement CAN message transmission function (CANx_SendStdData)
     - Add CAN interrupt handlers (HAL_CAN_RxFifo0MsgPendingCallback)
     - Include message filtering configuration

2. **Slave Identification**
   - **Issue**: No mechanism to determine slave ID
   - **Impact**: Cannot filter CAN messages for this specific slave
   - **Solution**: Implement compile-time slave ID configuration
   - **Implementation**:
     - Add machine_id variable (hardcoded 0-7 for our setup)
     - Integrate with CAN filter configuration

3. **Message Processing**
   - **Issue**: No CAN message parsing or handling
   - **Impact**: Cannot respond to commands from master
   - **Solution**: Implement message parsing and command handling
   - **Implementation**:
     - Add data_CAN buffer to store received messages
     - Add receiveFlag array to track received message types
     - Add commandFlag variable to track command assembly status
     - Implement ProcessCANMessage() function to handle different message types
     - Add functions to convert received data to motor positions
     - Add LED color command handling (replaces temperature command)

4. **Position Control Integration**
   - **Issue**: Motion control exists but isn't integrated with position commands
   - **Impact**: Cannot execute position commands from master
   - **Solution**: Connect received position data to motion control system
   - **Implementation**:
     - Implement regenerateData() function to convert CAN data to motor steps
     - Modify main loop to execute movements when position commands are received
     - Add position tracking variables

5. **Homing Command Implementation**
   - **Issue**: Homing procedure exists but isn't triggered by CAN commands
   - **Impact**: Cannot perform homing when requested by master
   - **Solution**: Connect homing procedure to CAN command handling
   - **Implementation**:
     - Add State variable to track operation mode
     - Implement homing command handling in message processor
     - Connect State variable to motion control execution

6. **Status Reporting**
   - **Issue**: No mechanism to send status updates to master
   - **Impact**: Master cannot monitor slave status
   - **Solution**: Implement status reporting functions
   - **Implementation**:
     - Add functions to send initialization status
     - Add periodic status updates
     - Add retransmission response handling

7. **Speed Control**
   - **Issue**: No speed parameter handling from CAN commands
   - **Impact**: Cannot adjust motor speeds based on master commands
   - **Solution**: Implement speed parameter storage and application
   - **Implementation**:
     - Add variables for InitMotorSpeed and HighestSpeed
     - Implement speed command handling
     - Connect speed parameters to motion control system

8. **Physical Switch Integration**
   - **Issue**: Physical switches exist but aren't integrated with motor control
   - **Impact**: Cannot use direct motor control switches
   - **Solution**: Implement switch monitoring and motor control override
   - **Implementation**:
     - Add periodic switch state checking
     - Implement motor override when switches are pressed
     - Ensure motors stop at position limits (0mm/200mm)

9. **LED Color Control Integration**
   - **Issue**: LED driver exists but isn't integrated with CAN commands
   - **Impact**: Cannot control LED colors via CAN commands
   - **Solution**: Implement LED color command handling to replace temperature command
   - **Implementation**:
     - Add setMotorLEDColor() function to set individual motor LED colors
     - Implement LED color command processing (s=7)
     - Add predefined color palette and direct RGB support
     - Connect LED color setting to existing WS2812B driver

### Existing Issues in Current Implementation

1. **Commented-Out Code**
   - **Issue**: Large sections of code are commented out in main.c
   - **Impact**: Reduces functionality and clarity
   - **Solution**: Remove or properly implement commented code
   - **Implementation**:
     - Review and either implement or remove motor initialization code
     - Enable motion control system initialization
     - Activate state machine for motor control

2. **Incomplete Motor Configuration**
   - **Issue**: Only 4 of 8 motors are properly configured
   - **Impact**: Half the motors are unusable
   - **Solution**: Configure all 8 motors
   - **Implementation**:
     - Initialize all TMC2209 handles (motor0 through motor7)
     - Configure control pins for all motors
     - Add all motor handles to all_motor_handles array

3. **LED Control Dominance**
   - **Issue**: Main loop focuses primarily on LED color cycling
   - **Impact**: Motor control is not the primary function
   - **Solution**: Refactor main loop for motor control with LED as status indicator
   - **Implementation**:
     - Move LED control to background or lower priority
     - Implement motor control as primary function
     - Use LEDs for status indication rather than primary activity

## Required Additions to Duplicate Slave Functionality

### 1. CAN Communication Implementation

**Components to Add**:
- CAN handle declaration in main.c
- CAN initialization function (MX_CAN1_Init)
- CAN start function (CAN_Start)
- Message transmission function (CANx_SendStdData)
- Message reception callback (HAL_CAN_RxFifo0MsgPendingCallback)
- Message processing function (ProcessCANMessage)
- CAN filter configuration in initialization

**Files to Create/Modify**:
- Core/Src/main.c (add CAN handle and initialization)
- Core/Src/can_slave.c (create new file with CAN implementation)
- Core/Inc/can_slave.h (create new header file)

### 2. Slave Identification System

**Components to Add**:
- Machine ID variable (hardcoded 0-7)
- Integration with CAN filter configuration

**Files to Create/Modify**:
- Core/Src/main.c (add machine_id variable)
- Core/Src/can_slave.c (integrate with filter configuration)
- Core/Src/global.c (create new file for global variables)
- Core/Inc/global.h (create new header file)

### 3. Data Processing and Command Handling

**Components to Add**:
- data_CAN buffer for received messages
- receiveFlag array for message tracking
- commandFlag variable for command assembly status
- Data conversion functions (regenerateData)
- Position tracking variables
- State variable for operation mode
- LED color command handling (s=7) - REPLACES TEMPERATURE COMMAND

**Files to Create/Modify**:
- Core/Src/data.c (create new file for data processing)
- Core/Inc/data.h (create new header file)
- Core/Src/main.c (add variables and integrate with main loop)

### 4. Motor Control Integration

**Components to Add**:
- Connection between received position data and motion control
- Homing command handling
- Speed parameter handling
- Position tracking implementation

**Files to Create/Modify**:
- Core/Src/main.c (integrate with motion control)
- Core/tmc2209/motion_control.c (possibly modify for position tracking)
- Core/Src/data.c (add position conversion)

### 5. Status Reporting System

**Components to Add**:
- Initialization status reporting
- Periodic status updates
- Retransmission response handling

**Files to Create/Modify**:
- Core/Src/can_slave.c (add status reporting functions)
- Core/Src/main.c (integrate with main loop and timer interrupts)

### 6. Physical Switch Integration

**Components to Add**:
- Periodic switch state monitoring
- Motor control override implementation
- Position limit enforcement

**Files to Create/Modify**:
- Core/Src/main.c (add switch monitoring to main loop)
- Core/pca9555/io_expander.c (verify switch reading functions)

### 7. LED Color Control Integration

**Components to Add**:
- setMotorLEDColor() function to set individual motor LED colors
- LED color command processing (s=7)
- Predefined color palette and direct RGB support
- Connection to existing WS2812B driver

**Files to Create/Modify**:
- Core/Src/main.c (add LED color command processing)
- Core/Src/data.c (add LED color command handling)
- Core/ws2812b/ws2812_driver.c (verify LED setting functions)
- Core/Inc/data.h (add LED color command declarations)

## Hardware Dependencies

### GPIO Pins

- Limit switch inputs through PCA9555 I/O expanders
- Motor control pins (EN, STEP, DIR) for all 8 motors
- UART interfaces for TMC2209 communication
- I2C interface for PCA9555 communication
- LED control pins
- CAN transceiver pins (PD0/PD1 for CAN1 RX/TX)
- ADC pins for temperature sensors (PA2, PA3, PA4 with voltage dividers)
- Physical switch inputs through PCA9555 I/O expanders

### Peripherals

- **CAN1**: For communication with master (PD0/PD1)
- **I2C1**: For PCA9555 communication
- **UART1/2/3/4**: For TMC2209 communication
- **TIM2**: For motion control stepping
- **TIM3**: For WS2812B LED control
- **ADC1**: For temperature sensing (channels 2, 3, 4)
- **GPIO**: Extensive use for motor control and I/O expansion

## Position Calculation

Given the system specifications:
- 4mm pitch leadscrew
- 200mm travel range
- Assuming 16 microsteps per full step (typical for TMC2209)
- 200 full steps per revolution

Calculations:
- Steps per revolution: 200 * 16 = 3200 steps
- Revolutions per full travel: 200mm / 4mm = 50 revolutions
- Total steps for full travel: 50 * 3200 = 160,000 steps
- Steps per mm: 160,000 / 200 = 800 steps/mm
- Steps per 0.1mm: 800 / 10 = 80 steps

This matches the 80 steps per 1/10 mm unit specified in the system documentation.

## Speed Calibration

The system will require speed calibration:
1. Start with safe, slow speeds
2. Test movement accuracy and smoothness
3. Gradually increase speeds while monitoring performance
4. Determine optimal InitMotorSpeed and HighestSpeed values
5. Default starting values can be InitMotorSpeed=3000, HighestSpeed=1500 (slower than old system)

## LED Color Control Implementation Details

### Command Format (s=7 - Replaces Temperature Command)

Instead of the original temperature command, we'll use command type 7 for LED color control:

Format:
```json
{"i": slave_id, "s": 7, "h": [0, 0, motor_index, r, g, b, 0, 0, ..., 0]}
```

Details:
- Bytes 0-1: Must be 0 to distinguish from temperature command
- Byte 2: Motor index (1-8)
- Byte 3: Red value (0-255)
- Byte 4: Green value (0-255)
- Byte 5: Blue value (0-255)
- Bytes 6-19: Reserved (should be 0)

### Predefined Color Palette

For convenience, we can also support predefined color codes:
- 0: Off [0, 0, 0]
- 1: Red [255, 0, 0]
- 2: Green [0, 255, 0]
- 3: Blue [0, 0, 255]
- 4: White [255, 255, 255]
- 5: Yellow [255, 255, 0]
- 6: Cyan [0, 255, 255]
- 7: Magenta [255, 0, 255]
- 8: Orange [255, 165, 0]
- 9: Purple [128, 0, 128]
- 10: Pink [255, 192, 203]

### Implementation in Slave Code

In the slave's CAN message processing:

1. Detect LED Color Command:
```c
if (RxData[0] == 0 && RxData[1] == 0 && RxData[2] != 0) {
    // This is an LED color command, not a temperature command
    uint8_t motor_index = RxData[2];
    uint8_t r = RxData[3];
    uint8_t g = RxData[4];
    uint8_t b = RxData[5];
    
    // Validate motor_index (1-8)
    if (motor_index >= 1 && motor_index <= 8) {
        // Set LED color for specified motor
        setMotorLEDColor(motor_index - 1, r, g, b); // Convert to 0-7 index
    }
} else {
    // Process as normal temperature command
    // ... existing temperature handling code
}
```

2. Color Setting Function:
```c
void setMotorLEDColor(uint8_t motor_index, uint8_t r, uint8_t g, uint8_t b) {
    // Validate motor_index
    if (motor_index >= 8) return;
    
    // Set the LED color for the specified motor
    // This assumes you have a way to address individual motor LEDs
    ws2812b_set_led_color(motor_index, r, g, b);
    
    // Update LED strip to show new color
    ws2812b_update();
}
```

### Integration with WS2812B Driver

The existing WS2812B driver should already support:
- Setting individual LED colors
- Updating the LED strip
- Controlling multiple LEDs

We just need to integrate our LED color command processing with these existing functions.

## System Timing

This is an art installation with no strict timing requirements:
- Command response times in milliseconds or tens of milliseconds are acceptable
- Motor movements will begin as soon as commands are processed
- No hard real-time constraints

## Development Environment

- STM32CubeIDE for development
- HAL (Hardware Abstraction Layer) library
- C programming language
- STM32F407ZGT6 microcontroller

This comprehensive overview documents the current state of the mit-motor-controller codebase, identifies all critical missing functionality needed to duplicate the old slave implementation, and provides detailed solutions for implementation. This document should serve as a standalone reference for understanding the codebase and what needs to be added to make it fully functional as a CAN slave controller.