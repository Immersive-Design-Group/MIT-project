# MIT Motor Controller Implementation Plan

This document provides a detailed implementation plan for adding CAN slave functionality to the mit-motor-controller codebase. The goal is to enable the new hardware to receive commands from the existing can_stm32 master controller and implement all features available in the old slave project.

## Overview

The implementation will transform the mit-motor-controller from a standalone motor control system into a CAN slave that can communicate with the master controller. This involves adding CAN communication, slave identification, message processing, and integration with the existing motor control system.

## Phase 1: CAN Communication Layer Implementation

### Objective
Implement the basic CAN communication infrastructure needed for slave operation.

### Tasks

1. **Add CAN Handle Declarations**
   - Add `CAN_HandleTypeDef hcan1` to main.c (only one CAN interface)
   - Include necessary headers in main.c

2. **Create CAN Header File**
   - Create `Core/Inc/can_slave.h`
   - Define function prototypes for CAN initialization and message handling
   - Declare external variables (hcan1)

3. **Implement CAN Initialization Functions**
   - Create `Core/Src/can_slave.c`
   - Implement `MX_CAN1_Init()` with proper configuration:
     - Prescaler: 12
     - TimeSeg1: 7
     - TimeSeg2: 6
     - SJW: 1
     - Mode: Normal
     - All advanced features disabled (matching slave implementation)
   - Add proper GPIO initialization for CAN pins (PD0/PD1 for CAN1 RX/TX)

4. **Implement CAN Start Function**
   - Create `CAN_Slave_Start()` function
   - Initialize and start CAN interface
   - Activate notification for RX FIFO 0

5. **Implement Message Transmission**
   - Create `CAN_Slave_SendMessage()` function
   - Handle mailbox management and error checking
   - Match the implementation in the slave project

6. **Add CAN Filter Configuration**
   - Configure filters based on machine_id
   - Use ID list mode for exact message ID matching
   - Assign appropriate IDs to FIFO0

7. **Implement CAN Interrupt Handlers**
   - Add `HAL_CAN_RxFifo0MsgPendingCallback()` 
   - Create common message processing function

8. **Integrate CAN Initialization in Main**
   - Add CAN initialization to startup sequence in main()
   - Enable CAN interrupts
   - Call `CAN_Slave_Start()` after peripheral initialization

### Deliverables
- Working CAN communication layer
- Ability to send and receive CAN messages
- Proper message filtering based on slave ID

### Estimated Time
2-3 days

## Phase 2: Slave Identification System

### Objective
Implement the slave identification mechanism to determine this slave's ID.

### Tasks

1. **Add Global Variables**
   - Create `Core/Inc/global.h`
   - Add declarations for `machine_id`, `NUM_SLAVES` (50), `NUM_MOTORS` (8 for our setup)
   - Add `side_id` and `State` variables

2. **Create Global Implementation**
   - Create `Core/Src/global.c`
   - Implement `GetMachineID()` function
   - Hardcode machine_id (0-7) for our setup

3. **Integrate with CAN Configuration**
   - Modify CAN filter configuration to use machine_id
   - Ensure proper message filtering based on slave ID

### Deliverables
- Slave identification system
- Proper integration with CAN filtering

### Estimated Time
1 day

## Phase 3: Data Processing and Command Handling

### Objective
Implement the message processing system to handle commands from the master.

### Tasks

1. **Add Data Structures**
   - Add `data_CAN[48]` buffer to store received messages
   - Add `receiveFlag[6]` array to track received message types
   - Add `commandFlag` variable to track command assembly status

2. **Implement Message Processing**
   - Create `ProcessCANMessage()` function
   - Handle different message types:
     - Position commands (ID = machine_id * 6 + [1-5])
     - Status messages (ID = machine_id * 6 + 6)
     - LED color control messages (ID = machine_id * 6 + 7) - REPLACES TEMPERATURE COMMAND
   - Implement proper data storage in `data_CAN` buffer

3. **Create Data Processing Functions**
   - Create `Core/Inc/data.h` and `Core/Src/data.c`
   - Implement `regenerateData()` function to convert CAN data to motor steps
   - Add position tracking variables

4. **Integrate with Main Loop**
   - Modify main loop to check `commandFlag`
   - Process completed commands when `commandFlag == 2`
   - Call `regenerateData()` to convert received data to motor positions

### Deliverables
- Complete message processing system
- Data conversion from CAN format to motor steps
- Integration with main application loop

### Estimated Time
2-3 days

## Phase 4: Motor Control Integration

### Objective
Connect the received commands to the motor control system.

### Tasks

1. **Integrate with Motion Control**
   - Modify main loop to execute movements when position commands are received
   - Connect motor position targets to `Motion_move()` functions
   - Ensure proper conversion from 1/10mm units to motor steps (80 steps per 1/10mm)

2. **Implement Homing Command Handling**
   - Add State variable handling (0=idle, 1=moving, 2=homing)
   - Implement homing command processing in message handler
   - Connect to existing homing procedures in motion control

3. **Add Speed Parameter Handling**
   - Add `InitMotorSpeed` and `HighestSpeed` variables
   - Implement speed command handling
   - Connect speed parameters to motion control system

4. **Implement Position Tracking**
   - Add position tracking to motion control system
   - Ensure positions are properly updated during movement
   - Reset positions during homing

### Deliverables
- Full integration of CAN commands with motor control
- Homing procedure activation via CAN
- Speed parameter control via CAN
- Position tracking during operation

### Estimated Time
3-4 days

## Phase 5: Status Reporting System

### Objective
Implement the status reporting system to communicate with the master.

### Tasks

1. **Add Status Reporting Functions**
   - Implement initialization status reporting
   - Add functions to send status messages to master
   - Match message formats from the slave implementation

2. **Implement Periodic Status Updates**
   - Add periodic status reporting in main loop or timer interrupt
   - Implement state reporting based on operation mode

3. **Add Retransmission Response Handling**
   - Implement retransmission request processing
   - Add functions to resend requested data packets
   - Track transmission status for each packet

### Deliverables
- Complete status reporting system
- Retransmission handling capability
- Periodic status updates to master

### Estimated Time
2-3 days

## Phase 6: LED Color Control Implementation

### Objective
Implement LED color control via CAN commands, replacing the temperature command.

### Tasks

1. **Add LED Color Control Functions**
   - Create `setMotorLEDColor()` function to set individual motor LED colors
   - Add predefined color palette (red, green, blue, white, yellow, etc.)
   - Add support for direct RGB values (0-255)

2. **Update Message Processing for LED Commands**
   - Modify `ProcessCANMessage()` to handle LED color commands (s=7)
   - Implement special format detection (bytes 0-1 = 0) to distinguish from temperature commands
   - Validate motor index (1-8) and color values

3. **Integrate with WS2812B Driver**
   - Connect LED color setting to existing WS2812B driver
   - Map motor indices to specific LED channels
   - Implement color setting for each motor's LED

4. **Add LED Color Command Handling**
   - Update `regenerateData()` function to handle LED color commands
   - Add LED color tracking variables

### Deliverables
- Complete LED color control via CAN
- Replacement of temperature command with LED color command
- Integration with existing WS2812B LED driver
- Support for both palette and direct RGB color values

### Estimated Time
2-3 days

## Phase 7: Physical Switch Integration

### Objective
Implement the physical switch inputs for direct motor control.

### Tasks

1. **Implement Switch Monitoring**
   - Add periodic switch state checking in main loop
   - Use existing `IO_DigitalRead()` functions to read switch states

2. **Implement Motor Override**
   - Override CAN commands when physical switches are pressed
   - Implement motor control for UP/DOWN switches
   - Use pre-defined speed for switch operations

3. **Implement Position Limits**
   - Ensure motors stop at 0mm and 200mm positions
   - Even when physical switches are still pressed

### Deliverables
- Working physical switch integration
- Motor override capability
- Position limit enforcement

### Estimated Time
2-3 days

## Phase 8: Speed Calibration

### Objective
Calibrate motor speeds for optimal performance.

### Tasks

1. **Implement Safe Starting Speeds**
   - Start with conservative speed values
   - Default: InitMotorSpeed=3000, HighestSpeed=1500

2. **Test and Optimize**
   - Test movement accuracy and smoothness
   - Gradually adjust speeds while monitoring performance
   - Determine optimal values for the specific hardware

### Deliverables
- Calibrated motor speed parameters
- Verified movement performance

### Estimated Time
1-2 days

## Phase 9: System Integration and Testing

### Objective
Fully integrate all components and perform comprehensive testing.

### Tasks

1. **Complete System Integration**
   - Ensure all components work together seamlessly
   - Verify proper initialization sequence
   - Check timing and performance

2. **Functional Testing**
   - Test position commands from master
   - Verify homing procedure activation
   - Test speed parameter control
   - Validate status reporting
   - Test physical switch override functionality
   - Test LED color control via CAN commands

3. **Error Handling Testing**
   - Test retransmission mechanism
   - Verify error reporting
   - Check system recovery from error conditions

4. **Performance Optimization**
   - Optimize timing and responsiveness
   - Reduce latency in command execution
   - Ensure reliable communication

### Deliverables
- Fully integrated and tested CAN slave implementation
- Verified compatibility with master controller
- Optimized performance

### Estimated Time
2-3 days

## Phase 10: Documentation and Finalization

### Objective
Complete documentation and finalize the implementation.

### Tasks

1. **Update Documentation**
   - Update MIT_MOTOR_CONTROLLER_OVERVIEW.md with implementation details
   - Add usage instructions
   - Document any deviations from the plan

2. **Code Cleanup**
   - Remove unused/commented code
   - Ensure consistent code style
   - Add necessary comments

3. **Final Testing**
   - Perform complete system test
   - Verify all features work as expected
   - Document any remaining issues

### Deliverables
- Complete and well-documented implementation
- Clean and maintainable codebase
- Fully functional CAN slave controller

### Estimated Time
1-2 days

## Total Estimated Time
20-27 days for complete implementation

## Risk Mitigation

1. **Hardware Compatibility Issues**
   - Maintain regular testing with actual hardware
   - Have backup plans for pin configuration issues

2. **Communication Problems**
   - Use CAN analyzer if available
   - Implement comprehensive logging
   - Test with known working slave implementation

3. **Timing Issues**
   - Profile performance regularly
   - Optimize critical sections
   - Ensure interrupt handlers are efficient

4. **Integration Challenges**
   - Use incremental integration approach
   - Test each phase thoroughly before proceeding
   - Maintain working backups at each milestone

This implementation plan provides a detailed roadmap for adding CAN slave functionality to the mit-motor-controller, ensuring all necessary features are implemented and properly integrated.