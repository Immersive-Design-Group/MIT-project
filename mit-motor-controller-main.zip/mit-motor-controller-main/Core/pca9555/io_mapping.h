#ifndef IO_MAPPING_H
#define IO_MAPPING_H

// This file defines a unified hardware pin mapping for all I/O expanders.
// Pins 0-15 map to Expander 1 (0x20).
// Pins 16-31 map to Expander 2 (0x21).

//==============================================================================
// GPIO EXTENDER 1 (I2C Address 0x20) -> Pins 0-15
//==============================================================================
#define IO_PIN_LED_DATA1_OE     0
#define IO_PIN_LED_DATA2_OE     1
#define IO_PIN_LIMIT_SW1        2
#define IO_PIN_UP_SW1           3
#define IO_PIN_DOWN_SW1         4
#define IO_PIN_LIMIT_SW2        5
#define IO_PIN_UP_SW2           6
#define IO_PIN_DOWN_SW2         7
#define IO_PIN_DOWN_SW4         8
#define IO_PIN_UP_SW4           9
#define IO_PIN_LIMIT_SW4        10
#define IO_PIN_LED_DATA4_OE     11
#define IO_PIN_LED_DATA3_OE     12
#define IO_PIN_DOWN_SW3         13
#define IO_PIN_UP_SW3           14
#define IO_PIN_LIMIT_SW3        15

//==============================================================================
// GPIO EXTENDER 2 (I2C Address 0x21) -> Pins 16-31
//==============================================================================
#define IO_PIN_LIMIT_SW5        16 // P00 on expander 2
#define IO_PIN_UP_SW5           17 // P01 on expander 2
#define IO_PIN_DOWN_SW5         18 // P02 on expander 2
#define IO_PIN_LED_DATA5_OE     19 // P03 on expander 2
#define IO_PIN_LED_DATA6_OE     20 // P04 on expander 2
#define IO_PIN_LIMIT_SW6        21 // P05 on expander 2
#define IO_PIN_UP_SW6           22 // P06 on expander 2
#define IO_PIN_DOWN_SW6         23 // P07 on expander 2
#define IO_PIN_LIMIT_SW8        24 // P10 on expander 2
#define IO_PIN_UP_SW8           25 // P11 on expander 2
#define IO_PIN_DOWN_SW8         26 // P12 on expander 2
#define IO_PIN_LED_DATA8_OE     27 // P13 on expander 2
#define IO_PIN_LED_DATA7_OE     28 // P14 on expander 2
#define IO_PIN_DOWN_SW7         29 // P15 on expander 2
#define IO_PIN_UP_SW7           30 // P16 on expander 2
#define IO_PIN_LIMIT_SW7        31 // P17 on expander 2


#endif // IO_MAPPING_H
