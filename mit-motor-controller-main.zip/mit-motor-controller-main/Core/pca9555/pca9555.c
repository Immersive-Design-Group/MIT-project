
#include "pca9555.h"

// A short, reasonable timeout for all I2C operations
#define PCA9555_I2C_TIMEOUT_MS  100

// Helper macro for bit manipulation
#define bit_write(value, bit, bitvalue) ( (bitvalue) ? ((value) |= (1UL << (bit))) : ((value) &= ~(1UL << (bit))) )

// ======== PRIVATE HELPER FUNCTIONS ========

/**
 * @brief Writes a 16-bit value to a register pair on the PCA9555.
 * @note  This now uses a single, efficient 2-byte I2C transaction.
 */
static HAL_StatusTypeDef write_register_16bit(PCA9555_HandleTypeDef *hdev, uint8_t reg_addr, uint16_t value) {
    uint8_t data[2];
    data[0] = value & 0xFF;         // Low byte
    data[1] = (value >> 8) & 0xFF;  // High byte
    return HAL_I2C_Mem_Write(hdev->hi2c, hdev->device_address, reg_addr, I2C_MEMADD_SIZE_8BIT, data, 2, PCA9555_I2C_TIMEOUT_MS);
}

/**
 * @brief Reads a 16-bit value from a register pair on the PCA9555.
 * @note  This now uses a single, efficient 2-byte I2C transaction.
 */
static HAL_StatusTypeDef read_register_16bit(PCA9555_HandleTypeDef *hdev, uint8_t reg_addr, uint16_t *p_value) {
    uint8_t data[2];
    HAL_StatusTypeDef status = HAL_I2C_Mem_Read(hdev->hi2c, hdev->device_address, reg_addr, I2C_MEMADD_SIZE_8BIT, data, 2, PCA9555_I2C_TIMEOUT_MS);
    if (status == HAL_OK) {
        *p_value = (uint16_t)(data[1] << 8) | data[0];
    }
    return status;
}

// ======== PUBLIC API FUNCTIONS ========

HAL_StatusTypeDef PCA9555_Init(PCA9555_HandleTypeDef* hdev, I2C_HandleTypeDef* hi2c, uint16_t address) {
    hdev->hi2c = hi2c;
    // The HAL expects the 7-bit address to be shifted left by one
    hdev->device_address = address << 1;

    // Check if the device is present on the bus
    if (HAL_I2C_IsDeviceReady(hdev->hi2c, hdev->device_address, 2, PCA9555_I2C_TIMEOUT_MS) != HAL_OK) {
        return HAL_ERROR;
    }

    // Initialize software caches to a known state (all pins as inputs by default)
    hdev->config_cache = 0xFFFF;
    hdev->output_cache = 0x0000;

    // Write this default configuration to the chip
    return write_register_16bit(hdev, PCA9555_REG_CONFIG, hdev->config_cache);
}

HAL_StatusTypeDef PCA9555_SetPinMode(PCA9555_HandleTypeDef* hdev, uint8_t pin, PCA9555_PinMode_t mode) {
    if (pin > 15) return HAL_ERROR;
    bit_write(hdev->config_cache, pin, mode);
    return write_register_16bit(hdev, PCA9555_REG_CONFIG, hdev->config_cache);
}

HAL_StatusTypeDef PCA9555_SetPinPolarity(PCA9555_HandleTypeDef* hdev, uint8_t pin, PCA9555_PinPolarity_t polarity) {
    if (pin > 15) return HAL_ERROR;
    // This is a Read-Modify-Write operation as we don't cache the polarity register
    uint16_t reg_val;
    HAL_StatusTypeDef status = read_register_16bit(hdev, PCA9555_REG_POLARITY, &reg_val);
    if (status != HAL_OK) return status;
    bit_write(reg_val, pin, polarity);
    return write_register_16bit(hdev, PCA9555_REG_POLARITY, reg_val);
}

HAL_StatusTypeDef PCA9555_ReadPin(PCA9555_HandleTypeDef* hdev, uint8_t pin, GPIO_PinState* p_pin_state) {
    if (pin > 15) return HAL_ERROR;
    uint16_t all_pins;
    HAL_StatusTypeDef status = read_register_16bit(hdev, PCA9555_REG_INPUT, &all_pins);
    if (status == HAL_OK) {
        *p_pin_state = ((all_pins >> pin) & 0x01) ? GPIO_PIN_SET : GPIO_PIN_RESET;
    }
    return status;
}

HAL_StatusTypeDef PCA9555_WritePin(PCA9555_HandleTypeDef* hdev, uint8_t pin, GPIO_PinState pin_state) {
    if (pin > 15) return HAL_ERROR;
    bit_write(hdev->output_cache, pin, pin_state);
    return write_register_16bit(hdev, PCA9555_REG_OUTPUT, hdev->output_cache);
}

HAL_StatusTypeDef PCA9555_ReadAllPins(PCA9555_HandleTypeDef* hdev, uint16_t* p_all_pins_state) {
    return read_register_16bit(hdev, PCA9555_REG_INPUT, p_all_pins_state);
}

HAL_StatusTypeDef PCA9555_WriteAllPins(PCA9555_HandleTypeDef* hdev, uint16_t all_pins_state) {
    hdev->output_cache = all_pins_state;
    return write_register_16bit(hdev, PCA9555_REG_OUTPUT, hdev->output_cache);
}
