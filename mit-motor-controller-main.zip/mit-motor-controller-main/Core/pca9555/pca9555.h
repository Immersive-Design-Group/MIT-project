#ifndef INC_PCA9555_H_
#define INC_PCA9555_H_

#include "main.h" // Use main.h for HAL types like I2C_HandleTypeDef and GPIO_PinState

// 7-bit I2C address (without the R/W bit)
#define PCA9555_ADDRESS_0       0x20
#define PCA9555_ADDRESS_1       0x21
#define PCA9555_ADDRESS_2       0x22
#define PCA9555_ADDRESS_3       0x23
#define PCA9555_ADDRESS_4       0x24
#define PCA9555_ADDRESS_5       0x25
#define PCA9555_ADDRESS_6       0x26
#define PCA9555_ADDRESS_7       0x27

// Command Bytes (Register Addresses)
#define PCA9555_REG_INPUT       0x00
#define PCA9555_REG_OUTPUT      0x02
#define PCA9555_REG_POLARITY    0x04
#define PCA9555_REG_CONFIG      0x06

// Enums for clarity and type safety
typedef enum {
    PCA9555_PIN_OUTPUT = 0,
    PCA9555_PIN_INPUT = 1
} PCA9555_PinMode_t;

typedef enum {
    PCA9555_POLARITY_NORMAL = 0,
    PCA9555_POLARITY_INVERTED = 1
} PCA9555_PinPolarity_t;

// The handle structure for a single PCA9555 instance
typedef struct {
    I2C_HandleTypeDef*  hi2c;
    uint16_t            device_address; // The 7-bit address shifted left
    uint16_t            config_cache;   // Software cache for the config register
    uint16_t            output_cache;   // Software cache for the output register
} PCA9555_HandleTypeDef;


/**
 * @brief Initializes a PCA9555 device handle.
 * @param hdev Pointer to the PCA9555_HandleTypeDef struct for this instance.
 * @param hi2c Pointer to the HAL I2C_HandleTypeDef for the bus.
 * @param address The 7-bit I2C address of the device (e.g., PCA9555_ADDRESS_0).
 * @return HAL_StatusTypeDef HAL_OK on success.
 */
HAL_StatusTypeDef PCA9555_Init(PCA9555_HandleTypeDef* hdev, I2C_HandleTypeDef* hi2c, uint16_t address);

/**
 * @brief Configures a single pin as either an input or an output.
 * @param hdev Pointer to the device handle.
 * @param pin The pin to configure (0-15).
 * @param mode The desired mode (PCA9555_PIN_INPUT or PCA9555_PIN_OUTPUT).
 * @return HAL_StatusTypeDef HAL_OK on success.
 */
HAL_StatusTypeDef PCA9555_SetPinMode(PCA9555_HandleTypeDef* hdev, uint8_t pin, PCA9555_PinMode_t mode);

/**
 * @brief Configures the polarity of a single input pin.
 * @param hdev Pointer to the device handle.
 * @param pin The pin to configure (0-15).
 * @param polarity The desired polarity (PCA9555_POLARITY_NORMAL or PCA9555_POLARITY_INVERTED).
 * @return HAL_StatusTypeDef HAL_OK on success.
 */
HAL_StatusTypeDef PCA9555_SetPinPolarity(PCA9555_HandleTypeDef* hdev, uint8_t pin, PCA9555_PinPolarity_t polarity);

/**
 * @brief Reads the state of a single pin.
 * @param hdev Pointer to the device handle.
 * @param pin The pin to read (0-15).
 * @param p_pin_state Pointer to a GPIO_PinState variable to store the result.
 * @return HAL_StatusTypeDef HAL_OK on success.
 */
HAL_StatusTypeDef PCA9555_ReadPin(PCA9555_HandleTypeDef* hdev, uint8_t pin, GPIO_PinState* p_pin_state);

/**
 * @brief Writes a state to a single output pin.
 * @param hdev Pointer to the device handle.
 * @param pin The pin to write to (0-15).
 * @param pin_state The state to write (GPIO_PIN_SET or GPIO_PIN_RESET).
 * @return HAL_StatusTypeDef HAL_OK on success.
 */
HAL_StatusTypeDef PCA9555_WritePin(PCA9555_HandleTypeDef* hdev, uint8_t pin, GPIO_PinState pin_state);

/**
 * @brief NEW: Reads the state of all 16 input pins at once.
 * @param hdev Pointer to the device handle.
 * @param p_all_pins_state Pointer to a uint16_t variable to store the bitmask of all pins.
 * @return HAL_StatusTypeDef HAL_OK on success.
 */
HAL_StatusTypeDef PCA9555_ReadAllPins(PCA9555_HandleTypeDef* hdev, uint16_t* p_all_pins_state);

/**
 * @brief NEW: Writes the state of all 16 output pins at once.
 * @param hdev Pointer to the device handle.
 * @param all_pins_state A uint16_t bitmask of the states to write.
 * @return HAL_StatusTypeDef HAL_OK on success.
 */
HAL_StatusTypeDef PCA9555_WriteAllPins(PCA9555_HandleTypeDef* hdev, uint16_t all_pins_state);


#endif /* INC_PCA9555_H_ */
