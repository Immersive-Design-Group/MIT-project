#ifndef IO_EXPANDER_H
#define IO_EXPANDER_H

#include "main.h"
#include <stdbool.h>

/**
 * @brief Initializes both PCA9555 I/O expanders and configures all pins.
 *
 * This function must be called once at startup. It sets up all OE pins as
 * outputs and all switch pins as inputs according to io_mapping.h.
 *
 * @param hi2c Pointer to the HAL I2C_HandleTypeDef for the bus.
 * @return true if initialization was successful, false otherwise.
 */
bool IO_Init(I2C_HandleTypeDef* hi2c);

/**
 * @brief Reads the state of a single input pin from any expander.
 * @param pin The globally unique pin number to read (0-31), from io_mapping.h.
 * @return true if the pin is HIGH, false if the pin is LOW or an error occurred.
 */
bool IO_DigitalRead(uint8_t pin);

/**
 * @brief Writes a state to a single output pin on any expander.
 * @param pin The globally unique pin number to write to (0-31), from io_mapping.h.
 * @param value The value to write (true for HIGH, false for LOW).
 * @return true if the write was successful, false if an error occurred.
 */
bool IO_DigitalWrite(uint8_t pin, bool value);

/**
 * @brief Selects which LED channel to enable by controlling the OE pins on the IO expander.
 * @note  This function guarantees that only one OE pin is LOW at any time.
 *        When a new channel is enabled, all others are automatically disabled (set HIGH).
 *
 * @param channel The channel to enable (0 through 7).
 */
void IO_Expander_EnableLedChannel(uint8_t channel);
void IO_Expander_EnableAllLedChannels(void);
// You should still keep this function for initializing the system.
void IO_Expander_DisableAllLedChannels(void);
#endif // IO_EXPANDER_H
