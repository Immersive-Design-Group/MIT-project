#include "io_expander.h"
#include "pca9555.h"      // The low-level driver
#include "io_mapping.h"   // The pin definitions

// ======== PRIVATE STATE ========
// Create the handles for our two expander chips.
// These are private to this file and hidden from the main application.
static PCA9555_HandleTypeDef expander1;
static PCA9555_HandleTypeDef expander2;
static bool is_initialized = false;

// ======== PUBLIC API FUNCTIONS ========

bool IO_Init(I2C_HandleTypeDef* hi2c)
{
    // Initialize Expander 1 (Address 0x20)
    if (PCA9555_Init(&expander1, hi2c, PCA9555_ADDRESS_0) != HAL_OK) {
        return false; // Error handled inside
    }

    // Initialize Expander 2 (Address 0x21)
    if (PCA9555_Init(&expander2, hi2c, PCA9555_ADDRESS_1) != HAL_OK) {
        return false;
    }

    // --- Configure All Pins for Expander 1 (Pins 0-15) ---
    PCA9555_SetPinMode(&expander1, IO_PIN_LED_DATA1_OE, PCA9555_PIN_OUTPUT);
    PCA9555_SetPinMode(&expander1, IO_PIN_LED_DATA2_OE, PCA9555_PIN_OUTPUT);
    PCA9555_SetPinMode(&expander1, IO_PIN_LED_DATA3_OE, PCA9555_PIN_OUTPUT);
    PCA9555_SetPinMode(&expander1, IO_PIN_LED_DATA4_OE, PCA9555_PIN_OUTPUT);
    PCA9555_SetPinMode(&expander1, IO_PIN_LIMIT_SW1, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander1, IO_PIN_UP_SW1, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander1, IO_PIN_DOWN_SW1, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander1, IO_PIN_LIMIT_SW2, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander1, IO_PIN_UP_SW2, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander1, IO_PIN_DOWN_SW2, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander1, IO_PIN_LIMIT_SW3, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander1, IO_PIN_UP_SW3, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander1, IO_PIN_DOWN_SW3, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander1, IO_PIN_LIMIT_SW4, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander1, IO_PIN_UP_SW4, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander1, IO_PIN_DOWN_SW4, PCA9555_PIN_INPUT);

    // --- Configure All Pins for Expander 2 (Pins 16-31) ---
    // Note: We use the local pin number (0-15) for the low-level driver call
    PCA9555_SetPinMode(&expander2, IO_PIN_LED_DATA5_OE - 16, PCA9555_PIN_OUTPUT);
    PCA9555_SetPinMode(&expander2, IO_PIN_LED_DATA6_OE - 16, PCA9555_PIN_OUTPUT);
    PCA9555_SetPinMode(&expander2, IO_PIN_LED_DATA7_OE - 16, PCA9555_PIN_OUTPUT);
    PCA9555_SetPinMode(&expander2, IO_PIN_LED_DATA8_OE - 16, PCA9555_PIN_OUTPUT);
    PCA9555_SetPinMode(&expander2, IO_PIN_LIMIT_SW5 - 16, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander2, IO_PIN_UP_SW5 - 16, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander2, IO_PIN_DOWN_SW5 - 16, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander2, IO_PIN_LIMIT_SW6 - 16, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander2, IO_PIN_UP_SW6 - 16, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander2, IO_PIN_DOWN_SW6 - 16, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander2, IO_PIN_LIMIT_SW7 - 16, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander2, IO_PIN_UP_SW7 - 16, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander2, IO_PIN_DOWN_SW7 - 16, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander2, IO_PIN_LIMIT_SW8 - 16, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander2, IO_PIN_UP_SW8 - 16, PCA9555_PIN_INPUT);
    PCA9555_SetPinMode(&expander2, IO_PIN_DOWN_SW8 - 16, PCA9555_PIN_INPUT);

    IO_Expander_DisableAllLedChannels();

    is_initialized = true;
    return true; // Success
}

bool IO_DigitalRead(uint8_t pin)
{
    if (!is_initialized) return false;

    GPIO_PinState pin_state = GPIO_PIN_RESET;
    HAL_StatusTypeDef status;

    if (pin < 16) {
        // This pin is on Expander 1
        status = PCA9555_ReadPin(&expander1, pin, &pin_state);
    } else if (pin < 32) {
        // This pin is on Expander 2, subtract 16 for the local pin number
        status = PCA9555_ReadPin(&expander2, pin - 16, &pin_state);
    } else {
        return false; // Invalid pin number
    }

    if (status != HAL_OK) {
        return false; // I2C communication error
    }

    return (pin_state == GPIO_PIN_SET);
}

bool IO_DigitalWrite(uint8_t pin, bool value)
{
    if (!is_initialized) return false;

    GPIO_PinState pin_state = value ? GPIO_PIN_SET : GPIO_PIN_RESET;
    HAL_StatusTypeDef status;

    if (pin < 16) {
        // This pin is on Expander 1
        status = PCA9555_WritePin(&expander1, pin, pin_state);
    } else if (pin < 32) {
        // This pin is on Expander 2, subtract 16 for the local pin number
        status = PCA9555_WritePin(&expander2, pin - 16, pin_state);
    } else {
        return false; // Invalid pin number
    }

    return (status == HAL_OK);
}

static const uint8_t led_oe_pins[8] = {
    IO_PIN_LED_DATA1_OE, // Array index 0 corresponds to Channel 1
    IO_PIN_LED_DATA2_OE, // Array index 1 corresponds to Channel 2
    IO_PIN_LED_DATA3_OE, // Array index 2 corresponds to Channel 3
    IO_PIN_LED_DATA4_OE, // Array index 3 corresponds to Channel 4
    IO_PIN_LED_DATA5_OE, // Array index 4 corresponds to Channel 5
    IO_PIN_LED_DATA6_OE, // Array index 5 corresponds to Channel 6
    IO_PIN_LED_DATA7_OE, // Array index 6 corresponds to Channel 7
    IO_PIN_LED_DATA8_OE  // Array index 7 corresponds to Channel 8
};


// This is the most efficient and robust implementation.
void IO_Expander_EnableLedChannel(uint8_t channel) {
    // Convert the 1-8 channel number to a 0-7 array index
    uint8_t channel_index = channel - 1;

    // Safety check
    if (channel < 1 || channel > 8) {
        return;
    }

    // This loop is more efficient and avoids the "blink" effect.
    for (int i = 0; i < 8; i++) {
        if (i == channel_index) {
            // This is the channel we want to enable.
            IO_DigitalWrite(led_oe_pins[i], false); // Set LOW
        } else {
            // This is not the target channel, so disable it.
            IO_DigitalWrite(led_oe_pins[i], true); // Set HIGH
        }
    }
}

// You should still keep this function for initializing the system.
void IO_Expander_DisableAllLedChannels(void) {
    for (int i = 0; i < 8; i++) {
        IO_DigitalWrite(led_oe_pins[i], true);
    }
}

// You should still keep this function for initializing the system.
void IO_Expander_EnableAllLedChannels(void) {
    for (int i = 0; i < 8; i++) {
        IO_DigitalWrite(led_oe_pins[i], false);
    }
}
