/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define DIR5_Pin GPIO_PIN_2
#define DIR5_GPIO_Port GPIOE
#define STEP5_Pin GPIO_PIN_3
#define STEP5_GPIO_Port GPIOE
#define EN5_Pin GPIO_PIN_5
#define EN5_GPIO_Port GPIOE
#define LED2_Pin GPIO_PIN_2
#define LED2_GPIO_Port GPIOF
#define LED1_Pin GPIO_PIN_3
#define LED1_GPIO_Port GPIOF
#define STEP6_Pin GPIO_PIN_4
#define STEP6_GPIO_Port GPIOF
#define DIR7_Pin GPIO_PIN_0
#define DIR7_GPIO_Port GPIOB
#define STEP7_Pin GPIO_PIN_1
#define STEP7_GPIO_Port GPIOB
#define EN7_Pin GPIO_PIN_13
#define EN7_GPIO_Port GPIOF
#define DIR6_Pin GPIO_PIN_15
#define DIR6_GPIO_Port GPIOF
#define EN6_Pin GPIO_PIN_1
#define EN6_GPIO_Port GPIOG
#define DIR3_Pin GPIO_PIN_12
#define DIR3_GPIO_Port GPIOE
#define STEP3_Pin GPIO_PIN_13
#define STEP3_GPIO_Port GPIOE
#define EN3_Pin GPIO_PIN_15
#define EN3_GPIO_Port GPIOE
#define DIR2_Pin GPIO_PIN_14
#define DIR2_GPIO_Port GPIOB
#define STEP2_Pin GPIO_PIN_15
#define STEP2_GPIO_Port GPIOB
#define EN2_Pin GPIO_PIN_13
#define EN2_GPIO_Port GPIOD
#define DIR1_Pin GPIO_PIN_3
#define DIR1_GPIO_Port GPIOG
#define STEP1_Pin GPIO_PIN_4
#define STEP1_GPIO_Port GPIOG
#define EN1_Pin GPIO_PIN_6
#define EN1_GPIO_Port GPIOG
#define DIR0_Pin GPIO_PIN_6
#define DIR0_GPIO_Port GPIOC
#define STEP0_Pin GPIO_PIN_7
#define STEP0_GPIO_Port GPIOC
#define EN0_Pin GPIO_PIN_11
#define EN0_GPIO_Port GPIOA
#define STEP4_Pin GPIO_PIN_15
#define STEP4_GPIO_Port GPIOA
#define DIR4_Pin GPIO_PIN_10
#define DIR4_GPIO_Port GPIOC
#define EN4_Pin GPIO_PIN_12
#define EN4_GPIO_Port GPIOC

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
