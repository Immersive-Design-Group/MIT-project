#ifndef WS2812B_DRIVER_H
#define WS2812B_DRIVER_H

#include "stm32f4xx_hal.h" // Or your specific HAL include
#include <stdint.h>

/**
 * @brief Initializes the WS2812B driver.
 * @note  This configures the GPIO pin, a hardware timer, and a DMA stream.
 *        It should be called once at startup.
 *
 * @param htim Pointer to the HAL timer handle to be used (e.g., &htim3).
 * @param hdma Pointer to the HAL DMA handle to be used.
 * @return 0 on success, -1 on error.
 */
int ws2812b_init(TIM_HandleTypeDef* htim, DMA_HandleTypeDef* hdma);

/**
 * @brief Sets the entire strip of 12 LEDs to a single color and transmits the data.
 * @note  This function prepares the data and starts the DMA transfer.
 *        It will return while the data is still being sent in the background.
 *        To wait for completion, use ws2812b_isBusy().
 *
 * @param red   The red color component (0-255).
 * @param green The green color component (0-255).
 * @param blue  The blue color component (0-255).
 */
void ws2812b_set_strip_color(uint8_t red, uint8_t green, uint8_t blue);

/**
 * @brief Checks if the DMA is currently busy sending data to the LEDs.
 *
 * @return true if a transfer is in progress, false otherwise.
 */
uint8_t ws2812b_is_busy(void);

void ws2812b_dma_cplt_callback(DMA_HandleTypeDef *hdma);
#endif // WS2812B_DRIVER_H
