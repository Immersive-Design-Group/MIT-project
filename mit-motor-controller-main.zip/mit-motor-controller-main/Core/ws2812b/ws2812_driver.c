#include "ws2812b_driver.h"

// --- Configuration Constants ---
#define NUM_LEDS         12
#define BITS_PER_LED     24
#define RESET_PULSES     50  // Number of low-pulses to generate the >50us reset signal

// These values are calculated for a 84MHz timer clock (APB1) to get 800kHz PWM
#define TIMER_CLOCK_MHZ  84
#define TIMER_PERIOD     (TIMER_CLOCK_MHZ / 0.8) // 105 ticks for an 800kHz signal
#define DUTY_CYCLE_0     (TIMER_PERIOD / 3)      // ~33% duty for a '0' bit (~0.4us)
#define DUTY_CYCLE_1     (TIMER_PERIOD * 2 / 3)  // ~67% duty for a '1' bit (~0.8us)

// --- Static Variables ---
static TIM_HandleTypeDef* p_htim; // Pointer to the timer handle
static DMA_HandleTypeDef* p_hdma; // Pointer to the DMA handle

// This is our DMA buffer. It holds the duty cycle value for each bit, plus reset pulses.
// It must be large enough for all bits + reset sequence.
static uint16_t dma_buffer[BITS_PER_LED * NUM_LEDS + RESET_PULSES];

// A flag to indicate when the DMA transfer is complete
static volatile uint8_t transfer_complete = 1;


/**
 * @brief DMA Transfer Complete callback.
 * @note  This function is called by the HAL DMA IRQ handler when the transfer is finished.
 */
void ws2812b_dma_cplt_callback(DMA_HandleTypeDef *hdma)
{
    // Stop the timer's PWM signal and the DMA request
    HAL_TIM_PWM_Stop_DMA(p_htim, TIM_CHANNEL_2); // IMPORTANT: Use your specific timer channel
    transfer_complete = 1;
}


int ws2812b_init(TIM_HandleTypeDef* htim, DMA_HandleTypeDef* hdma)
{
    if (!htim || !hdma) return -1;

    p_htim = htim;
    p_hdma = hdma;

    // Link our custom callback to the HAL DMA handle
//    p_hdma->XferCpltCallback = ws2812b_dma_cplt_callback;

    // Fill the buffer with 0-duty cycle pulses initially (for reset and off state)
    for(int i = 0; i < sizeof(dma_buffer)/sizeof(dma_buffer[0]); ++i)
    {
        dma_buffer[i] = 0;
    }

    return 0;
}


void ws2812b_set_strip_color(uint8_t red, uint8_t green, uint8_t blue)
{
    if (!transfer_complete) return; // Don't start a new transfer if one is busy
	transfer_complete = 0;

    // The WS2812B expects data in Green-Red-Blue order
	  // r = blue, g = red, b=green *FIX*
    uint32_t color = ((uint32_t)red << 16) | ((uint32_t)blue << 8) | green;

    // --- Prepare the DMA buffer ---
    // For each of the 12 LEDs...
    for (int i = 0; i < NUM_LEDS; ++i)
    {
        // ...and for each of the 24 bits in the color...
        for (int j = 0; j < BITS_PER_LED; ++j)
        {
            // ...check if the most significant bit of the color is a 1 or 0
            if ((color << j) & 0x800000) {
                // If it's a 1, set the duty cycle for a '1' bit
                dma_buffer[i * BITS_PER_LED + j] = DUTY_CYCLE_1;
            } else {
                // If it's a 0, set the duty cycle for a '0' bit
                dma_buffer[i * BITS_PER_LED + j] = DUTY_CYCLE_0;
            }
        }
    }


    // --- Start the DMA Transfer ---
    // The HAL function will configure the DMA and start the timer's PWM signal.
    HAL_TIM_PWM_Start_DMA(p_htim,
                          TIM_CHANNEL_2, // IMPORTANT: Use your specific timer channel
                          (uint32_t *)dma_buffer,
                          sizeof(dma_buffer)/sizeof(dma_buffer[0]));
}

uint8_t ws2812b_is_busy(void)
{
    return !transfer_complete;
}
