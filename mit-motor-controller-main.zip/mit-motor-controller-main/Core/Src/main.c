/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "tmc2209.h"
#include "motion_control.h"
#include "pca9555.h"
#include "io_mapping.h"
#include "io_expander.h"
#include "ws2812b_driver.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* Active-low control macros */
#define LED1_ON()    HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_RESET)
#define LED1_OFF()   HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_SET)

#define LED2_ON()    HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_RESET)
#define LED2_OFF()   HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, GPIO_PIN_SET)

/* Toggle macros for active-low LEDs */
#define LED1_TOGGLE()   HAL_GPIO_TogglePin(LED1_GPIO_Port, LED1_Pin)
#define LED2_TOGGLE()   HAL_GPIO_TogglePin(LED2_GPIO_Port, LED2_Pin)
#define LED_DATA_TOGGLE()   HAL_GPIO_TogglePin(LED_DATA_GPIO_Port, LED_DATA_Pin)
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
DMA_HandleTypeDef hdma_tim3_ch2;

UART_HandleTypeDef huart4;
UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */
TMC2209_Handle_t motor0;
TMC2209_Handle_t motor1;
TMC2209_Handle_t motor2;
TMC2209_Handle_t motor3;
TMC2209_Handle_t motor4;
TMC2209_Handle_t motor5;
TMC2209_Handle_t motor6;
TMC2209_Handle_t motor7;

// 2. Create the array of pointers for the motion controller.
//    Even with one motor, the controller needs this array structure.
TMC2209_Handle_t* all_motor_handles[MAX_MOTORS] = {
    &motor0, &motor1, &motor2, &motor3, &motor4, &motor5, &motor6, &motor7 // Init the rest to NULL
};

// 1. Define the states for our task using an enum for clarity
typedef enum {
    STATE_START_FORWARD_MOVE,
    STATE_WAITING_FOR_FORWARD_FINISH,
    STATE_START_REVERSE_MOVE,
    STATE_WAITING_FOR_REVERSE_FINISH
} MotorTaskState_t;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_TIM2_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_UART4_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM3_Init(void);
/* USER CODE BEGIN PFP */
HAL_StatusTypeDef setup_io_expanders(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART1_UART_Init();
  MX_TIM2_Init();
  MX_USART3_UART_Init();
  MX_USART2_UART_Init();
  MX_UART4_Init();
  MX_I2C1_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */

  // Keep LEDs off at the start
  LED1_OFF();
  LED2_OFF();


  //Initialize gpio_extenders so we can use homing switches

  if (IO_Init(&hi2c1)) {
//	  LED1_ON();
	  LED1_OFF();

  } else {
      // Handle initialization failure
      Error_Handler();
    }

  // Initialize and Configure ALL Motors via UART
  // The timer is NOT running yet, so UART communication is safe and uninterrupted.

    TMC2209_init(&motor0, &huart1, SERIAL_ADDRESS_0);
    TMC2209_init(&motor1, &huart1, SERIAL_ADDRESS_1);
    TMC2209_init(&motor2, &huart3, SERIAL_ADDRESS_0);
    TMC2209_init(&motor3, &huart3, SERIAL_ADDRESS_1);
    TMC2209_init(&motor4, &huart2, SERIAL_ADDRESS_0);
    TMC2209_init(&motor5, &huart2, SERIAL_ADDRESS_1);
    TMC2209_init(&motor6, &huart4, SERIAL_ADDRESS_0);
    TMC2209_init(&motor7, &huart4, SERIAL_ADDRESS_1);

    TMC2209_setControlPins(&motor0, EN0_GPIO_Port, EN0_Pin, STEP0_GPIO_Port, STEP0_Pin, DIR0_GPIO_Port, DIR0_Pin);
    TMC2209_setControlPins(&motor1, EN1_GPIO_Port, EN1_Pin, STEP1_GPIO_Port, STEP1_Pin, DIR1_GPIO_Port, DIR1_Pin);
    TMC2209_setControlPins(&motor2, EN2_GPIO_Port, EN2_Pin, STEP2_GPIO_Port, STEP2_Pin, DIR2_GPIO_Port, DIR2_Pin);
    TMC2209_setControlPins(&motor3, EN3_GPIO_Port, EN3_Pin, STEP3_GPIO_Port, STEP3_Pin, DIR3_GPIO_Port, DIR3_Pin);
    TMC2209_setControlPins(&motor4, EN4_GPIO_Port, EN4_Pin, STEP4_GPIO_Port, STEP4_Pin, DIR4_GPIO_Port, DIR4_Pin);
    TMC2209_setControlPins(&motor5, EN5_GPIO_Port, EN5_Pin, STEP5_GPIO_Port, STEP5_Pin, DIR5_GPIO_Port, DIR5_Pin);
    TMC2209_setControlPins(&motor6, EN6_GPIO_Port, EN6_Pin, STEP6_GPIO_Port, STEP6_Pin, DIR6_GPIO_Port, DIR6_Pin);
    TMC2209_setControlPins(&motor7, EN7_GPIO_Port, EN7_Pin, STEP7_GPIO_Port, STEP7_Pin, DIR7_GPIO_Port, DIR7_Pin);



    // MOTOR0
    // Check communication and set parameters
    if (TMC2209_isCommunicating(&motor0)) {
      // Communication is good, now configure the drive settings
      TMC2209_setRunCurrent(&motor0, 30);
      TMC2209_setHoldCurrent(&motor0, 20);
      TMC2209_setMicrostepsPerStep(&motor0, 4);
      TMC2209_enable(&motor0);
      //LED1_ON(); // Turn on LED to confirm successful communication
    } else {
      // Communication failed. Handle the error. Blink an LED, etc.
      while(1); // Halt here for debugging
    }


    // MOTOR1
    // Check communication and set parameters
    if (TMC2209_isCommunicating(&motor1)) {
      // Communication is good, now configure the drive settings
      TMC2209_setRunCurrent(&motor1, 30);
      TMC2209_setHoldCurrent(&motor1, 20);
      TMC2209_setMicrostepsPerStep(&motor1, 4);
      TMC2209_enable(&motor1);
//      LED1_ON(); // Turn on LED to confirm successful communication
    } else {
      // Communication failed. Handle the error. Blink an LED, etc.
      while(1); // Halt here for debugging
    }

    // MOTOR2
    // Check communication and set parameters
    if (TMC2209_isCommunicating(&motor2)) {
      // Communication is good, now configure the drive settings
      TMC2209_setRunCurrent(&motor2, 30);
      TMC2209_setHoldCurrent(&motor2, 20);
      TMC2209_setMicrostepsPerStep(&motor2, 4);
      TMC2209_enable(&motor2);
      LED2_ON(); // Turn on LED to confirm successful communication
    } else {
      // Communication failed. Handle the error. Blink an LED, etc.
      while(1); // Halt here for debugging
    }

    // MOTOR3
    // Check communication and set parameters
    if (TMC2209_isCommunicating(&motor3)) {
      // Communication is good, now configure the drive settings
      TMC2209_setRunCurrent(&motor3, 30);
      TMC2209_setHoldCurrent(&motor3, 20);
      TMC2209_setMicrostepsPerStep(&motor3, 4);
      TMC2209_enable(&motor3);
      LED2_ON(); // Turn on LED to confirm successful communication
    } else {
      // Communication failed. Handle the error. Blink an LED, etc.
      while(1); // Halt here for debugging
    }



    // MOTOR4
    // Check communication and set parameters
    if (TMC2209_isCommunicating(&motor4)) {
      // Communication is good, now configure the drive settings
      TMC2209_setRunCurrent(&motor4, 30);
      TMC2209_setHoldCurrent(&motor4, 20);
      TMC2209_setMicrostepsPerStep(&motor4, 4);
      TMC2209_enable(&motor4);
      LED1_ON(); // Turn on LED to confirm successful communication
    } else {
      // Communication failed. Handle the error. Blink an LED, etc.
      while(1); // Halt here for debugging
    }

    // MOTOR5
    // Check communication and set parameters
    if (TMC2209_isCommunicating(&motor5)) {
      // Communication is good, now configure the drive settings
      TMC2209_setRunCurrent(&motor5, 30);
      TMC2209_setHoldCurrent(&motor5, 20);
      TMC2209_setMicrostepsPerStep(&motor5, 4);
      TMC2209_enable(&motor5);
      //LED1_ON(); // Turn on LED to confirm successful communication
    } else {
      // Communication failed. Handle the error. Blink an LED, etc.
      while(1); // Halt here for debugging
    }

    // MOTOR6
    // Check communication and set parameters
    if (TMC2209_isCommunicating(&motor6)) {
      // Communication is good, now configure the drive settings
      TMC2209_setRunCurrent(&motor6, 30);
      TMC2209_setHoldCurrent(&motor6, 20);
      TMC2209_setMicrostepsPerStep(&motor6, 4);
      TMC2209_enable(&motor6);
      //LED2_ON(); // Turn on LED to confirm successful communication
    } else {
      // Communication failed. Handle the error. Blink an LED, etc.
      while(1); // Halt here for debugging
    }

    // MOTOR7
    // Check communication and set parameters
    if (TMC2209_isCommunicating(&motor7)) {
      // Communication is good, now configure the drive settings
      TMC2209_setRunCurrent(&motor7, 30);
      TMC2209_setHoldCurrent(&motor7, 20);
      TMC2209_setMicrostepsPerStep(&motor7, 4);
      TMC2209_enable(&motor7);
      LED2_ON(); // Turn on LED to confirm successful communication
    } else {
      // Communication failed. Handle the error. Blink an LED, etc.
      while(1); // Halt here for debugging
    }


    // Once for all motors
    Motion_init(&htim2, all_motor_handles);

    // Enable only after all motor setup
    HAL_TIM_Base_Start_IT(&htim2);
    HAL_Delay(10); // Short delay for power to stabilize

    // --- STATE MACHINE SETUP ---
    // 2. Initialize the state machine
    MotorTaskState_t motor_task_state = STATE_START_FORWARD_MOVE;
    const uint32_t steps_per_rev = 6400; // 200 steps/rev * 16 microsteps
    const uint16_t move_period_us = 2000; // The speed for the move



    //IO_Expander_EnableAllLedChannels();


//    HAL_NVIC_SetPriority(DMA1_Stream5_IRQn, 0, 0);
//    HAL_NVIC_EnableIRQ(DMA1_Stream5_IRQn);


    // Initialize our new LED driver
    ws2812b_init(&htim3, &hdma_tim3_ch2);


    // Some Example LED Code
    uint8_t r = 50, g = 0, b = 0;
    uint8_t temp = r;

    IO_Expander_EnableLedChannel(1);
    ws2812b_set_strip_color(r, g, b);
    IO_Expander_EnableLedChannel(5);
    ws2812b_set_strip_color(r, g, r);
    IO_Expander_EnableLedChannel(4);
    ws2812b_set_strip_color(r, g, r);
    IO_Expander_EnableLedChannel(8);
    ws2812b_set_strip_color(r, g, r);


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */


    // Turn on some LEDs
	HAL_Delay(100);
	temp = r;
	r = g;
	g = b;
	b = temp;
	IO_Expander_EnableLedChannel(1);
    ws2812b_set_strip_color(r, g, b);


	HAL_Delay(100);
	temp = r;
	r = g;
	g = b;
	b = temp;
    IO_Expander_EnableLedChannel(5);
    ws2812b_set_strip_color(r, g, b);


	HAL_Delay(100);
	temp = r;
	r = g;
	g = b;
	b = temp;
    IO_Expander_EnableLedChannel(4);
    ws2812b_set_strip_color(r, g, b);
	HAL_Delay(100);
	temp = r;
	r = g;
	g = b;
	b = temp;
    IO_Expander_EnableLedChannel(8);
    ws2812b_set_strip_color(r, g, b);



  while (1)
  {



	  // 3. Process the current state
	    switch (motor_task_state)
	    {
	      case STATE_START_FORWARD_MOVE:
	        // Command the non-blocking forward move
	    	// 0 i ndexed... Remember
	    	Motion_move(0, steps_per_rev, move_period_us, true);
	        Motion_move(1, steps_per_rev, move_period_us, true);
	        Motion_move(2, steps_per_rev, move_period_us, true);
	        Motion_move(3, steps_per_rev, move_period_us, true);
	    	Motion_move(4, steps_per_rev, move_period_us, true);
	        Motion_move(5, steps_per_rev, move_period_us, true);
	        Motion_move(6, steps_per_rev, move_period_us, true);
	        Motion_move(7, steps_per_rev, move_period_us, true);	        // Immediately transition to the next state
	        motor_task_state = STATE_WAITING_FOR_FORWARD_FINISH;
	        break;

	      case STATE_WAITING_FOR_FORWARD_FINISH:
	        // Do nothing but check if the motor is finished
	        if (!Motion_isBusy(7)) {
	          // The forward move is done. Transition to the next state.
	          //HAL_Delay(1000); // Optional: wait 1 second before reversing
	          motor_task_state = STATE_START_REVERSE_MOVE;
	        }
	        break;

	      case STATE_START_REVERSE_MOVE:
	        // Command the non-blocking reverse move
	        Motion_move(0, steps_per_rev, move_period_us, false);
	        Motion_move(1, steps_per_rev, move_period_us, false);
	        Motion_move(2, steps_per_rev, move_period_us, false);
	        Motion_move(3, steps_per_rev, move_period_us, false);
	    	Motion_move(4, steps_per_rev, move_period_us, false);
	        Motion_move(5, steps_per_rev, move_period_us, false);
	        Motion_move(6, steps_per_rev, move_period_us, false);
	        Motion_move(7, steps_per_rev, move_period_us, false);	        // Immediately transition to the next state
	        motor_task_state = STATE_WAITING_FOR_REVERSE_FINISH;
			//IO_Expander_EnableLedChannel(1);

	        break;

	      case STATE_WAITING_FOR_REVERSE_FINISH:
	        // Do nothing but check if the motor is finished
	        if (!Motion_isBusy(7)) {
	          // The reverse move is done. Go back to the beginning.
	          //HAL_Delay(1000); // Optional: wait 1 second before starting again
	          motor_task_state = STATE_START_FORWARD_MOVE;
	        }
	        break;
	    }


    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 83;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 50;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 0;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 104;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_ENABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief UART4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART4_Init(void)
{

  /* USER CODE BEGIN UART4_Init 0 */

  /* USER CODE END UART4_Init 0 */

  /* USER CODE BEGIN UART4_Init 1 */

  /* USER CODE END UART4_Init 1 */
  huart4.Instance = UART4;
  huart4.Init.BaudRate = 115200;
  huart4.Init.WordLength = UART_WORDLENGTH_8B;
  huart4.Init.StopBits = UART_STOPBITS_1;
  huart4.Init.Parity = UART_PARITY_NONE;
  huart4.Init.Mode = UART_MODE_TX_RX;
  huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart4.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART4_Init 2 */

  /* USER CODE END UART4_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream5_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream5_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, DIR5_Pin|STEP5_Pin|EN5_Pin|DIR3_Pin
                          |STEP3_Pin|EN3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOF, LED2_Pin|LED1_Pin|STEP6_Pin|EN7_Pin
                          |DIR6_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, DIR7_Pin|STEP7_Pin|DIR2_Pin|STEP2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOG, EN6_Pin|DIR1_Pin|STEP1_Pin|EN1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(EN2_GPIO_Port, EN2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, DIR0_Pin|STEP0_Pin|DIR4_Pin|EN4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(EN0_GPIO_Port, EN0_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(STEP4_GPIO_Port, STEP4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : DIR5_Pin STEP5_Pin EN5_Pin DIR3_Pin
                           STEP3_Pin EN3_Pin */
  GPIO_InitStruct.Pin = DIR5_Pin|STEP5_Pin|EN5_Pin|DIR3_Pin
                          |STEP3_Pin|EN3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : LED2_Pin LED1_Pin */
  GPIO_InitStruct.Pin = LED2_Pin|LED1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

  /*Configure GPIO pins : STEP6_Pin EN7_Pin DIR6_Pin */
  GPIO_InitStruct.Pin = STEP6_Pin|EN7_Pin|DIR6_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

  /*Configure GPIO pin : PA6 */
  GPIO_InitStruct.Pin = GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : DIR7_Pin STEP7_Pin DIR2_Pin STEP2_Pin */
  GPIO_InitStruct.Pin = DIR7_Pin|STEP7_Pin|DIR2_Pin|STEP2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : EN6_Pin DIR1_Pin STEP1_Pin EN1_Pin */
  GPIO_InitStruct.Pin = EN6_Pin|DIR1_Pin|STEP1_Pin|EN1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

  /*Configure GPIO pin : EN2_Pin */
  GPIO_InitStruct.Pin = EN2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(EN2_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : DIR0_Pin STEP0_Pin DIR4_Pin EN4_Pin */
  GPIO_InitStruct.Pin = DIR0_Pin|STEP0_Pin|DIR4_Pin|EN4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : EN0_Pin STEP4_Pin */
  GPIO_InitStruct.Pin = EN0_Pin|STEP4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
