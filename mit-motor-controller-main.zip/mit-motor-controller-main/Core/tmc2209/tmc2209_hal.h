#ifndef TMC2209_HAL_H
#define TMC2209_HAL_H

#include "stm32f4xx_hal.h"
#include <stdbool.h>
#include <stdint.h>

/* Arduino constants */
#define OUTPUT         1
#define INPUT          0
#define INPUT_PULLUP   2
#define HIGH           1
#define LOW            0

/* HAL equivalents for Arduino calls */
#define delay(ms)              HAL_Delay(ms)
#define delayMicroseconds(us)  do{ for(volatile uint32_t i=0;i<(us)*42;i++); }while(0) /* 168 MHz */

#define pinMode(pin, mode)     do{ \
                                   GPIO_InitTypeDef GPIO_InitStruct = {0}; \
                                   GPIO_InitStruct.Pin = (pin); \
                                   GPIO_InitStruct.Mode = (mode==OUTPUT)?GPIO_MODE_OUTPUT_PP:GPIO_MODE_INPUT; \
                                   GPIO_InitStruct.Pull = (mode==INPUT_PULLUP)?GPIO_PULLUP:GPIO_NOPULL; \
                                   GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW; \
                                   HAL_GPIO_Init(GPIOF, &GPIO_InitStruct); \
                               }while(0)

#define digitalWrite(pin, v)   HAL_GPIO_WritePin(GPIOF, (pin), (v)?GPIO_PIN_SET:GPIO_PIN_RESET)
#define digitalRead(pin)       (HAL_GPIO_ReadPin(GPIOF, (pin)) == GPIO_PIN_SET)

#endif
