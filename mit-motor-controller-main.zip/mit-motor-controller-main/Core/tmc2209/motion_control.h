#ifndef MOTION_CONTROL_H
#define MOTION_CONTROL_H

#include "tmc2209.h" // We need the TMC2209_Handle_t definition
#include <stdbool.h>
#include <stdint.h>

#define MAX_MOTORS 8 // The maximum number of motors our system can handle

/**
 * @brief Initializes the motion control system.
 *
 * This MUST be called once at startup. It configures and starts the hardware
 * timer that drives all non-blocking motor movements.
 *
 * @param htim Pointer to the HAL timer handle (e.g., &htim2) configured for a 1MHz clock.
 * @param motor_handles An array of pointers to the TMC2209_Handle_t for all motors.
 */
void Motion_init(TIM_HandleTypeDef* htim, TMC2209_Handle_t* motor_handles[MAX_MOTORS]);

/**
 * @brief Commands a motor to move a specific number of steps.
 *
 * This function is NON-BLOCKING. It sets up the move parameters and returns
 * immediately. The actual stepping is handled by the timer interrupt in the background.
 *
 * @param motor_idx The index of the motor to move (0 to MAX_MOTORS-1).
 * @param steps The total number of steps to move.
 * @param period_us The time in microseconds between each step (controls the speed).
 * @param direction The direction of motion (true for forward, false for reverse).
 */
void Motion_move(uint8_t motor_idx, uint32_t steps, uint16_t period_us, bool direction);

/**
 * @brief Immediately stops a motor's movement.
 *
 * @param motor_idx The index of the motor to stop.
 */
void Motion_stop(uint8_t motor_idx);

/**
 * @brief Checks if a motor is currently busy with a move command.
 *
 * @param motor_idx The index of the motor to check.
 * @return true if the motor is currently executing a move, false otherwise.
 */
bool Motion_isBusy(uint8_t motor_idx);

/**
 * @brief The main engine of the motion controller, called by the timer ISR.
 * @note This function should NOT be called by user application code. It must
 *       be public only for the timer interrupt callback to see it.
 */
void Motion_timerCallback(void);

#endif // MOTION_CONTROL_H```
