#include "motion_control.h"

// Private structure to hold the motion profile for a single motor
typedef struct {
    TMC2209_Handle_t* handle;       // Pointer to the motor's driver handle
    volatile bool     active;       // Is this motor currently commanded to move?
    volatile uint32_t steps_remaining; // Steps left in the current move
    uint16_t          period_ticks;  // Ticks between steps (sets the speed)
    volatile uint16_t tick_counter;  // Countdown timer for the next step
} MotionProfile_t;

// ======== Private State ========
static TIM_HandleTypeDef* motion_timer_handle;         // Pointer to the timer we are using
static MotionProfile_t motor_profiles[MAX_MOTORS]; // State for all motors

// ======== Public API Functions ========

void Motion_init(TIM_HandleTypeDef* htim, TMC2209_Handle_t* motor_handles[MAX_MOTORS]) {
    motion_timer_handle = htim;
    for (int i = 0; i < MAX_MOTORS; i++) {
        motor_profiles[i].handle = motor_handles[i];
        motor_profiles[i].active = false;
        motor_profiles[i].steps_remaining = 0;
    }

    // Start the timer interrupt. This is the heartbeat of our motion system.
    HAL_TIM_Base_Start_IT(motion_timer_handle);
}

void Motion_move(uint8_t motor_idx, uint32_t steps, uint16_t period_us, bool direction)
{
    if (motor_idx >= MAX_MOTORS || steps == 0) {
        return;
    }

    // This is ESSENTIAL. Set the motor direction immediately.
    TMC2209_setDirection(motor_profiles[motor_idx].handle, direction);

    // Convert the desired period in microseconds into the correct number of
    // 2-microsecond timer ticks that our hardware is actually generating.
    uint16_t ticks_to_wait = period_us / 100;

    // Ensure we always wait at least 1 tick, even for very high speeds.
    if (ticks_to_wait == 0) {
        ticks_to_wait = 1;
    }

    // Atomic section to prevent race conditions with the ISR
    __disable_irq();
    motor_profiles[motor_idx].period_ticks = ticks_to_wait; // Use the calculated value
    motor_profiles[motor_idx].tick_counter = 1; // Start the first step almost immediately
    motor_profiles[motor_idx].steps_remaining = steps;
    motor_profiles[motor_idx].active = true; // This is the "go" signal for the ISR
    __enable_irq();
}

void Motion_stop(uint8_t motor_idx) {
    if (motor_idx >= MAX_MOTORS) {
        return;
    }
    motor_profiles[motor_idx].active = false;
}

bool Motion_isBusy(uint8_t motor_idx) {
    if (motor_idx >= MAX_MOTORS) {
        return false;
    }
    return motor_profiles[motor_idx].active;
}

// ======== Timer Interrupt Callback ========
// This function is the engine. It gets called by the HAL timer ISR.
void Motion_timerCallback(void) {
    for (int i = 0; i < MAX_MOTORS; i++) {
        // Only process motors that are supposed to be moving
        if (motor_profiles[i].active) {
            motor_profiles[i].tick_counter--;

            if (motor_profiles[i].tick_counter == 0) {
                // Time for a step!
                TMC2209_step(motor_profiles[i].handle);

                motor_profiles[i].steps_remaining--;

                if (motor_profiles[i].steps_remaining == 0) {
                    // This was the last step, the move is complete.
                    motor_profiles[i].active = false;
                } else {
                    // Reload the counter for the next step pulse
                    motor_profiles[i].tick_counter = motor_profiles[i].period_ticks;
                }
            }
        }
    }
}
