// ----------------------------------------------------------------------------
// TMC2209.c
//
// Authors:
// Peter Polidoro peter@polidoro.io
// Converted to STM32 HAL by Assistant
// ----------------------------------------------------------------------------
#include "tmc2209.h"

// Constants (from original header)
#define SYNC 0x05
#define RW_READ 0
#define RW_WRITE 1
#define WRITE_READ_REPLY_DATAGRAM_SIZE 8
#define READ_REQUEST_DATAGRAM_SIZE 4
#define DATA_SIZE 4
#define BITS_PER_BYTE 8
#define BYTE_MAX_VALUE 0xFF
#define MAX_READ_RETRIES 5
#define READ_RETRY_DELAY_MS 20
#define ECHO_DELAY_MAX_MICROSECONDS 4000
#define REPLY_DELAY_MAX_MICROSECONDS 10000

// Register addresses
#define ADDRESS_GCONF 0x00
#define ADDRESS_GSTAT 0x01
#define ADDRESS_IFCNT 0x02
#define ADDRESS_REPLYDELAY 0x03
#define ADDRESS_IOIN 0x06
#define ADDRESS_IHOLD_IRUN 0x10
#define ADDRESS_TPOWERDOWN 0x11
#define ADDRESS_TSTEP 0x12
#define ADDRESS_TPWMTHRS 0x13
#define ADDRESS_TCOOLTHRS 0x14
#define ADDRESS_VACTUAL 0x22
#define ADDRESS_SGTHRS 0x40
#define ADDRESS_SG_RESULT 0x41
#define ADDRESS_COOLCONF 0x42
#define ADDRESS_MSCNT 0x6A
#define ADDRESS_MSCURACT 0x6B
#define ADDRESS_CHOPCONF 0x6C
#define ADDRESS_DRV_STATUS 0x6F
#define ADDRESS_PWMCONF 0x70
#define ADDRESS_PWM_SCALE 0x71
#define ADDRESS_PWM_AUTO 0x72

// Default values
#define CHOPPER_CONFIG_DEFAULT 0x10000053
#define PWM_CONFIG_DEFAULT 0xC10D0024
#define COOLCONF_DEFAULT 0
#define TPOWERDOWN_DEFAULT 20
#define TPWMTHRS_DEFAULT 0
#define VACTUAL_DEFAULT 0
#define TCOOLTHRS_DEFAULT 0
#define SGTHRS_DEFAULT 0
#define IHOLD_DEFAULT 16
#define IRUN_DEFAULT 31
#define IHOLDDELAY_DEFAULT 1
#define TOFF_DEFAULT 3
#define TOFF_DISABLE 0
#define VERSION 0x21

// Microstep resolution values
#define MRES_256 0x0000
#define MRES_128 0x0001
#define MRES_064 0x0002
#define MRES_032 0x0003
#define MRES_016 0x0004
#define MRES_008 0x0005
#define MRES_004 0x0006
#define MRES_002 0x0007
#define MRES_001 0x0008

#define PERCENT_MIN 0
#define PERCENT_MAX 100
#define CURRENT_SETTING_MIN 0
#define CURRENT_SETTING_MAX 31

// Helper function prototypes
static void uart_tx_rx(TMC2209_Handle_t *p_tmc, uint8_t *tx, uint16_t tx_len, uint8_t *rx, uint16_t rx_len);
static void write_register(TMC2209_Handle_t *p_tmc, uint8_t reg, uint32_t data);
static uint32_t read_register(TMC2209_Handle_t *p_tmc, uint8_t reg);
static uint32_t reverse_data(uint32_t data);
static uint8_t calculate_crc(uint8_t *datagram, uint8_t datagram_size);
static uint32_t constrain_value(uint32_t value, uint32_t low, uint32_t high);
static uint8_t percent_to_current_setting(uint8_t percent);
static uint8_t current_setting_to_percent(uint8_t current_setting);
static uint8_t percent_to_hold_delay_setting(uint8_t percent);
static uint8_t hold_delay_setting_to_percent(uint8_t hold_delay_setting);
static uint16_t map_value(uint16_t x, uint16_t in_min, uint16_t in_max, uint16_t out_min, uint16_t out_max);


static void uart_tx_rx(TMC2209_Handle_t *p_tmc, uint8_t *tx, uint16_t tx_len,
                       uint8_t *rx, uint16_t rx_len)
{
    __HAL_UART_CLEAR_OREFLAG(p_tmc->huart);
	if (tx_len)
        HAL_UART_Transmit(p_tmc->huart, tx, tx_len, HAL_MAX_DELAY);

    if (rx_len) {
    	// discard echo byte
        HAL_UART_Receive(p_tmc->huart, rx, 1, 10);
    	// read the reply
    	HAL_UART_Receive(p_tmc->huart, rx, rx_len, 10);
    }
    // let the TMC2209 release the line
    delayMicroseconds(10); // Tuned, don't go much below 50
    //    HAL_Delay(1);         // 1 ms is > 8 bit-times @ 115 kBaud
}

/*
static void uart_tx_rx(TMC2209_Handle_t *p_tmc, uint8_t *tx, uint16_t tx_len,
                       uint8_t *rx, uint16_t rx_len)
{
    const uint32_t timeout_ms = 10;
    uint8_t discard_byte;

    // Proactively clear the Overrun flag before any transaction.
    // This prevents a previous error state from corrupting the current read.
    __HAL_UART_CLEAR_OREFLAG(p_tmc->huart);

    // 1. Transmit the command data.
    if (tx_len) {
        HAL_UART_Transmit(p_tmc->huart, tx, tx_len, timeout_ms);
    }

    // 2. If a reply from the slave is expected...
    if (rx_len) {
        // ...we must first clear the single echo byte that results from the
        // two-wire half-duplex setup causing an overrun condition.
        // We only read 1 byte, as this is the consistent observed behavior.
        HAL_UART_Receive(p_tmc->huart, &discard_byte, 1, timeout_ms);

        // Now that the buffer is confirmed to be clean, read the actual reply.
        HAL_UART_Receive(p_tmc->huart, rx, rx_len, timeout_ms);
    }
}*/


static uint32_t reverse_data(uint32_t data)
{
    uint32_t reversed_data = 0;
    uint8_t right_shift;
    uint8_t left_shift;
    for (uint8_t i = 0; i < DATA_SIZE; ++i) {
        right_shift = (DATA_SIZE - i - 1) * BITS_PER_BYTE;
        left_shift = i * BITS_PER_BYTE;
        reversed_data |= ((data >> right_shift) & BYTE_MAX_VALUE) << left_shift;
    }
    return reversed_data;
}

static uint8_t calculate_crc(uint8_t *datagram, uint8_t datagram_size)
{
    uint8_t crc = 0;
    uint8_t byte;
    for (uint8_t i = 0; i < (datagram_size - 1); ++i) {
        byte = datagram[i];
        for (uint8_t j = 0; j < BITS_PER_BYTE; ++j) {
            if ((crc >> 7) ^ (byte & 0x01)) {
                crc = (crc << 1) ^ 0x07;
            } else {
                crc = crc << 1;
            }
            byte = byte >> 1;
        }
    }
    return crc;
}

static void write_register(TMC2209_Handle_t *p_tmc, uint8_t reg, uint32_t data)
{
    uint8_t tx[8] = {0};
    uint64_t datagram = 0;
    
    // Build write datagram
    datagram |= ((uint64_t)SYNC & 0x0F);
    datagram |= ((uint64_t)p_tmc->serial_addr & 0xFF) << 8;
    datagram |= ((uint64_t)reg & 0x7F) << 16;
    datagram |= ((uint64_t)RW_WRITE & 0x01) << 23;
    datagram |= ((uint64_t)reverse_data(data)) << 24;
    
    // Convert to byte array
    for (uint8_t i = 0; i < 7; ++i) {
        tx[i] = (datagram >> (i * 8)) & 0xFF;
    }
    
    // Calculate and add CRC
    tx[7] = calculate_crc(tx, 8);
    
    uart_tx_rx(p_tmc, tx, 8, NULL, 0);
}

static uint32_t read_register(TMC2209_Handle_t *p_tmc, uint8_t reg)
{
    uint8_t tx[4] = {0};
    uint8_t rx[8] = {0};
    uint32_t datagram = 0;
    
    // Build read request datagram
    datagram |= (SYNC & 0x0F);
    datagram |= ((uint32_t)p_tmc->serial_addr & 0xFF) << 8;
    datagram |= ((uint32_t)reg & 0x7F) << 16;
    datagram |= ((uint32_t)RW_READ & 0x01) << 23;
    
    // Convert to byte array
    for (uint8_t i = 0; i < 3; ++i) {
        tx[i] = (datagram >> (i * 8)) & 0xFF;
    }
    
    // Calculate and add CRC
    tx[3] = calculate_crc(tx, 4);
    
    for (uint8_t retry = 0; retry < MAX_READ_RETRIES; retry++) {
        uart_tx_rx(p_tmc, tx, 4, rx, 8);
        
        // Verify CRC of response
        uint8_t received_crc = rx[7];
        uint8_t calculated_crc = calculate_crc(rx, 8);
        
        if (received_crc == calculated_crc) {
            // Extract and return data
            uint32_t response_data = 0;
            response_data |= ((uint32_t)rx[3] << 24);
            response_data |= ((uint32_t)rx[4] << 16);
            response_data |= ((uint32_t)rx[5] << 8);
            response_data |= ((uint32_t)rx[6]);
            return response_data;
        }
        
        HAL_Delay(READ_RETRY_DELAY_MS);
    }
    
    return 0;
}

// Helper functions
static uint32_t constrain_value(uint32_t value, uint32_t low, uint32_t high)
{
    return ((value) < (low) ? (low) : ((value) > (high) ? (high) : (value)));
}

static uint16_t map_value(uint16_t x, uint16_t in_min, uint16_t in_max, uint16_t out_min, uint16_t out_max)
{
    return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

static uint8_t percent_to_current_setting(uint8_t percent)
{
    uint8_t constrained_percent = constrain_value(percent, PERCENT_MIN, PERCENT_MAX);
    uint8_t current_setting = map_value(constrained_percent, PERCENT_MIN, PERCENT_MAX, CURRENT_SETTING_MIN, CURRENT_SETTING_MAX);
    return current_setting;
}

static uint8_t current_setting_to_percent(uint8_t current_setting)
{
    return map_value(current_setting, CURRENT_SETTING_MIN, CURRENT_SETTING_MAX, PERCENT_MIN, PERCENT_MAX);
}

static uint8_t percent_to_hold_delay_setting(uint8_t percent)
{
    uint8_t constrained_percent = constrain_value(percent, PERCENT_MIN, PERCENT_MAX);
    return map_value(constrained_percent, PERCENT_MIN, PERCENT_MAX, 0, 15);
}

static uint8_t hold_delay_setting_to_percent(uint8_t hold_delay_setting)
{
    return map_value(hold_delay_setting, 0, 15, PERCENT_MIN, PERCENT_MAX);
}

// Public API functions
void TMC2209_init(TMC2209_Handle_t *p_tmc, UART_HandleTypeDef *huart, uint8_t addr)
{
    p_tmc->huart = huart;
    p_tmc->serial_addr = addr;
    
    // Initialize pin structures to NULL (no pins assigned by default)
    p_tmc->en_pin.port = NULL;
    p_tmc->en_pin.pin = 0;
    p_tmc->step_pin.port = NULL;
    p_tmc->step_pin.pin = 0;
    p_tmc->dir_pin.port = NULL;
    p_tmc->dir_pin.pin = 0;
    
    p_tmc->cool_step_enabled = false;
    
    // Initialize register values to defaults
    p_tmc->global_config.bytes = 0;
    p_tmc->global_config.i_scale_analog = 0;
    p_tmc->global_config.pdn_disable = 1;
    p_tmc->global_config.mstep_reg_select = 1;
    p_tmc->global_config.multistep_filt = 1;
    
    p_tmc->driver_current.bytes = 0;
    p_tmc->driver_current.ihold = IHOLD_DEFAULT;
    p_tmc->driver_current.irun = IRUN_DEFAULT;
    p_tmc->driver_current.iholddelay = IHOLDDELAY_DEFAULT;
    
    p_tmc->chopper_config.bytes = CHOPPER_CONFIG_DEFAULT;
    p_tmc->chopper_config.toff = TOFF_DEFAULT;
    p_tmc->toff_value = TOFF_DEFAULT;
    
    p_tmc->pwm_config.bytes = PWM_CONFIG_DEFAULT;
    p_tmc->cool_config.bytes = COOLCONF_DEFAULT;
    
    TMC2209_setRegistersToDefaults(p_tmc);
}

// Public API functions
void TMC2209_init_min(TMC2209_Handle_t *p_tmc, UART_HandleTypeDef *huart, uint8_t addr)
{
    p_tmc->huart = huart;
    p_tmc->serial_addr = addr;
    
    // Initialize pin structures to NULL (no pins assigned by default)
    p_tmc->en_pin.port = NULL;
    p_tmc->en_pin.pin = 0;
    p_tmc->step_pin.port = NULL;
    p_tmc->step_pin.pin = 0;
    p_tmc->dir_pin.port = NULL;
    p_tmc->dir_pin.pin = 0;
    
    p_tmc->cool_step_enabled = false;
    p_tmc->toff_value = TOFF_DEFAULT;

}

void TMC2209_setRegistersToDefaults(TMC2209_Handle_t *p_tmc)
{
    write_register(p_tmc, ADDRESS_GCONF, p_tmc->global_config.bytes);
    write_register(p_tmc, ADDRESS_IHOLD_IRUN, p_tmc->driver_current.bytes);
    write_register(p_tmc, ADDRESS_CHOPCONF, p_tmc->chopper_config.bytes);
    write_register(p_tmc, ADDRESS_PWMCONF, p_tmc->pwm_config.bytes);
    write_register(p_tmc, ADDRESS_COOLCONF, p_tmc->cool_config.bytes);
    write_register(p_tmc, ADDRESS_TPOWERDOWN, TPOWERDOWN_DEFAULT);
    write_register(p_tmc, ADDRESS_TPWMTHRS, TPWMTHRS_DEFAULT);
    write_register(p_tmc, ADDRESS_VACTUAL, VACTUAL_DEFAULT);
    write_register(p_tmc, ADDRESS_TCOOLTHRS, TCOOLTHRS_DEFAULT);
    write_register(p_tmc, ADDRESS_SGTHRS, SGTHRS_DEFAULT);
}

void TMC2209_setControlPins(TMC2209_Handle_t *p_tmc,
                              GPIO_TypeDef* en_port,  uint16_t en_pin,
                              GPIO_TypeDef* step_port, uint16_t step_pin,
                              GPIO_TypeDef* dir_port,  uint16_t dir_pin)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    // Store all pins in the handle
    p_tmc->en_pin.port = en_port;
    p_tmc->en_pin.pin = en_pin;
    p_tmc->step_pin.port = step_port;
    p_tmc->step_pin.pin = step_pin;
    p_tmc->dir_pin.port = dir_port;
    p_tmc->dir_pin.pin = dir_pin;

    // Configure GPIO settings for all pins
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;

    // Initialize Enable Pin (if provided)
    if (en_port != NULL) {
        GPIO_InitStruct.Pin = en_pin;
        HAL_GPIO_Init(en_port, &GPIO_InitStruct);
        HAL_GPIO_WritePin(en_port, en_pin, GPIO_PIN_SET); // Disable driver by default
    }

    // Initialize Step Pin (if provided)
    if (step_port != NULL) {
        GPIO_InitStruct.Pin = step_pin;
        HAL_GPIO_Init(step_port, &GPIO_InitStruct);
        HAL_GPIO_WritePin(step_port, step_pin, GPIO_PIN_RESET); // Pin should be low by default
    }

    // Initialize Direction Pin (if provided)
    if (dir_port != NULL) {
        GPIO_InitStruct.Pin = dir_pin;
        HAL_GPIO_Init(dir_port, &GPIO_InitStruct);
        HAL_GPIO_WritePin(dir_port, dir_pin, GPIO_PIN_RESET); // Default direction
    }
}

void TMC2209_enable(TMC2209_Handle_t *p_tmc)
{
    if (p_tmc->en_pin.port != NULL) {
        HAL_GPIO_WritePin(p_tmc->en_pin.port, p_tmc->en_pin.pin, GPIO_PIN_RESET);
    }
    p_tmc->chopper_config.toff = p_tmc->toff_value;
    write_register(p_tmc, ADDRESS_CHOPCONF, p_tmc->chopper_config.bytes);
}

void TMC2209_disable(TMC2209_Handle_t *p_tmc)
{
    if (p_tmc->en_pin.port != NULL) {
        HAL_GPIO_WritePin(p_tmc->en_pin.port, p_tmc->en_pin.pin, GPIO_PIN_SET);
    }
    p_tmc->chopper_config.toff = TOFF_DISABLE;
    write_register(p_tmc, ADDRESS_CHOPCONF, p_tmc->chopper_config.bytes);
}

void TMC2209_setMicrostepsPerStep(TMC2209_Handle_t *p_tmc, uint16_t microsteps_per_step)
{
    uint16_t microsteps_per_step_shifted = constrain_value(microsteps_per_step, 1, 256);
    microsteps_per_step_shifted = microsteps_per_step >> 1;
    uint16_t exponent = 0;
    while (microsteps_per_step_shifted > 0) {
        microsteps_per_step_shifted = microsteps_per_step_shifted >> 1;
        ++exponent;
    }
    TMC2209_setMicrostepsPerStepPowerOfTwo(p_tmc, exponent);
}

void TMC2209_setMicrostepsPerStepPowerOfTwo(TMC2209_Handle_t *p_tmc, uint8_t exponent)
{
    switch (exponent) {
        case 0: p_tmc->chopper_config.mres = MRES_001; break;
        case 1: p_tmc->chopper_config.mres = MRES_002; break;
        case 2: p_tmc->chopper_config.mres = MRES_004; break;
        case 3: p_tmc->chopper_config.mres = MRES_008; break;
        case 4: p_tmc->chopper_config.mres = MRES_016; break;
        case 5: p_tmc->chopper_config.mres = MRES_032; break;
        case 6: p_tmc->chopper_config.mres = MRES_064; break;
        case 7: p_tmc->chopper_config.mres = MRES_128; break;
        case 8:
        default: p_tmc->chopper_config.mres = MRES_256; break;
    }
    write_register(p_tmc, ADDRESS_CHOPCONF, p_tmc->chopper_config.bytes);
}

void TMC2209_setRunCurrent(TMC2209_Handle_t *p_tmc, uint8_t percent)
{
    uint8_t run_current = percent_to_current_setting(percent);
    p_tmc->driver_current.irun = run_current;
    write_register(p_tmc, ADDRESS_IHOLD_IRUN, p_tmc->driver_current.bytes);
}

void TMC2209_setHoldCurrent(TMC2209_Handle_t *p_tmc, uint8_t percent)
{
    uint8_t hold_current = percent_to_current_setting(percent);
    p_tmc->driver_current.ihold = hold_current;
    write_register(p_tmc, ADDRESS_IHOLD_IRUN, p_tmc->driver_current.bytes);
}

void TMC2209_setHoldDelay(TMC2209_Handle_t *p_tmc, uint8_t percent)
{
    uint8_t hold_delay = percent_to_hold_delay_setting(percent);
    p_tmc->driver_current.iholddelay = hold_delay;
    write_register(p_tmc, ADDRESS_IHOLD_IRUN, p_tmc->driver_current.bytes);
}

void TMC2209_setAllCurrentValues(TMC2209_Handle_t *p_tmc, uint8_t run_current_percent, uint8_t hold_current_percent, uint8_t hold_delay_percent)
{
    uint8_t run_current = percent_to_current_setting(run_current_percent);
    uint8_t hold_current = percent_to_current_setting(hold_current_percent);
    uint8_t hold_delay = percent_to_hold_delay_setting(hold_delay_percent);
    
    p_tmc->driver_current.irun = run_current;
    p_tmc->driver_current.ihold = hold_current;
    p_tmc->driver_current.iholddelay = hold_delay;
    write_register(p_tmc, ADDRESS_IHOLD_IRUN, p_tmc->driver_current.bytes);
}

void TMC2209_enableStealthChop(TMC2209_Handle_t *p_tmc)
{
    p_tmc->global_config.enable_spread_cycle = 0;
    write_register(p_tmc, ADDRESS_GCONF, p_tmc->global_config.bytes);
}

void TMC2209_disableStealthChop(TMC2209_Handle_t *p_tmc)
{
    p_tmc->global_config.enable_spread_cycle = 1;
    write_register(p_tmc, ADDRESS_GCONF, p_tmc->global_config.bytes);
}

void TMC2209_moveAtVelocity(TMC2209_Handle_t *p_tmc, int32_t microsteps_per_period)
{
    write_register(p_tmc, ADDRESS_VACTUAL, microsteps_per_period);
}

void TMC2209_moveUsingStepDirInterface(TMC2209_Handle_t *p_tmc)
{
    write_register(p_tmc, ADDRESS_VACTUAL, 0);
}

void TMC2209_setDirection(TMC2209_Handle_t *p_tmc, bool forward)
{
    if (p_tmc->dir_pin.port != NULL) {
        GPIO_PinState state = forward ? GPIO_PIN_SET : GPIO_PIN_RESET;
        HAL_GPIO_WritePin(p_tmc->dir_pin.port, p_tmc->dir_pin.pin, state);
    }
}

void TMC2209_step(TMC2209_Handle_t *p_tmc)
{
    if (p_tmc->step_pin.port != NULL) {
        HAL_GPIO_WritePin(p_tmc->step_pin.port, p_tmc->step_pin.pin, GPIO_PIN_SET);
        // A minimal delay is required to meet the driver's timing specs.
        // 1-2 microseconds is usually sufficient.
        delayMicroseconds(1);
        HAL_GPIO_WritePin(p_tmc->step_pin.port, p_tmc->step_pin.pin, GPIO_PIN_RESET);
        delayMicroseconds(1);
    }
}

uint8_t TMC2209_getVersion(TMC2209_Handle_t *p_tmc)
{
	uint32_t raw = read_register(p_tmc, ADDRESS_IOIN);
	return (raw >> 24) & 0xFF;
}

bool TMC2209_isCommunicating(TMC2209_Handle_t *p_tmc)
{
    return (TMC2209_getVersion(p_tmc) == VERSION);
}

uint16_t TMC2209_getMicrostepsPerStep(TMC2209_Handle_t *p_tmc)
{
    uint32_t chopconf = read_register(p_tmc, ADDRESS_CHOPCONF);
    uint8_t mres = (chopconf >> 24) & 0x0F;
    
    uint16_t microsteps_per_step_exponent;
    switch (mres) {
        case MRES_001: microsteps_per_step_exponent = 0; break;
        case MRES_002: microsteps_per_step_exponent = 1; break;
        case MRES_004: microsteps_per_step_exponent = 2; break;
        case MRES_008: microsteps_per_step_exponent = 3; break;
        case MRES_016: microsteps_per_step_exponent = 4; break;
        case MRES_032: microsteps_per_step_exponent = 5; break;
        case MRES_064: microsteps_per_step_exponent = 6; break;
        case MRES_128: microsteps_per_step_exponent = 7; break;
        case MRES_256:
        default: microsteps_per_step_exponent = 8; break;
    }
    return 1 << microsteps_per_step_exponent;
}

uint16_t TMC2209_calcMicrostepsPerStep(uint8_t mres)
{
    uint16_t microsteps_per_step_exponent;
    switch (mres) {
        case MRES_001: microsteps_per_step_exponent = 0; break;
        case MRES_002: microsteps_per_step_exponent = 1; break;
        case MRES_004: microsteps_per_step_exponent = 2; break;
        case MRES_008: microsteps_per_step_exponent = 3; break;
        case MRES_016: microsteps_per_step_exponent = 4; break;
        case MRES_032: microsteps_per_step_exponent = 5; break;
        case MRES_064: microsteps_per_step_exponent = 6; break;
        case MRES_128: microsteps_per_step_exponent = 7; break;
        case MRES_256:
        default: microsteps_per_step_exponent = 8; break;
    }
    return 1 << microsteps_per_step_exponent;
}


void TMC2209_setStallGuardThreshold(TMC2209_Handle_t *p_tmc, uint8_t stall_guard_threshold)
{
    write_register(p_tmc, ADDRESS_SGTHRS, stall_guard_threshold);
}

uint16_t TMC2209_getStallGuardResult(TMC2209_Handle_t *p_tmc)
{
    return read_register(p_tmc, ADDRESS_SG_RESULT);
}

void TMC2209_enableInverseMotorDirection(TMC2209_Handle_t *p_tmc)
{
    p_tmc->global_config.shaft = 1;
    write_register(p_tmc, ADDRESS_GCONF, p_tmc->global_config.bytes);
}

void TMC2209_disableInverseMotorDirection(TMC2209_Handle_t *p_tmc)
{
    p_tmc->global_config.shaft = 0;
    write_register(p_tmc, ADDRESS_GCONF, p_tmc->global_config.bytes);
}

void TMC2209_setRMSCurrent(TMC2209_Handle_t *p_tmc, uint16_t mA, float rSense, float holdMultiplier)
{
    // Taken from https://github.com/teemuatlut/TMCStepper
    uint8_t CS = 32.0*1.41421*mA/1000.0*(rSense+0.02)/0.325 - 1;
    // If Current Scale is too low, turn on high sensitivity R_sense and calculate again
    if (CS < 16) {
        TMC2209_enableVSense(p_tmc);
        CS = 32.0*1.41421*mA/1000.0*(rSense+0.02)/0.180 - 1;
    } else { // If CS >= 16, turn off high_sense_r
        TMC2209_disableVSense(p_tmc);
    }

    if (CS > 31) {
        CS = 31;
    }

    p_tmc->driver_current.irun = CS;
    p_tmc->driver_current.ihold = CS*holdMultiplier;
    write_register(p_tmc, ADDRESS_IHOLD_IRUN, p_tmc->driver_current.bytes);
}

void TMC2209_enableDoubleEdge(TMC2209_Handle_t *p_tmc)
{
    p_tmc->chopper_config.double_edge = 1;
    write_register(p_tmc, ADDRESS_CHOPCONF, p_tmc->chopper_config.bytes);
}

void TMC2209_disableDoubleEdge(TMC2209_Handle_t *p_tmc)
{
    p_tmc->chopper_config.double_edge = 0;
    write_register(p_tmc, ADDRESS_CHOPCONF, p_tmc->chopper_config.bytes);
}

void TMC2209_enableVSense(TMC2209_Handle_t *p_tmc)
{
    p_tmc->chopper_config.vsense = 1;
    write_register(p_tmc, ADDRESS_CHOPCONF, p_tmc->chopper_config.bytes);
}

void TMC2209_disableVSense(TMC2209_Handle_t *p_tmc)
{
    p_tmc->chopper_config.vsense = 0;
    write_register(p_tmc, ADDRESS_CHOPCONF, p_tmc->chopper_config.bytes);
}

void TMC2209_setStandstillMode(TMC2209_Handle_t *p_tmc, StandstillMode_t mode)
{
    p_tmc->pwm_config.freewheel = mode;
    write_register(p_tmc, ADDRESS_PWMCONF, p_tmc->pwm_config.bytes);
}

void TMC2209_enableAutomaticCurrentScaling(TMC2209_Handle_t *p_tmc)
{
    p_tmc->pwm_config.pwm_autoscale = 1;
    write_register(p_tmc, ADDRESS_PWMCONF, p_tmc->pwm_config.bytes);
}

void TMC2209_disableAutomaticCurrentScaling(TMC2209_Handle_t *p_tmc)
{
    p_tmc->pwm_config.pwm_autoscale = 0;
    write_register(p_tmc, ADDRESS_PWMCONF, p_tmc->pwm_config.bytes);
}

void TMC2209_enableAutomaticGradientAdaptation(TMC2209_Handle_t *p_tmc)
{
    p_tmc->pwm_config.pwm_autograd = 1;
    write_register(p_tmc, ADDRESS_PWMCONF, p_tmc->pwm_config.bytes);
}

void TMC2209_disableAutomaticGradientAdaptation(TMC2209_Handle_t *p_tmc)
{
    p_tmc->pwm_config.pwm_autograd = 0;
    write_register(p_tmc, ADDRESS_PWMCONF, p_tmc->pwm_config.bytes);
}

void TMC2209_setPwmOffset(TMC2209_Handle_t *p_tmc, uint8_t pwm_amplitude)
{
    p_tmc->pwm_config.pwm_offset = pwm_amplitude;
    write_register(p_tmc, ADDRESS_PWMCONF, p_tmc->pwm_config.bytes);
}

void TMC2209_setPwmGradient(TMC2209_Handle_t *p_tmc, uint8_t pwm_amplitude)
{
    p_tmc->pwm_config.pwm_grad = pwm_amplitude;
    write_register(p_tmc, ADDRESS_PWMCONF, p_tmc->pwm_config.bytes);
}

void TMC2209_setPowerDownDelay(TMC2209_Handle_t *p_tmc, uint8_t power_down_delay)
{
    write_register(p_tmc, ADDRESS_TPOWERDOWN, power_down_delay);
}

void TMC2209_setReplyDelay(TMC2209_Handle_t *p_tmc, uint8_t delay)
{
    if (delay > REPLY_DELAY_MAX) {
        delay = REPLY_DELAY_MAX;
    }
    uint32_t reply_delay_data = 0;
    reply_delay_data |= ((uint32_t)delay & 0x0F) << 8;
    write_register(p_tmc, ADDRESS_REPLYDELAY, reply_delay_data);
}

void TMC2209_setStealthChopDurationThreshold(TMC2209_Handle_t *p_tmc, uint32_t duration_threshold)
{
    write_register(p_tmc, ADDRESS_TPWMTHRS, duration_threshold);
}

void TMC2209_enableCoolStep(TMC2209_Handle_t *p_tmc, uint8_t lower_threshold, uint8_t upper_threshold)
{
    lower_threshold = constrain_value(lower_threshold, 1, 15);
    p_tmc->cool_config.semin = lower_threshold;
    upper_threshold = constrain_value(upper_threshold, 0, 15);
    p_tmc->cool_config.semax = upper_threshold;
    write_register(p_tmc, ADDRESS_COOLCONF, p_tmc->cool_config.bytes);
    p_tmc->cool_step_enabled = true;
}

void TMC2209_disableCoolStep(TMC2209_Handle_t *p_tmc)
{
    p_tmc->cool_config.semin = 0;
    write_register(p_tmc, ADDRESS_COOLCONF, p_tmc->cool_config.bytes);
    p_tmc->cool_step_enabled = false;
}

void TMC2209_setCoolStepCurrentIncrement(TMC2209_Handle_t *p_tmc, CurrentIncrement_t current_increment)
{
    p_tmc->cool_config.seup = current_increment;
    write_register(p_tmc, ADDRESS_COOLCONF, p_tmc->cool_config.bytes);
}

void TMC2209_setCoolStepMeasurementCount(TMC2209_Handle_t *p_tmc, MeasurementCount_t measurement_count)
{
    p_tmc->cool_config.sedn = measurement_count;
    write_register(p_tmc, ADDRESS_COOLCONF, p_tmc->cool_config.bytes);
}

void TMC2209_setCoolStepDurationThreshold(TMC2209_Handle_t *p_tmc, uint32_t duration_threshold)
{
    write_register(p_tmc, ADDRESS_TCOOLTHRS, duration_threshold);
}

void TMC2209_enableAnalogCurrentScaling(TMC2209_Handle_t *p_tmc)
{
    p_tmc->global_config.i_scale_analog = 1;
    write_register(p_tmc, ADDRESS_GCONF, p_tmc->global_config.bytes);
}

void TMC2209_disableAnalogCurrentScaling(TMC2209_Handle_t *p_tmc)
{
    p_tmc->global_config.i_scale_analog = 0;
    write_register(p_tmc, ADDRESS_GCONF, p_tmc->global_config.bytes);
}

void TMC2209_useExternalSenseResistors(TMC2209_Handle_t *p_tmc)
{
    p_tmc->global_config.internal_rsense = 0;
    write_register(p_tmc, ADDRESS_GCONF, p_tmc->global_config.bytes);
}

void TMC2209_useInternalSenseResistors(TMC2209_Handle_t *p_tmc)
{
    p_tmc->global_config.internal_rsense = 1;
    write_register(p_tmc, ADDRESS_GCONF, p_tmc->global_config.bytes);
}

bool TMC2209_isSetupAndCommunicating(TMC2209_Handle_t *p_tmc)
{
    if (!TMC2209_isCommunicating(p_tmc)) {
        return false;
    }
    uint32_t gconf = read_register(p_tmc, ADDRESS_GCONF);
    return (gconf & 0x40) != 0; // pdn_disable bit
}

bool TMC2209_isCommunicatingButNotSetup(TMC2209_Handle_t *p_tmc)
{
    return (TMC2209_isCommunicating(p_tmc) && !TMC2209_isSetupAndCommunicating(p_tmc));
}

bool TMC2209_hardwareDisabled(TMC2209_Handle_t *p_tmc)
{
    uint32_t input_data = read_register(p_tmc, ADDRESS_IOIN);
    return (input_data & 0x01) != 0; // enn bit
}

Settings_t TMC2209_getSettings(TMC2209_Handle_t *p_tmc)
{
    Settings_t settings = {0};

    // Populate the settings structure by reading from the software handle (the cache).
    // This function no longer communicates with the hardware, making it instantaneous
    // and preventing it from overwriting the driver's cached state.

    // Check communication status to report if the cached data is likely to be "live".
    settings.is_communicating = TMC2209_isCommunicating(p_tmc);

    // Translate cached register values into a user-friendly format.
    settings.is_setup = p_tmc->global_config.pdn_disable;
    settings.software_enabled = (p_tmc->chopper_config.toff > 0);
    settings.microsteps_per_step = TMC2209_calcMicrostepsPerStep(p_tmc->chopper_config.mres);
    settings.inverse_motor_direction_enabled = p_tmc->global_config.shaft;
    settings.stealth_chop_enabled = !p_tmc->global_config.enable_spread_cycle;
    settings.standstill_mode = p_tmc->pwm_config.freewheel;
    settings.irun_percent = current_setting_to_percent(p_tmc->driver_current.irun);
    settings.irun_register_value = p_tmc->driver_current.irun;
    settings.ihold_percent = current_setting_to_percent(p_tmc->driver_current.ihold);
    settings.ihold_register_value = p_tmc->driver_current.ihold;
    settings.iholddelay_percent = hold_delay_setting_to_percent(p_tmc->driver_current.iholddelay);
    settings.iholddelay_register_value = p_tmc->driver_current.iholddelay;
    settings.automatic_current_scaling_enabled = p_tmc->pwm_config.pwm_autoscale;
    settings.automatic_gradient_adaptation_enabled = p_tmc->pwm_config.pwm_autograd;
    settings.pwm_offset = p_tmc->pwm_config.pwm_offset;
    settings.pwm_gradient = p_tmc->pwm_config.pwm_grad;
    settings.cool_step_enabled = p_tmc->cool_step_enabled;
    settings.analog_current_scaling_enabled = p_tmc->global_config.i_scale_analog;
    settings.internal_sense_resistors_enabled = p_tmc->global_config.internal_rsense;

    return settings;
}

Status_t TMC2209_getStatus(TMC2209_Handle_t *p_tmc)
{
    uint32_t status_data = read_register(p_tmc, ADDRESS_DRV_STATUS);
    Status_t status = {0};
    
    status.over_temperature_warning = (status_data >> 0) & 0x01;
    status.over_temperature_shutdown = (status_data >> 1) & 0x01;
    status.short_to_ground_a = (status_data >> 2) & 0x01;
    status.short_to_ground_b = (status_data >> 3) & 0x01;
    status.low_side_short_a = (status_data >> 4) & 0x01;
    status.low_side_short_b = (status_data >> 5) & 0x01;
    status.open_load_a = (status_data >> 6) & 0x01;
    status.open_load_b = (status_data >> 7) & 0x01;
    status.over_temperature_120c = (status_data >> 8) & 0x01;
    status.over_temperature_143c = (status_data >> 9) & 0x01;
    status.over_temperature_150c = (status_data >> 10) & 0x01;
    status.over_temperature_157c = (status_data >> 11) & 0x01;
    status.current_scaling = (status_data >> 16) & 0x1F;
    status.stealth_chop_mode = (status_data >> 30) & 0x01;
    status.standstill = (status_data >> 31) & 0x01;
    
    return status;
}

GlobalStatus_t TMC2209_getGlobalStatus(TMC2209_Handle_t *p_tmc)
{
    uint32_t gstat_data = read_register(p_tmc, ADDRESS_GSTAT);
    GlobalStatus_t global_status = {0};
    
    global_status.reset = (gstat_data >> 0) & 0x01;
    global_status.drv_err = (gstat_data >> 1) & 0x01;
    global_status.uv_cp = (gstat_data >> 2) & 0x01;
    
    return global_status;
}

void TMC2209_clearReset(TMC2209_Handle_t *p_tmc)
{
    uint32_t gstat_data = 0x01; // Set reset bit to clear it
    write_register(p_tmc, ADDRESS_GSTAT, gstat_data);
}

void TMC2209_clearDriveError(TMC2209_Handle_t *p_tmc)
{
    uint32_t gstat_data = 0x02; // Set drv_err bit to clear it
    write_register(p_tmc, ADDRESS_GSTAT, gstat_data);
}

uint8_t TMC2209_getInterfaceTransmissionCounter(TMC2209_Handle_t *p_tmc)
{
    return read_register(p_tmc, ADDRESS_IFCNT);
}

uint32_t TMC2209_getInterstepDuration(TMC2209_Handle_t *p_tmc)
{
    return read_register(p_tmc, ADDRESS_TSTEP);
}

uint8_t TMC2209_getPwmScaleSum(TMC2209_Handle_t *p_tmc)
{
    uint32_t pwm_scale_data = read_register(p_tmc, ADDRESS_PWM_SCALE);
    return pwm_scale_data & 0xFF;
}

int16_t TMC2209_getPwmScaleAuto(TMC2209_Handle_t *p_tmc)
{
    uint32_t pwm_scale_data = read_register(p_tmc, ADDRESS_PWM_SCALE);
    return (pwm_scale_data >> 16) & 0x1FF;
}

uint8_t TMC2209_getPwmOffsetAuto(TMC2209_Handle_t *p_tmc)
{
    uint32_t pwm_auto_data = read_register(p_tmc, ADDRESS_PWM_AUTO);
    return pwm_auto_data & 0xFF;
}

uint8_t TMC2209_getPwmGradientAuto(TMC2209_Handle_t *p_tmc)
{
    uint32_t pwm_auto_data = read_register(p_tmc, ADDRESS_PWM_AUTO);
    return (pwm_auto_data >> 16) & 0xFF;
}

uint16_t TMC2209_getMicrostepCounter(TMC2209_Handle_t *p_tmc)
{
    return read_register(p_tmc, ADDRESS_MSCNT);
}

uint32_t TMC2209_read(TMC2209_Handle_t *p_tmc, uint8_t reg)
{
    return read_register(p_tmc, reg);   // uses the existing private read() routine
}

