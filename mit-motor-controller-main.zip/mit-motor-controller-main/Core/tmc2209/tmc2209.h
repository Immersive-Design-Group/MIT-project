// ----------------------------------------------------------------------------
// TMC2209.h
//
// Authors:
// Peter Polidoro peter@polidoro.io
// ----------------------------------------------------------------------------

#ifndef TMC2209_H
#define TMC2209_H
#include "tmc2209_hal.h"   // replaces Arduino.h
#include <stdbool.h>
#include <stdint.h>

// Serial Address enumeration
typedef enum {
    SERIAL_ADDRESS_0 = 0,
    SERIAL_ADDRESS_1 = 1,
    SERIAL_ADDRESS_2 = 2,
    SERIAL_ADDRESS_3 = 3,
} SerialAddress_t;

// Standstill Mode enumeration
typedef enum {
    STANDSTILL_NORMAL = 0,
    STANDSTILL_FREEWHEELING = 1,
    STANDSTILL_STRONG_BRAKING = 2,
    STANDSTILL_BRAKING = 3,
} StandstillMode_t;

// Current Increment enumeration
typedef enum {
    CURRENT_INCREMENT_1 = 0,
    CURRENT_INCREMENT_2 = 1,
    CURRENT_INCREMENT_4 = 2,
    CURRENT_INCREMENT_8 = 3,
} CurrentIncrement_t;

// Measurement Count enumeration
typedef enum {
    MEASUREMENT_COUNT_32 = 0,
    MEASUREMENT_COUNT_8 = 1,
    MEASUREMENT_COUNT_2 = 2,
    MEASUREMENT_COUNT_1 = 3,
} MeasurementCount_t;

// Register structures
typedef union {
    struct {
        uint32_t i_scale_analog : 1;
        uint32_t internal_rsense : 1;
        uint32_t enable_spread_cycle : 1;
        uint32_t shaft : 1;
        uint32_t index_otpw : 1;
        uint32_t index_step : 1;
        uint32_t pdn_disable : 1;
        uint32_t mstep_reg_select : 1;
        uint32_t multistep_filt : 1;
        uint32_t test_mode : 1;
        uint32_t reserved : 22;
    };
    uint32_t bytes;
} GlobalConfig_t;

typedef union {
    struct {
        uint32_t ihold : 5;
        uint32_t reserved_0 : 3;
        uint32_t irun : 5;
        uint32_t reserved_1 : 3;
        uint32_t iholddelay : 4;
        uint32_t reserved_2 : 12;
    };
    uint32_t bytes;
} DriverCurrent_t;

typedef union {
    struct {
        uint32_t toff : 4;
        uint32_t hstart : 3;
        uint32_t hend : 4;
        uint32_t reserved_0 : 4;
        uint32_t tbl : 2;
        uint32_t vsense : 1;
        uint32_t reserved_1 : 6;
        uint32_t mres : 4;
        uint32_t interpolation : 1;
        uint32_t double_edge : 1;
        uint32_t diss2g : 1;
        uint32_t diss2vs : 1;
    };
    uint32_t bytes;
} ChopperConfig_t;

typedef union {
    struct {
        uint32_t pwm_offset : 8;
        uint32_t pwm_grad : 8;
        uint32_t pwm_freq : 2;
        uint32_t pwm_autoscale : 1;
        uint32_t pwm_autograd : 1;
        uint32_t freewheel : 2;
        uint32_t reserved : 2;
        uint32_t pwm_reg : 4;
        uint32_t pwm_lim : 4;
    };
    uint32_t bytes;
} PwmConfig_t;

typedef union {
    struct {
        uint32_t semin : 4;
        uint32_t reserved_0 : 1;
        uint32_t seup : 2;
        uint32_t reserved_1 : 1;
        uint32_t semax : 4;
        uint32_t reserved_2 : 1;
        uint32_t sedn : 2;
        uint32_t seimin : 1;
        uint32_t reserved_3 : 16;
    };
    uint32_t bytes;
} CoolConfig_t;

typedef struct {
    uint32_t over_temperature_warning : 1;
    uint32_t over_temperature_shutdown : 1;
    uint32_t short_to_ground_a : 1;
    uint32_t short_to_ground_b : 1;
    uint32_t low_side_short_a : 1;
    uint32_t low_side_short_b : 1;
    uint32_t open_load_a : 1;
    uint32_t open_load_b : 1;
    uint32_t over_temperature_120c : 1;
    uint32_t over_temperature_143c : 1;
    uint32_t over_temperature_150c : 1;
    uint32_t over_temperature_157c : 1;
    uint32_t reserved0 : 4;
    uint32_t current_scaling : 5;
    uint32_t reserved1 : 9;
    uint32_t stealth_chop_mode : 1;
    uint32_t standstill : 1;
} Status_t;

typedef struct {
    uint32_t reset : 1;
    uint32_t drv_err : 1;
    uint32_t uv_cp : 1;
    uint32_t reserved : 29;
} GlobalStatus_t;

typedef struct {
    bool is_communicating;
    bool is_setup;
    bool software_enabled;
    uint16_t microsteps_per_step;
    bool inverse_motor_direction_enabled;
    bool stealth_chop_enabled;
    uint8_t standstill_mode;
    uint8_t irun_percent;
    uint8_t irun_register_value;
    uint8_t ihold_percent;
    uint8_t ihold_register_value;
    uint8_t iholddelay_percent;
    uint8_t iholddelay_register_value;
    bool automatic_current_scaling_enabled;
    bool automatic_gradient_adaptation_enabled;
    uint8_t pwm_offset;
    uint8_t pwm_gradient;
    bool cool_step_enabled;
    bool analog_current_scaling_enabled;
    bool internal_sense_resistors_enabled;
} Settings_t;

// Helper struct to define a GPIO pin in the STM32 HAL environment
typedef struct {
    GPIO_TypeDef* port;
    uint16_t      pin;
} TMC_Pin_t;

typedef struct {
    // Hardware and communication configuration
    UART_HandleTypeDef *huart;
    uint8_t             serial_addr;

    // GPIO pin definitions
    TMC_Pin_t           en_pin;
    TMC_Pin_t           step_pin;
    TMC_Pin_t           dir_pin;

    // Cached register values
    GlobalConfig_t  global_config;
    DriverCurrent_t driver_current;
    ChopperConfig_t chopper_config;
    PwmConfig_t     pwm_config;
    CoolConfig_t    cool_config;

    // Internal state flags and values
    bool    cool_step_enabled;
    uint8_t toff_value;

} TMC2209_Handle_t;

// Constants
#define CURRENT_SCALING_MAX 31
#define REPLY_DELAY_MAX 15

// Function declarations

// Initialization
void TMC2209_init(TMC2209_Handle_t *p_tmc, UART_HandleTypeDef *huart, uint8_t addr);
void TMC2209_init_min(TMC2209_Handle_t *p_tmc, UART_HandleTypeDef *huart, uint8_t addr);
void TMC2209_setRegistersToDefaults(TMC2209_Handle_t *p_tmc);

// Hardware control
void TMC2209_setControlPins(TMC2209_Handle_t *p_tmc,
                              GPIO_TypeDef* en_port,  uint16_t en_pin,
                              GPIO_TypeDef* step_port, uint16_t step_pin,
                              GPIO_TypeDef* dir_port,  uint16_t dir_pin);
void TMC2209_enable(TMC2209_Handle_t *p_tmc);
void TMC2209_disable(TMC2209_Handle_t *p_tmc);

// Microstepping
void TMC2209_setMicrostepsPerStep(TMC2209_Handle_t *p_tmc, uint16_t microsteps_per_step);
void TMC2209_setMicrostepsPerStepPowerOfTwo(TMC2209_Handle_t *p_tmc, uint8_t exponent);
uint16_t TMC2209_getMicrostepsPerStep(TMC2209_Handle_t *p_tmc);
uint16_t TMC2209_calcMicrostepsPerStep(uint8_t mres);

// Current settings
void TMC2209_setRunCurrent(TMC2209_Handle_t *p_tmc, uint8_t percent);
void TMC2209_setHoldCurrent(TMC2209_Handle_t *p_tmc, uint8_t percent);
void TMC2209_setHoldDelay(TMC2209_Handle_t *p_tmc, uint8_t percent);
void TMC2209_setAllCurrentValues(TMC2209_Handle_t *p_tmc, uint8_t run_current_percent, uint8_t hold_current_percent, uint8_t hold_delay_percent);
void TMC2209_setRMSCurrent(TMC2209_Handle_t *p_tmc, uint16_t mA, float rSense, float holdMultiplier);

// Direction and movement
void TMC2209_enableInverseMotorDirection(TMC2209_Handle_t *p_tmc);
void TMC2209_disableInverseMotorDirection(TMC2209_Handle_t *p_tmc);
void TMC2209_moveAtVelocity(TMC2209_Handle_t *p_tmc, int32_t microsteps_per_period);
void TMC2209_moveUsingStepDirInterface(TMC2209_Handle_t *p_tmc);
void TMC2209_setDirection(TMC2209_Handle_t *p_tmc, bool forward);
void TMC2209_step(TMC2209_Handle_t *p_tmc);

// StealthChop
void TMC2209_enableStealthChop(TMC2209_Handle_t *p_tmc);
void TMC2209_disableStealthChop(TMC2209_Handle_t *p_tmc);
void TMC2209_setStealthChopDurationThreshold(TMC2209_Handle_t *p_tmc, uint32_t duration_threshold);

// StallGuard
void TMC2209_setStallGuardThreshold(TMC2209_Handle_t *p_tmc, uint8_t stall_guard_threshold);
uint16_t TMC2209_getStallGuardResult(TMC2209_Handle_t *p_tmc);

// CoolStep
void TMC2209_enableCoolStep(TMC2209_Handle_t *p_tmc, uint8_t lower_threshold, uint8_t upper_threshold);
void TMC2209_disableCoolStep(TMC2209_Handle_t *p_tmc);
void TMC2209_setCoolStepCurrentIncrement(TMC2209_Handle_t *p_tmc, CurrentIncrement_t current_increment);
void TMC2209_setCoolStepMeasurementCount(TMC2209_Handle_t *p_tmc, MeasurementCount_t measurement_count);
void TMC2209_setCoolStepDurationThreshold(TMC2209_Handle_t *p_tmc, uint32_t duration_threshold);

// Advanced settings
void TMC2209_enableDoubleEdge(TMC2209_Handle_t *p_tmc);
void TMC2209_disableDoubleEdge(TMC2209_Handle_t *p_tmc);
void TMC2209_enableVSense(TMC2209_Handle_t *p_tmc);
void TMC2209_disableVSense(TMC2209_Handle_t *p_tmc);
void TMC2209_setStandstillMode(TMC2209_Handle_t *p_tmc, StandstillMode_t mode);
void TMC2209_enableAutomaticCurrentScaling(TMC2209_Handle_t *p_tmc);
void TMC2209_disableAutomaticCurrentScaling(TMC2209_Handle_t *p_tmc);
void TMC2209_enableAutomaticGradientAdaptation(TMC2209_Handle_t *p_tmc);
void TMC2209_disableAutomaticGradientAdaptation(TMC2209_Handle_t *p_tmc);
void TMC2209_setPwmOffset(TMC2209_Handle_t *p_tmc, uint8_t pwm_amplitude);
void TMC2209_setPwmGradient(TMC2209_Handle_t *p_tmc, uint8_t pwm_amplitude);
void TMC2209_setPowerDownDelay(TMC2209_Handle_t *p_tmc, uint8_t power_down_delay);
void TMC2209_setReplyDelay(TMC2209_Handle_t *p_tmc, uint8_t delay);
void TMC2209_enableAnalogCurrentScaling(TMC2209_Handle_t *p_tmc);
void TMC2209_disableAnalogCurrentScaling(TMC2209_Handle_t *p_tmc);
void TMC2209_useExternalSenseResistors(TMC2209_Handle_t *p_tmc);
void TMC2209_useInternalSenseResistors(TMC2209_Handle_t *p_tmc);

// Communication and status
uint32_t TMC2209_read(TMC2209_Handle_t *p_tmc, uint8_t reg);

uint8_t TMC2209_getVersion(TMC2209_Handle_t *p_tmc);
bool TMC2209_isCommunicating(TMC2209_Handle_t *p_tmc);
bool TMC2209_isSetupAndCommunicating(TMC2209_Handle_t *p_tmc);
bool TMC2209_isCommunicatingButNotSetup(TMC2209_Handle_t *p_tmc);
bool TMC2209_hardwareDisabled(TMC2209_Handle_t *p_tmc);
Settings_t TMC2209_getSettings(TMC2209_Handle_t *p_tmc);
Status_t TMC2209_getStatus(TMC2209_Handle_t *p_tmc);
GlobalStatus_t TMC2209_getGlobalStatus(TMC2209_Handle_t *p_tmc);
void TMC2209_clearReset(TMC2209_Handle_t *p_tmc);
void TMC2209_clearDriveError(TMC2209_Handle_t *p_tmc);
uint8_t TMC2209_getInterfaceTransmissionCounter(TMC2209_Handle_t *p_tmc);
uint32_t TMC2209_getInterstepDuration(TMC2209_Handle_t *p_tmc);
uint8_t TMC2209_getPwmScaleSum(TMC2209_Handle_t *p_tmc);
int16_t TMC2209_getPwmScaleAuto(TMC2209_Handle_t *p_tmc);
uint8_t TMC2209_getPwmOffsetAuto(TMC2209_Handle_t *p_tmc);
uint8_t TMC2209_getPwmGradientAuto(TMC2209_Handle_t *p_tmc);
uint16_t TMC2209_getMicrostepCounter(TMC2209_Handle_t *p_tmc);

#endif
