################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/pca9555/io_expander.c \
../Core/pca9555/pca9555.c 

OBJS += \
./Core/pca9555/io_expander.o \
./Core/pca9555/pca9555.o 

C_DEPS += \
./Core/pca9555/io_expander.d \
./Core/pca9555/pca9555.d 


# Each subdirectory must supply rules for building sources it contributes
Core/pca9555/%.o Core/pca9555/%.su Core/pca9555/%.cyclo: ../Core/pca9555/%.c Core/pca9555/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F407xx -c -I../Core/Inc -I/home/bairui/stm32/mit-motor-controller/Core/tmc2209 -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I/home/bairui/stm32/mit-motor-controller/Core/pca9555 -I/home/bairui/stm32/mit-motor-controller/Core/ws2812b -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-pca9555

clean-Core-2f-pca9555:
	-$(RM) ./Core/pca9555/io_expander.cyclo ./Core/pca9555/io_expander.d ./Core/pca9555/io_expander.o ./Core/pca9555/io_expander.su ./Core/pca9555/pca9555.cyclo ./Core/pca9555/pca9555.d ./Core/pca9555/pca9555.o ./Core/pca9555/pca9555.su

.PHONY: clean-Core-2f-pca9555

