################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/ws2812b/ws2812_driver.c 

OBJS += \
./Core/ws2812b/ws2812_driver.o 

C_DEPS += \
./Core/ws2812b/ws2812_driver.d 


# Each subdirectory must supply rules for building sources it contributes
Core/ws2812b/%.o Core/ws2812b/%.su Core/ws2812b/%.cyclo: ../Core/ws2812b/%.c Core/ws2812b/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F407xx -c -I../Core/Inc -I/home/bairui/stm32/mit-motor-controller/Core/tmc2209 -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I/home/bairui/stm32/mit-motor-controller/Core/pca9555 -I/home/bairui/stm32/mit-motor-controller/Core/ws2812b -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-ws2812b

clean-Core-2f-ws2812b:
	-$(RM) ./Core/ws2812b/ws2812_driver.cyclo ./Core/ws2812b/ws2812_driver.d ./Core/ws2812b/ws2812_driver.o ./Core/ws2812b/ws2812_driver.su

.PHONY: clean-Core-2f-ws2812b

