# mit-pin-table-pcbs

mid pcb and motor pcb are Altium
all other pcbs are kicad 9
# mit-pin-table-pcbs
